# -*- coding: utf-8 -*-
"""
GSI DEM Downloader Plugin
"""
import os
from qgis.PyQt.QtWidgets import QAction, QToolBar
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from .dialog import GSIDEMDownloaderDialog


class GSIDEMDownloaderPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = '国土地理院DEM'
        self.toolbar_name = '拡張機能'
        self.toolbar = None

    def add_action(self, icon_path, text, callback, enabled_flag=True,
                   add_to_menu=True, add_to_toolbar=True, status_tip=None,
                   whats_this=None, parent=None):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)
        if status_tip:
            action.setStatusTip(status_tip)
        if whats_this:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.add_to_common_toolbar(action)
        if add_to_menu:
            self.iface.addPluginToRasterMenu(self.menu, action)
        self.actions.append(action)
        return action

    def add_to_common_toolbar(self, action):
        # layer2shp と同じ「拡張機能」共通ツールバーへ追加する
        self.toolbar = self.iface.mainWindow().findChild(QToolBar, self.toolbar_name)
        if self.toolbar is None:
            self.toolbar = self.iface.addToolBar(self.toolbar_name)
            self.toolbar.setObjectName(self.toolbar_name)
        self.toolbar.addAction(action)
        self.toolbar.setVisible(True)

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icons", "GSIDD.png")
        self.add_action(
            icon_path,
            text='国土地理院 標高DEM ダウンローダー',
            callback=self.run,
            parent=self.iface.mainWindow(),
            status_tip='国土地理院の標高タイルをDEM画像として取得'
        )

    def unload(self):
        for action in self.actions:
            self.iface.removePluginRasterMenu(self.menu, action)
            if self.toolbar is not None:
                self.toolbar.removeAction(action)
        self.toolbar = None

    def run(self):
        dialog = GSIDEMDownloaderDialog(self.iface)
        dialog.exec_()
