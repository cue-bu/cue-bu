# -*- coding: utf-8 -*-
"""
GSI DEM Downloader - 国土地理院標高タイルダウンローダー
"""

def classFactory(iface):
    from .plugin import GSIDEMDownloaderPlugin
    return GSIDEMDownloaderPlugin(iface)
