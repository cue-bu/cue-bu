# -*- coding: utf-8 -*-
"""
国土地理院標高タイルのダウンロード・処理ロジック
"""
import math
import os
import struct
import urllib.request
import urllib.error
from typing import Tuple, List, Optional


# 国土地理院 標高タイルのURL
GSI_TILE_URLS = {
    'dem5a': 'https://cyberjapandata.gsi.go.jp/xyz/dem5a/{z}/{x}/{y}.txt',
    'dem5b': 'https://cyberjapandata.gsi.go.jp/xyz/dem5b/{z}/{x}/{y}.txt',
    'dem5c': 'https://cyberjapandata.gsi.go.jp/xyz/dem5c/{z}/{x}/{y}.txt',
    'dem':   'https://cyberjapandata.gsi.go.jp/xyz/dem/{z}/{x}/{y}.txt',
    'demgm': 'https://cyberjapandata.gsi.go.jp/xyz/demgm/{z}/{x}/{y}.txt',
}

GSI_TILE_LABELS = {
    'dem5a': '5mメッシュ（航空レーザ）',
    'dem5b': '5mメッシュ（写真測量）',
    'dem5c': '5mメッシュ（マッチング法）',
    'dem':   '10mメッシュ（標準地図）',
    'demgm': 'グローバル標高（demgm）',
}

# タイルのデフォルトノーデータ値
NODATA_VALUE = -9999.0
TILE_SIZE = 256  # 各タイルは 256x256 ピクセル


def lon_lat_to_tile(lon: float, lat: float, zoom: int) -> Tuple[int, int]:
    """経緯度をタイル座標（x, y）に変換"""
    n = 2 ** zoom
    x = int((lon + 180.0) / 360.0 * n)
    lat_rad = math.radians(lat)
    y = int((1.0 - math.log(math.tan(lat_rad) + 1.0 / math.cos(lat_rad)) / math.pi) / 2.0 * n)
    return x, y


def tile_to_lon_lat(x: int, y: int, zoom: int) -> Tuple[float, float]:
    """タイル座標の左上隅の経緯度を返す"""
    n = 2 ** zoom
    lon = x / n * 360.0 - 180.0
    lat_rad = math.atan(math.sinh(math.pi * (1 - 2 * y / n)))
    lat = math.degrees(lat_rad)
    return lon, lat


def get_tile_bounds(x: int, y: int, zoom: int):
    """タイルのバウンディングボックス（lon_min, lat_min, lon_max, lat_max）を返す"""
    lon_min, lat_max = tile_to_lon_lat(x, y, zoom)
    lon_max, lat_min = tile_to_lon_lat(x + 1, y + 1, zoom)
    return lon_min, lat_min, lon_max, lat_max


def fetch_tile_elevation(x: int, y: int, zoom: int, tile_type: str) -> Optional[List[List[float]]]:
    """
    国土地理院の標高タイル（テキスト形式）を取得し、
    256x256 の標高値グリッド（行リスト）として返す。
    取得失敗またはノーデータの場合は None を返す。
    """
    url = GSI_TILE_URLS[tile_type].format(z=zoom, x=x, y=y)
    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            content = resp.read().decode('utf-8')
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None  # タイルが存在しない（海など）
        raise
    except Exception:
        raise

    rows = []
    for line in content.strip().split('\n'):
        cols = []
        for val in line.split(','):
            val = val.strip()
            if val == 'e':  # ノーデータ
                cols.append(NODATA_VALUE)
            else:
                try:
                    cols.append(float(val))
                except ValueError:
                    cols.append(NODATA_VALUE)
        rows.append(cols)
    return rows


def download_dem(
    lon_min: float, lat_min: float, lon_max: float, lat_max: float,
    zoom: int, tile_type: str, output_path: str,
    progress_callback=None
) -> dict:
    """
    指定した範囲・ズームレベルの標高タイルをダウンロードし、
    GeoTIFF として output_path に保存する。

    Returns:
        dict: {
            'tile_count': ダウンロードタイル数,
            'width': 出力画像幅（px）,
            'height': 出力画像高さ（px）,
            'bbox': (lon_min, lat_min, lon_max, lat_max) 実際のタイル範囲,
        }
    """
    # タイル範囲の計算
    x_min, y_min = lon_lat_to_tile(lon_min, lat_max, zoom)  # 左上
    x_max, y_max = lon_lat_to_tile(lon_max, lat_min, zoom)  # 右下

    # 範囲が逆転しないようにクリップ
    x_min, x_max = min(x_min, x_max), max(x_min, x_max)
    y_min, y_max = min(y_min, y_max), max(y_min, y_max)

    nx = x_max - x_min + 1
    ny = y_max - y_min + 1
    total_tiles = nx * ny
    width = nx * TILE_SIZE
    height = ny * TILE_SIZE

    # 実際のタイル範囲の経緯度
    actual_lon_min, actual_lat_max = tile_to_lon_lat(x_min, y_min, zoom)
    actual_lon_max, actual_lat_min = tile_to_lon_lat(x_max + 1, y_max + 1, zoom)

    # GeoTIFF パラメータ
    pixel_size_x = (actual_lon_max - actual_lon_min) / width
    pixel_size_y = (actual_lat_max - actual_lat_min) / height

    # NumPy を使って配列を確保（QGIS 環境では必ず利用可能）
    try:
        import numpy as np
        data = np.full((height, width), NODATA_VALUE, dtype=np.float32)
        use_numpy = True
    except ImportError:
        use_numpy = False
        data = [[NODATA_VALUE] * width for _ in range(height)]

    downloaded = 0
    for iy, ty in enumerate(range(y_min, y_max + 1)):
        for ix, tx in enumerate(range(x_min, x_max + 1)):
            if progress_callback:
                progress_callback(downloaded, total_tiles, tx, ty)

            try:
                tile_data = fetch_tile_elevation(tx, ty, zoom, tile_type)
            except Exception as e:
                tile_data = None  # エラーはスキップ

            if tile_data is not None:
                row_offset = iy * TILE_SIZE
                col_offset = ix * TILE_SIZE
                if use_numpy:
                    for row_idx, row in enumerate(tile_data[:TILE_SIZE]):
                        for col_idx, val in enumerate(row[:TILE_SIZE]):
                            data[row_offset + row_idx][col_offset + col_idx] = val
                else:
                    for row_idx, row in enumerate(tile_data[:TILE_SIZE]):
                        for col_idx, val in enumerate(row[:TILE_SIZE]):
                            data[row_offset + row_idx][col_offset + col_idx] = val

            downloaded += 1

    if progress_callback:
        progress_callback(total_tiles, total_tiles, -1, -1)

    # GeoTIFF として保存
    _write_geotiff(output_path, data, width, height,
                   actual_lon_min, actual_lat_max,
                   pixel_size_x, pixel_size_y, use_numpy)

    return {
        'tile_count': downloaded,
        'width': width,
        'height': height,
        'bbox': (actual_lon_min, actual_lat_min, actual_lon_max, actual_lat_max),
    }


def _write_geotiff(path, data, width, height,
                   lon_min, lat_max, pixel_size_x, pixel_size_y, use_numpy):
    """
    GDAL を使って GeoTIFF を書き出す。
    GDAL は QGIS 環境では必ず利用可能。
    """
    from osgeo import gdal, osr

    driver = gdal.GetDriverByName('GTiff')
    ds = driver.Create(path, width, height, 1, gdal.GDT_Float32,
                       options=['COMPRESS=LZW', 'PREDICTOR=2', 'TILED=YES'])

    # ジオトランスフォーム設定（左上経度, 解像度X, 回転, 左上緯度, 回転, -解像度Y）
    ds.SetGeoTransform([lon_min, pixel_size_x, 0, lat_max, 0, -pixel_size_y])

    # 座標参照系（WGS84）
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(4326)
    ds.SetProjection(srs.ExportToWkt())

    band = ds.GetRasterBand(1)
    band.SetNoDataValue(NODATA_VALUE)

    if use_numpy:
        import numpy as np
        band.WriteArray(np.array(data, dtype=np.float32))
    else:
        import array as arr
        for row_idx, row in enumerate(data):
            flat = arr.array('f', row)
            band.WriteRaster(0, row_idx, width, 1, flat.tobytes())

    band.FlushCache()
    ds.FlushCache()
    ds = None  # ファイルを閉じる
