# -*- coding: utf-8 -*-
"""
国土地理院 標高DEM ダウンローダー ダイアログ
"""
import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QDoubleSpinBox, QSpinBox, QComboBox,
    QPushButton, QFileDialog, QLineEdit, QProgressBar,
    QGroupBox, QMessageBox, QCheckBox, QSizePolicy
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont, QColor
from qgis.core import (
    QgsProject, QgsRasterLayer, QgsMapLayer,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsRectangle
)
from .downloader import (
    download_dem, GSI_TILE_LABELS, GSI_TILE_URLS,
    lon_lat_to_tile
)


class DownloadWorker(QThread):
    """バックグラウンドでダウンロードを実行するスレッド"""
    progress = pyqtSignal(int, int, int, int)   # done, total, tx, ty
    finished = pyqtSignal(dict)                  # result info
    error = pyqtSignal(str)                      # error message

    def __init__(self, params):
        super().__init__()
        self.params = params

    def run(self):
        try:
            result = download_dem(
                lon_min=self.params['lon_min'],
                lat_min=self.params['lat_min'],
                lon_max=self.params['lon_max'],
                lat_max=self.params['lat_max'],
                zoom=self.params['zoom'],
                tile_type=self.params['tile_type'],
                output_path=self.params['output_path'],
                progress_callback=lambda done, total, tx, ty:
                    self.progress.emit(done, total, tx, ty)
            )
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))


class GSIDEMDownloaderDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.worker = None
        self.setWindowTitle('国土地理院 標高DEM ダウンローダー')
        self.setMinimumWidth(480)
        self._build_ui()

    def _build_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(12)
        main_layout.setContentsMargins(16, 16, 16, 16)

        # ── タイトル ──────────────────────────────────────
        title = QLabel('🗾 国土地理院 標高タイル DEM ダウンローダー')
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(12)
        title.setFont(title_font)
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)

        # ── 取得範囲 ──────────────────────────────────────
        extent_group = QGroupBox('取得範囲（地理座標系 / WGS84）')
        extent_layout = QGridLayout(extent_group)

        self.lat_max_spin = self._make_lat_spin()
        self.lat_min_spin = self._make_lat_spin()
        self.lon_min_spin = self._make_lon_spin()
        self.lon_max_spin = self._make_lon_spin()

        extent_layout.addWidget(QLabel('北緯（最大）:'), 0, 0)
        extent_layout.addWidget(self.lat_max_spin, 0, 1)
        extent_layout.addWidget(QLabel('南緯（最小）:'), 1, 0)
        extent_layout.addWidget(self.lat_min_spin, 1, 1)
        extent_layout.addWidget(QLabel('西経（最小）:'), 2, 0)
        extent_layout.addWidget(self.lon_min_spin, 2, 1)
        extent_layout.addWidget(QLabel('東経（最大）:'), 3, 0)
        extent_layout.addWidget(self.lon_max_spin, 3, 1)

        # マップキャンバスから範囲を取得
        btn_from_canvas = QPushButton('📐 マップキャンバスから範囲取得')
        btn_from_canvas.clicked.connect(self._load_from_canvas)
        extent_layout.addWidget(btn_from_canvas, 4, 0, 1, 2)

        # アクティブレイヤーから範囲を取得
        btn_from_layer = QPushButton('📦 アクティブレイヤーから範囲取得')
        btn_from_layer.clicked.connect(self._load_from_layer)
        extent_layout.addWidget(btn_from_layer, 5, 0, 1, 2)

        main_layout.addWidget(extent_group)

        # ── タイル設定 ──────────────────────────────────────
        tile_group = QGroupBox('タイル設定')
        tile_layout = QGridLayout(tile_group)

        # タイル種別
        tile_layout.addWidget(QLabel('標高データ種別:'), 0, 0)
        self.tile_type_combo = QComboBox()
        for key, label in GSI_TILE_LABELS.items():
            self.tile_type_combo.addItem(f'{label}  [{key}]', key)
        self.tile_type_combo.setCurrentIndex(3)  # dem (10m) をデフォルト
        tile_layout.addWidget(self.tile_type_combo, 0, 1)

        # ズームレベル
        tile_layout.addWidget(QLabel('ズームレベル:'), 1, 0)
        zoom_h = QHBoxLayout()
        self.zoom_spin = QSpinBox()
        self.zoom_spin.setRange(1, 18)
        self.zoom_spin.setValue(14)
        self.zoom_spin.valueChanged.connect(self._update_tile_count)
        zoom_h.addWidget(self.zoom_spin)
        self.tile_count_label = QLabel('')
        zoom_h.addWidget(self.tile_count_label)
        tile_layout.addLayout(zoom_h, 1, 1)

        # ズームレベルの説明
        zoom_hint = QLabel(
            'ヒント: dem5a/b/c → ズーム15〜18推奨  /  dem → ズーム14推奨  /  demgm → ズーム5〜8推奨'
        )
        zoom_hint.setStyleSheet('color: gray; font-size: 10px;')
        zoom_hint.setWordWrap(True)
        tile_layout.addWidget(zoom_hint, 2, 0, 1, 2)

        main_layout.addWidget(tile_group)

        # ── 出力設定 ──────────────────────────────────────
        output_group = QGroupBox('出力設定')
        output_layout = QGridLayout(output_group)

        output_layout.addWidget(QLabel('保存先ファイル:'), 0, 0)
        out_h = QHBoxLayout()
        self.output_edit = QLineEdit()
        self.output_edit.setPlaceholderText('出力 GeoTIFF ファイルパス (.tif)')
        out_h.addWidget(self.output_edit)
        btn_browse = QPushButton('...')
        btn_browse.setFixedWidth(32)
        btn_browse.clicked.connect(self._browse_output)
        out_h.addWidget(btn_browse)
        output_layout.addLayout(out_h, 0, 1)

        self.add_layer_cb = QCheckBox('ダウンロード完了後にQGISレイヤーとして追加')
        self.add_layer_cb.setChecked(True)
        output_layout.addWidget(self.add_layer_cb, 1, 0, 1, 2)

        main_layout.addWidget(output_group)

        # ── プログレス ──────────────────────────────────────
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)

        self.status_label = QLabel('')
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet('color: #555;')
        main_layout.addWidget(self.status_label)

        # ── ボタン ──────────────────────────────────────
        btn_h = QHBoxLayout()
        self.download_btn = QPushButton('⬇️  DEM をダウンロード')
        self.download_btn.setFixedHeight(36)
        font = self.download_btn.font()
        font.setBold(True)
        self.download_btn.setFont(font)
        self.download_btn.setStyleSheet(
            'QPushButton { background-color: #2d7a3c; color: white; border-radius: 4px; }'
            'QPushButton:hover { background-color: #3a9b4f; }'
            'QPushButton:disabled { background-color: #aaa; }'
        )
        self.download_btn.clicked.connect(self._start_download)
        btn_h.addWidget(self.download_btn)

        close_btn = QPushButton('閉じる')
        close_btn.setFixedHeight(36)
        close_btn.clicked.connect(self.close)
        btn_h.addWidget(close_btn)
        main_layout.addLayout(btn_h)

        # 初期値をセット（日本付近）
        self.lat_max_spin.setValue(36.0)
        self.lat_min_spin.setValue(35.5)
        self.lon_min_spin.setValue(139.5)
        self.lon_max_spin.setValue(140.0)
        self._update_tile_count()

        # スピンボックスの変更でタイル数を更新
        for sp in [self.lat_max_spin, self.lat_min_spin,
                   self.lon_min_spin, self.lon_max_spin]:
            sp.valueChanged.connect(self._update_tile_count)

    # ── ヘルパー ───────────────────────────────────────────

    def _make_lat_spin(self):
        sp = QDoubleSpinBox()
        sp.setRange(-90.0, 90.0)
        sp.setDecimals(6)
        sp.setSingleStep(0.1)
        return sp

    def _make_lon_spin(self):
        sp = QDoubleSpinBox()
        sp.setRange(-180.0, 180.0)
        sp.setDecimals(6)
        sp.setSingleStep(0.1)
        return sp

    def _update_tile_count(self):
        try:
            zoom = self.zoom_spin.value()
            lon_min = self.lon_min_spin.value()
            lat_min = self.lat_min_spin.value()
            lon_max = self.lon_max_spin.value()
            lat_max = self.lat_max_spin.value()

            from .downloader import lon_lat_to_tile
            x_min, y_min = lon_lat_to_tile(lon_min, lat_max, zoom)
            x_max, y_max = lon_lat_to_tile(lon_max, lat_min, zoom)
            x_min, x_max = min(x_min, x_max), max(x_min, x_max)
            y_min, y_max = min(y_min, y_max), max(y_min, y_max)
            nx = x_max - x_min + 1
            ny = y_max - y_min + 1
            total = nx * ny
            px = nx * 256
            py = ny * 256
            self.tile_count_label.setText(
                f'→ {nx}×{ny} = {total}タイル（{px}×{py} px）'
            )
            if total > 500:
                self.tile_count_label.setStyleSheet('color: red; font-weight: bold;')
            elif total > 100:
                self.tile_count_label.setStyleSheet('color: orange;')
            else:
                self.tile_count_label.setStyleSheet('color: #2d7a3c;')
        except Exception:
            pass

    def _load_from_canvas(self):
        """マップキャンバスの現在表示範囲を取得"""
        canvas = self.iface.mapCanvas()
        extent = canvas.extent()
        crs = canvas.mapSettings().destinationCrs()
        wgs84 = QgsCoordinateReferenceSystem('EPSG:4326')
        transform = QgsCoordinateTransform(crs, wgs84, QgsProject.instance())
        rect = transform.transformBoundingBox(extent)
        self._set_extent(rect.xMinimum(), rect.yMinimum(),
                         rect.xMaximum(), rect.yMaximum())

    def _load_from_layer(self):
        """アクティブレイヤーの範囲を取得"""
        layer = self.iface.activeLayer()
        if layer is None:
            QMessageBox.warning(self, '警告', 'アクティブなレイヤーがありません。')
            return
        extent = layer.extent()
        crs = layer.crs()
        wgs84 = QgsCoordinateReferenceSystem('EPSG:4326')
        transform = QgsCoordinateTransform(crs, wgs84, QgsProject.instance())
        rect = transform.transformBoundingBox(extent)
        self._set_extent(rect.xMinimum(), rect.yMinimum(),
                         rect.xMaximum(), rect.yMaximum())

    def _set_extent(self, lon_min, lat_min, lon_max, lat_max):
        self.lon_min_spin.setValue(lon_min)
        self.lat_min_spin.setValue(lat_min)
        self.lon_max_spin.setValue(lon_max)
        self.lat_max_spin.setValue(lat_max)

    def _browse_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self, '出力ファイルを選択', '', 'GeoTIFF (*.tif *.tiff)'
        )
        if path:
            if not path.endswith('.tif') and not path.endswith('.tiff'):
                path += '.tif'
            self.output_edit.setText(path)

    # ── ダウンロード ──────────────────────────────────────

    def _start_download(self):
        lon_min = self.lon_min_spin.value()
        lat_min = self.lat_min_spin.value()
        lon_max = self.lon_max_spin.value()
        lat_max = self.lat_max_spin.value()
        zoom = self.zoom_spin.value()
        tile_type = self.tile_type_combo.currentData()
        output_path = self.output_edit.text().strip()

        # バリデーション
        if lon_min >= lon_max or lat_min >= lat_max:
            QMessageBox.critical(self, 'エラー', '範囲が不正です。経緯度の最小・最大値を確認してください。')
            return
        if not output_path:
            QMessageBox.critical(self, 'エラー', '出力ファイルパスを指定してください。')
            return

        # タイル数の確認
        from .downloader import lon_lat_to_tile
        x_min, y_min = lon_lat_to_tile(lon_min, lat_max, zoom)
        x_max, y_max = lon_lat_to_tile(lon_max, lat_min, zoom)
        total_tiles = (abs(x_max - x_min) + 1) * (abs(y_max - y_min) + 1)
        if total_tiles > 500:
            reply = QMessageBox.question(
                self, '確認',
                f'{total_tiles} タイルのダウンロードには時間がかかる場合があります。続行しますか？',
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return

        # UI を無効化
        self.download_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setMaximum(total_tiles)
        self.progress_bar.setValue(0)
        self.status_label.setText('ダウンロード中...')

        params = {
            'lon_min': lon_min, 'lat_min': lat_min,
            'lon_max': lon_max, 'lat_max': lat_max,
            'zoom': zoom, 'tile_type': tile_type,
            'output_path': output_path,
        }
        self.worker = DownloadWorker(params)
        self.worker.progress.connect(self._on_progress)
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.start()

    def _on_progress(self, done, total, tx, ty):
        self.progress_bar.setValue(done)
        if tx >= 0:
            self.status_label.setText(f'タイル取得中: {done}/{total}  (x={tx}, y={ty})')

    def _on_finished(self, result):
        self.progress_bar.setValue(self.progress_bar.maximum())
        self.download_btn.setEnabled(True)
        self.status_label.setText(
            f'完了: {result["tile_count"]} タイル / {result["width"]}×{result["height"]} px'
        )

        output_path = self.output_edit.text().strip()
        if self.add_layer_cb.isChecked() and os.path.exists(output_path):
            layer_name = os.path.splitext(os.path.basename(output_path))[0]
            layer = QgsRasterLayer(output_path, layer_name)
            if layer.isValid():
                QgsProject.instance().addMapLayer(layer)
                self.status_label.setText(
                    self.status_label.text() + '  → レイヤーを追加しました'
                )

        QMessageBox.information(
            self, 'ダウンロード完了',
            f'DEM画像を保存しました:\n{output_path}\n\n'
            f'タイル数: {result["tile_count"]}\n'
            f'画像サイズ: {result["width"]} × {result["height"]} px\n'
            f'範囲: 経度 {result["bbox"][0]:.4f}〜{result["bbox"][2]:.4f}\n'
            f'　　　緯度 {result["bbox"][1]:.4f}〜{result["bbox"][3]:.4f}'
        )

    def _on_error(self, msg):
        self.download_btn.setEnabled(True)
        self.progress_bar.setVisible(False)
        self.status_label.setText('エラーが発生しました')
        QMessageBox.critical(self, 'エラー', f'ダウンロードに失敗しました:\n{msg}')
