from PIL import Image

# 画像を読み込み
img = Image.open("loop_save_shp.png")

# リサイズ後のサイズ (幅, 高さ)
new_size = (512, 512)

# リサイズ
img_resized = img.resize(new_size, Image.BILINEAR)

# 保存
img_resized.save("re_loop_save_shp.png")
