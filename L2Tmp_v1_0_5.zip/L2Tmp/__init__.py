# -*- coding: utf-8 -*-

def classFactory(iface):
    from .l2tmp_plugin import L2TmpPlugin
    return L2TmpPlugin(iface)
