# -*- coding: utf-8 -*-
"""
L2Tmp - Load saved layers as temporary layers for QGIS.

Vector layers are converted to QGIS memory layers.
Raster layers are converted to temporary raster files, preferably GeoTIFF via GDAL Translate.
Original layers can be removed from the QGIS project. Source files are never deleted.
"""

import os
import re
import shutil
import tempfile
import traceback

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QAction,
    QButtonGroup,
    QCheckBox,
    QDialog,
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QMessageBox,
    QPushButton,
    QProgressDialog,
    QToolButton,
    QRadioButton,
    QTextEdit,
    QVBoxLayout,
    QApplication,
    QWidget,
    QToolBar,
)

from qgis.core import (
    QgsFeature,
    QgsMapLayer,
    QgsMapLayerStyle,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
    QgsWkbTypes,
)


PLUGIN_NAME = "L2Tmp"
PLUGIN_VERSION = "1.0.5"


VECTOR_EXTS = {
    ".shp", ".gpkg", ".geojson", ".json", ".csv", ".kml", ".gml",
    ".fgb", ".dxf", ".tab", ".mif", ".sqlite", ".db", ".gpkg.zip"
}

RASTER_EXTS = {
    ".tif", ".tiff", ".vrt", ".img", ".asc", ".bil", ".jp2", ".j2k",
    ".png", ".jpg", ".jpeg", ".bmp", ".gif", ".dem", ".nc", ".grd"
}

SKIP_EXTS = {
    ".dbf", ".shx", ".prj", ".qpj", ".cpg", ".sbn", ".sbx", ".qix",
    ".tfw", ".jgw", ".pgw", ".bpw", ".wld", ".aux", ".ovr", ".xml",
    ".qml", ".sld", ".ini", ".txt", ".csvt"
}


class L2TmpDialog(QDialog):
    def __init__(self, plugin, parent=None):
        super().__init__(parent)
        self.plugin = plugin
        self.setWindowTitle("{} v{} - 保存データを一時レイヤ化".format(PLUGIN_NAME, PLUGIN_VERSION))
        self.resize(720, 680)
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)

        intro = QLabel(
            "保存済みのベクタ/ラスタを読み込み、全レイヤまたは選択レイヤを一時レイヤ化します。\n"
            "ベクタはメモリレイヤ、ラスタは一時ファイルとして作成します。元ファイルは削除しません。"
        )
        intro.setWordWrap(True)
        root.addWidget(intro)

        self.source_toggle_btn = QToolButton()
        self.source_toggle_btn.setText("▶ ファイル／フォルダから読み込む（任意）")
        self.source_toggle_btn.setCheckable(True)
        self.source_toggle_btn.setChecked(False)
        self.source_toggle_btn.setToolButtonStyle(Qt.ToolButtonTextOnly)
        root.addWidget(self.source_toggle_btn)

        src_group = QGroupBox("読み込み元")
        self.source_group = src_group
        src_layout = QVBoxLayout(src_group)
        src_note = QLabel(
            "ここにファイル／フォルダを追加した場合は、それらを読み込んでから一時レイヤ化します。\n"
            "空欄のまま実行した場合は、現在のプロジェクトにあるレイヤを対象にします。"
        )
        src_note.setWordWrap(True)
        src_layout.addWidget(src_note)

        self.path_list = QListWidget()
        src_layout.addWidget(self.path_list)

        btn_row = QHBoxLayout()
        self.add_files_btn = QPushButton("ファイルを追加")
        self.add_folder_btn = QPushButton("フォルダを追加")
        self.remove_path_btn = QPushButton("選択を削除")
        self.clear_path_btn = QPushButton("クリア")
        for b in (self.add_files_btn, self.add_folder_btn, self.remove_path_btn, self.clear_path_btn):
            btn_row.addWidget(b)
        src_layout.addLayout(btn_row)
        self.source_group.setVisible(False)
        root.addWidget(src_group)

        opt_group = QGroupBox("オプション")
        opt_layout = QVBoxLayout(opt_group)

        self.new_project_cb = QCheckBox("新規プロジェクトにしてから読み込む")
        self.new_project_cb.setChecked(True)
        self.recursive_cb = QCheckBox("フォルダ内を再帰的に検索する")
        self.recursive_cb.setChecked(False)
        self.copy_style_cb = QCheckBox("スタイルを引き継ぐ")
        self.copy_style_cb.setChecked(True)
        self.remove_original_cb = QCheckBox("一時レイヤ化後に元レイヤをプロジェクトから削除する（元ファイルは削除しない）")
        self.remove_original_cb.setChecked(True)
        self.suffix_cb = QCheckBox("一時レイヤ名の末尾に _tmp を付ける")
        self.suffix_cb.setChecked(False)

        self.convert_vector_cb = QCheckBox("ベクタをメモリレイヤ化する")
        self.convert_vector_cb.setChecked(True)
        self.convert_raster_cb = QCheckBox("ラスタを一時ファイル化する")
        self.convert_raster_cb.setChecked(True)

        for cb in (
            self.new_project_cb,
            self.recursive_cb,
            self.convert_vector_cb,
            self.convert_raster_cb,
            self.copy_style_cb,
            self.remove_original_cb,
            self.suffix_cb,
        ):
            opt_layout.addWidget(cb)
        root.addWidget(opt_group)

        target_group = QGroupBox("一時レイヤ化する対象")
        target_layout = QVBoxLayout(target_group)
        self.all_layers_rb = QRadioButton("すべてのレイヤ")
        self.selected_layers_rb = QRadioButton("レイヤパネルで選択中のレイヤのみ")
        self.all_layers_rb.setChecked(True)
        self.target_button_group = QButtonGroup(self)
        self.target_button_group.addButton(self.all_layers_rb)
        self.target_button_group.addButton(self.selected_layers_rb)
        target_layout.addWidget(self.all_layers_rb)
        target_layout.addWidget(self.selected_layers_rb)
        root.addWidget(target_group)

        note = QLabel(
            "※「元レイヤを削除」はQGISのレイヤパネルから外すだけです。ディスク上のshp/gpkg/tif等は削除しません。\n"
            "※巨大ラスタは一時ファイル作成に時間がかかる場合があります。"
        )
        note.setWordWrap(True)
        root.addWidget(note)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(130)
        root.addWidget(self.log)

        bottom = QHBoxLayout()
        self.copy_log_btn = QPushButton("ログをコピー")
        bottom.addWidget(self.copy_log_btn)
        bottom.addStretch(1)
        self.run_btn = QPushButton("実行")
        self.close_btn = QPushButton("閉じる")
        bottom.addWidget(self.run_btn)
        bottom.addWidget(self.close_btn)
        root.addLayout(bottom)

        self.source_toggle_btn.toggled.connect(self.set_source_expanded)
        self.add_files_btn.clicked.connect(self.add_files)
        self.add_folder_btn.clicked.connect(self.add_folder)
        self.remove_path_btn.clicked.connect(self.remove_selected_paths)
        self.clear_path_btn.clicked.connect(self.path_list.clear)
        self.copy_log_btn.clicked.connect(self.copy_log_to_clipboard)
        self.run_btn.clicked.connect(self.run)
        self.close_btn.clicked.connect(self.close)

    def set_source_expanded(self, checked):
        self.source_group.setVisible(checked)
        if checked:
            self.source_toggle_btn.setText("▼ ファイル／フォルダから読み込む（任意）")
        else:
            self.source_toggle_btn.setText("▶ ファイル／フォルダから読み込む（任意）")

    def append_log(self, text):
        self.log.append(text)

    def copy_log_to_clipboard(self):
        text = self.log.toPlainText()
        QApplication.clipboard().setText(text)
        if text.strip():
            QMessageBox.information(self, PLUGIN_NAME, "ログをクリップボードにコピーしました。")
        else:
            QMessageBox.information(self, PLUGIN_NAME, "コピーできるログがありません。")

    def add_files(self):
        filters = (
            "GISデータ (*.shp *.gpkg *.geojson *.json *.csv *.kml *.gml *.fgb *.dxf "
            "*.tif *.tiff *.vrt *.img *.asc *.bil *.jp2 *.png *.jpg *.jpeg *.dem *.nc);;"
            "すべてのファイル (*.*)"
        )
        files, _ = QFileDialog.getOpenFileNames(self, "読み込むファイルを選択", "", filters)
        for p in files:
            self._add_path_item(p)

    def add_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "読み込むフォルダを選択", "")
        if folder:
            self._add_path_item(folder)

    def _add_path_item(self, path):
        path = os.path.normpath(path)
        existing = {self.path_list.item(i).text() for i in range(self.path_list.count())}
        if path not in existing:
            self.path_list.addItem(path)

    def remove_selected_paths(self):
        for item in self.path_list.selectedItems():
            self.path_list.takeItem(self.path_list.row(item))

    def options(self):
        paths = [self.path_list.item(i).text() for i in range(self.path_list.count())]
        return {
            "paths": paths,
            "new_project": self.new_project_cb.isChecked(),
            "recursive": self.recursive_cb.isChecked(),
            "selected_only": self.selected_layers_rb.isChecked(),
            "copy_style": self.copy_style_cb.isChecked(),
            "remove_original": self.remove_original_cb.isChecked(),
            "suffix_tmp": self.suffix_cb.isChecked(),
            "convert_vector": self.convert_vector_cb.isChecked(),
            "convert_raster": self.convert_raster_cb.isChecked(),
        }

    def run(self):
        self.log.clear()
        opts = self.options()
        try:
            result = self.plugin.execute(opts, self)
            self.append_log("")
            self.append_log("完了しました。")
            self.append_log("読み込み: {} レイヤ".format(result.get("loaded", 0)))
            self.append_log("一時化: {} レイヤ".format(result.get("converted", 0)))
            self.append_log("スキップ: {} レイヤ".format(result.get("skipped", 0)))
        except Exception as e:
            self.append_log("エラー: {}".format(e))
            self.append_log(traceback.format_exc())
            QMessageBox.critical(self, PLUGIN_NAME, "処理中にエラーが発生しました。\n\n{}".format(e))


class L2TmpPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None
        self.temp_dirs = []
        self.toolbar_name = "拡張機能"
        self.toolbar = None

    def initGui(self):
        icon = QIcon(os.path.join(self.plugin_dir, "icon.png"))
        self.action = QAction(icon, "L2Tmp - 保存データを一時レイヤ化", self.iface.mainWindow())
        self.action.triggered.connect(self.show_dialog)
        self.iface.addPluginToMenu("&L2Tmp", self.action)

        # layer2shp と同じ共有ツールバー「拡張機能」に追加します。
        self.toolbar = self.iface.mainWindow().findChild(QToolBar, self.toolbar_name)
        if self.toolbar is None:
            self.toolbar = self.iface.addToolBar(self.toolbar_name)
            self.toolbar.setObjectName(self.toolbar_name)
        self.toolbar.addAction(self.action)
        self.toolbar.setVisible(True)

    def unload(self):
        if self.action is not None:
            self.iface.removePluginMenu("&L2Tmp", self.action)
            if self.toolbar is not None:
                self.toolbar.removeAction(self.action)
            self.action = None
        self.toolbar = None

    def show_dialog(self):
        if self.dialog is None:
            self.dialog = L2TmpDialog(self, self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

    def execute(self, opts, dlg=None):
        project = QgsProject.instance()
        paths = opts.get("paths") or []

        # 「新規プロジェクトにしてから読み込む」は、読み込み元が指定されている場合だけ有効にします。
        # 読み込み元が空欄の場合は、現在のプロジェクトのレイヤをそのまま対象にします。
        if opts.get("new_project") and paths:
            answer = QMessageBox.question(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                "現在のプロジェクトをクリアして新規プロジェクトにします。\n保存していない変更がある場合は、先に保存してください。\n\n続行しますか？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if answer != QMessageBox.Yes:
                raise RuntimeError("キャンセルしました。")
            project.clear()

        loaded_layers = []
        if paths:
            loaded_layers = self._load_paths(paths, opts.get("recursive", False), dlg)

        if opts.get("selected_only"):
            source_layers = self.iface.layerTreeView().selectedLayers()
        else:
            source_layers = loaded_layers if loaded_layers else list(project.mapLayers().values())

        # Remove duplicates while preserving order.
        unique_layers = []
        seen_ids = set()
        for lyr in source_layers:
            if lyr and lyr.id() not in seen_ids:
                seen_ids.add(lyr.id())
                unique_layers.append(lyr)
        source_layers = unique_layers

        if not source_layers:
            raise RuntimeError("対象レイヤがありません。")

        progress = QProgressDialog("一時レイヤ化しています...", "キャンセル", 0, len(source_layers), self.iface.mainWindow())
        progress.setWindowModality(Qt.WindowModal)
        progress.show()

        converted = 0
        skipped = 0
        for idx, layer in enumerate(source_layers, start=1):
            if progress.wasCanceled():
                break

            # 元レイヤを削除すると、PyQGIS 側の QgsVectorLayer/QgsRasterLayer ラッパーも
            # 無効化されることがあります。削除後に layer.name() などを呼ぶと、
            # "wrapped C/C++ object ... has been deleted" になるため、必要な情報は先に退避します。
            try:
                layer_name = layer.name()
                layer_type = layer.type()
            except Exception:
                skipped += 1
                self._log(dlg, "スキップ（参照できないレイヤ）")
                continue

            progress.setValue(idx - 1)
            progress.setLabelText("処理中: {}".format(layer_name))

            try:
                if layer_type == QgsMapLayer.VectorLayer:
                    if not opts.get("convert_vector", True):
                        skipped += 1
                        self._log(dlg, "スキップ（ベクタ無効）: {}".format(layer_name))
                        continue
                    tmp = self._vector_to_memory(layer, opts)
                    self._insert_temp_layer(layer, tmp, opts.get("remove_original", True))
                    converted += 1
                    self._log(dlg, "ベクタ一時化: {}".format(layer_name))
                elif layer_type == QgsMapLayer.RasterLayer:
                    if self._is_raster_service_layer(layer):
                        skipped += 1
                        self._log(dlg, "スキップ（配信タイル／WMS等のため保持）: {}".format(layer_name))
                        continue
                    if not opts.get("convert_raster", True):
                        skipped += 1
                        self._log(dlg, "スキップ（ラスタ無効）: {}".format(layer_name))
                        continue
                    tmp = self._raster_to_temp_file(layer, opts)
                    self._insert_temp_layer(layer, tmp, opts.get("remove_original", True))
                    converted += 1
                    self._log(dlg, "ラスタ一時化: {}".format(layer_name))
                else:
                    skipped += 1
                    self._log(dlg, "スキップ（未対応）: {}".format(layer_name))
            except Exception as e:
                skipped += 1
                self._log(dlg, "失敗: {} / {}".format(layer_name, e))
                self._log(dlg, traceback.format_exc())

        progress.setValue(len(source_layers))
        return {"loaded": len(loaded_layers), "converted": converted, "skipped": skipped}

    def _log(self, dlg, text):
        if dlg is not None:
            dlg.append_log(text)

    def _load_paths(self, paths, recursive=False, dlg=None):
        files = []
        for p in paths:
            if os.path.isdir(p):
                files.extend(self._collect_files(p, recursive))
            elif os.path.isfile(p):
                files.append(p)
            else:
                self._log(dlg, "存在しないためスキップ: {}".format(p))

        loaded = []
        for f in files:
            try:
                new_layers = self._load_single_file(f, dlg)
                loaded.extend(new_layers)
            except Exception as e:
                self._log(dlg, "読み込み失敗: {} / {}".format(f, e))
        return loaded

    def _collect_files(self, folder, recursive=False):
        found = []
        if recursive:
            walker = os.walk(folder)
        else:
            walker = [(folder, [], os.listdir(folder))]

        for root, _dirs, filenames in walker:
            for fn in filenames:
                path = os.path.join(root, fn)
                lower = fn.lower()
                ext = os.path.splitext(lower)[1]
                if lower.endswith(".aux.xml"):
                    continue
                if ext in SKIP_EXTS:
                    continue
                if ext in VECTOR_EXTS or ext in RASTER_EXTS:
                    found.append(path)
        return found

    def _load_single_file(self, path, dlg=None):
        ext = os.path.splitext(path.lower())[1]
        base = os.path.splitext(os.path.basename(path))[0]
        loaded = []

        if ext == ".gpkg":
            # First try vector sublayers in GeoPackage.
            gpkg_layers = self._load_gpkg_vector_layers(path, dlg)
            loaded.extend(gpkg_layers)
            if loaded:
                return loaded
            # If no vector layers are found, try as raster.

        if ext in VECTOR_EXTS:
            layer = QgsVectorLayer(path, base, "ogr")
            if layer.isValid():
                QgsProject.instance().addMapLayer(layer)
                self._log(dlg, "読み込み: {}".format(layer.name()))
                return [layer]

        if ext in RASTER_EXTS or ext == ".gpkg":
            layer = QgsRasterLayer(path, base)
            if layer.isValid():
                QgsProject.instance().addMapLayer(layer)
                self._log(dlg, "読み込み: {}".format(layer.name()))
                return [layer]

        # Fallback: try vector, then raster.
        v = QgsVectorLayer(path, base, "ogr")
        if v.isValid():
            QgsProject.instance().addMapLayer(v)
            self._log(dlg, "読み込み: {}".format(v.name()))
            return [v]

        r = QgsRasterLayer(path, base)
        if r.isValid():
            QgsProject.instance().addMapLayer(r)
            self._log(dlg, "読み込み: {}".format(r.name()))
            return [r]

        raise RuntimeError("QGISで読み込めませんでした。")

    def _load_gpkg_vector_layers(self, path, dlg=None):
        loaded = []
        try:
            from osgeo import ogr
        except Exception:
            # Fallback: QGIS/OGR may still open the first/default layer.
            base = os.path.splitext(os.path.basename(path))[0]
            lyr = QgsVectorLayer(path, base, "ogr")
            if lyr.isValid():
                QgsProject.instance().addMapLayer(lyr)
                return [lyr]
            return []

        ds = ogr.Open(path)
        if ds is None:
            return []
        for i in range(ds.GetLayerCount()):
            ogr_layer = ds.GetLayerByIndex(i)
            if ogr_layer is None:
                continue
            name = ogr_layer.GetName()
            uri = "{}|layername={}".format(path, name)
            qgs_layer = QgsVectorLayer(uri, name, "ogr")
            if qgs_layer.isValid():
                QgsProject.instance().addMapLayer(qgs_layer)
                loaded.append(qgs_layer)
                self._log(dlg, "読み込み: {}".format(qgs_layer.name()))
        return loaded

    def _vector_to_memory(self, src, opts):
        geom = self._memory_geometry_string(src)
        name = self._temporary_name(src.name(), opts)
        uri = geom
        if src.crs().isValid() and src.crs().authid():
            uri += "?crs={}".format(src.crs().authid())
        tmp = QgsVectorLayer(uri, name, "memory")
        if not tmp.isValid():
            # Some unusual WKB strings may not be accepted by the memory provider.
            fallback_geom = QgsWkbTypes.geometryDisplayString(src.geometryType())
            if src.wkbType() == QgsWkbTypes.NoGeometry:
                fallback_geom = "None"
            tmp = QgsVectorLayer(fallback_geom, name, "memory")
        if not tmp.isValid():
            raise RuntimeError("メモリレイヤを作成できませんでした。")

        if src.crs().isValid():
            tmp.setCrs(src.crs())

        provider = tmp.dataProvider()
        fields = [f for f in src.fields()]
        if fields:
            provider.addAttributes(fields)
            tmp.updateFields()

        batch = []
        tmp_fields = tmp.fields()
        for feat in src.getFeatures():
            new_feat = QgsFeature(tmp_fields)
            if feat.hasGeometry():
                new_feat.setGeometry(feat.geometry())
            new_feat.setAttributes(feat.attributes())
            batch.append(new_feat)
            if len(batch) >= 5000:
                provider.addFeatures(batch)
                batch = []
        if batch:
            provider.addFeatures(batch)

        tmp.updateExtents()
        tmp.setCustomProperty("L2Tmp/sourceLayerId", src.id())
        tmp.setCustomProperty("L2Tmp/source", src.source())
        tmp.setCustomProperty("skipMemoryLayersCheck", 1)

        if opts.get("copy_style", True):
            self._copy_style(src, tmp)
        return tmp

    def _memory_geometry_string(self, layer):
        if layer.wkbType() == QgsWkbTypes.NoGeometry:
            return "None"
        text = QgsWkbTypes.displayString(layer.wkbType())
        if not text:
            text = QgsWkbTypes.geometryDisplayString(layer.geometryType())
        return text or "None"

    def _is_raster_service_layer(self, layer):
        """Return True for XYZ/WMS/WMTS/remote tile style raster layers that should be preserved."""
        try:
            provider = (layer.providerType() or "").lower()
        except Exception:
            provider = ""
        try:
            source = (layer.source() or "").lower()
        except Exception:
            source = ""

        service_providers = {"wms", "xyz", "arcgismapserver"}
        if provider in service_providers:
            return True

        service_tokens = (
            "type=xyz",
            "service=wmts",
            "tilematrixset",
            "tilematrix=",
            "tileserver",
            "{x}",
            "{y}",
            "{z}",
        )
        if any(token in source for token in service_tokens):
            return True

        # WMS/WMTS provider URIs often include a URL and layer parameters, even when providerType()
        # cannot be read for some reason. Keep them as-is instead of trying to make a GeoTIFF.
        if ("url=http" in source or "url=https" in source) and ("layers=" in source or "styles=" in source):
            return True

        # If it is clearly a remote URL, do not treat it like a local raster file.
        if source.startswith("http://") or source.startswith("https://"):
            return True

        return False

    def _raster_to_temp_file(self, src, opts):
        name = self._temporary_name(src.name(), opts)
        temp_dir = tempfile.mkdtemp(prefix="l2tmp_raster_")
        self.temp_dirs.append(temp_dir)
        out_path = os.path.join(temp_dir, self._safe_filename(name) + ".tif")

        made = False
        translate_error = None

        # Prefer GDAL Translate because this disconnects the layer from the original raster source.
        try:
            import processing
            params = {
                "INPUT": src,
                "TARGET_CRS": None,
                "NODATA": None,
                "COPY_SUBDATASETS": False,
                "OPTIONS": "",
                "EXTRA": "",
                "DATA_TYPE": 0,
                "OUTPUT": out_path,
            }
            processing.run("gdal:translate", params)
            made = os.path.exists(out_path)
        except Exception as e:
            translate_error = e
            made = False

        if not made:
            # Fallback for environments where Processing/GDAL Translate is unavailable.
            out_path = self._copy_raster_source_to_temp(src, temp_dir)
            if not out_path:
                raise RuntimeError("ラスタ一時ファイルを作成できませんでした: {}".format(translate_error))

        tmp = QgsRasterLayer(out_path, name)
        if not tmp.isValid():
            raise RuntimeError("作成した一時ラスタを読み込めませんでした: {}".format(out_path))

        tmp.setCustomProperty("L2Tmp/sourceLayerId", src.id())
        tmp.setCustomProperty("L2Tmp/source", src.source())
        tmp.setCustomProperty("L2Tmp/tempPath", out_path)

        if opts.get("copy_style", True):
            self._copy_style(src, tmp)
        return tmp

    def _copy_raster_source_to_temp(self, src_layer, temp_dir):
        src_path = self._local_source_path(src_layer.source())
        if not src_path or not os.path.exists(src_path):
            return None
        base = os.path.basename(src_path)
        out_path = os.path.join(temp_dir, base)
        shutil.copy2(src_path, out_path)

        # Copy common raster sidecars when they exist.
        root, ext = os.path.splitext(src_path)
        sidecars = [
            ".tfw", ".tifw", ".jgw", ".jpgw", ".pgw", ".pngw", ".bpw", ".wld",
            ".prj", ".qpj", ".aux.xml", ".ovr", ".xml",
        ]
        for suffix in sidecars:
            s = root + suffix
            if os.path.exists(s):
                try:
                    shutil.copy2(s, os.path.join(temp_dir, os.path.basename(s)))
                except Exception:
                    pass
        return out_path

    def _local_source_path(self, source):
        if not source:
            return None
        # Strip QGIS provider URI suffixes such as /path/file.tif|option=value.
        p = source.split("|")[0]
        # Strip file URI prefix.
        if p.startswith("file://"):
            p = p[7:]
        return os.path.normpath(p)

    def _insert_temp_layer(self, original, temp_layer, remove_original=True):
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        node = root.findLayer(original.id())

        # 元レイヤのレイヤパネル上の表示ON/OFF状態を退避します。
        # itemVisibilityChecked() は「レイヤ名左のチェック状態」を返すため、
        # 親グループの表示状態に左右されず、元レイヤそのもののON/OFFを引き継げます。
        original_visibility_checked = True
        if node is not None:
            try:
                original_visibility_checked = node.itemVisibilityChecked()
            except Exception:
                original_visibility_checked = True

        project.addMapLayer(temp_layer, False)

        new_node = None
        if node is not None and node.parent() is not None:
            parent = node.parent()
            try:
                idx = parent.children().index(node)
            except ValueError:
                idx = -1
            new_node = parent.insertLayer(idx + 1, temp_layer)
        else:
            new_node = root.addLayer(temp_layer)

        # 一時化後のレイヤに、元レイヤの表示ON/OFF状態を反映します。
        if new_node is not None:
            try:
                new_node.setItemVisibilityChecked(original_visibility_checked)
            except Exception:
                pass

        if remove_original:
            project.removeMapLayer(original.id())

    def _copy_style(self, src, dst):
        # QgsMapLayerStyle is the cleanest in-memory style copy for both vector and raster.
        try:
            style = QgsMapLayerStyle()
            style.readFromLayer(src)
            style.writeToLayer(dst)
            dst.triggerRepaint()
            return
        except Exception:
            pass

        # Fallback: QML round-trip.
        qml_path = None
        try:
            fd, qml_path = tempfile.mkstemp(prefix="l2tmp_style_", suffix=".qml")
            os.close(fd)
            src.saveNamedStyle(qml_path)
            dst.loadNamedStyle(qml_path)
            dst.triggerRepaint()
        finally:
            if qml_path and os.path.exists(qml_path):
                try:
                    os.remove(qml_path)
                except Exception:
                    pass

    def _temporary_name(self, name, opts):
        if opts.get("suffix_tmp", False):
            if not name.endswith("_tmp"):
                return name + "_tmp"
        return name

    def _safe_filename(self, text):
        text = re.sub(r"[\\/:*?\"<>|]+", "_", text)
        text = re.sub(r"\s+", "_", text).strip("._ ")
        return text or "layer"
