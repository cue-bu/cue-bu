# -*- coding: utf-8 -*-

def classFactory(iface):
    from .Layer2shp import SimpleSaveTemporarylayer
    return SimpleSaveTemporarylayer(iface)
