# -*- coding: utf-8 -*-
"""LayerPanel2GeoPackage QGIS plugin.

Exports vector layers in the layer panel to a single GeoPackage and raster
layers to a sibling folder as GeoTIFF. Output names are based on layer names
with CRS/EPSG suffixes.
"""

import os
import re
import tempfile
import traceback

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QAction,
    QAbstractItemView,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QToolBar,
    QVBoxLayout,
)

from qgis.core import (
    QgsMapLayer,
    QgsProject,
    QgsRasterBlockFeedback,
    QgsRasterFileWriter,
    QgsRasterPipe,
    QgsVectorFileWriter,
    QgsVectorLayer,
)

try:
    from qgis.core import QgsLayerTreeLayer
except Exception:  # pragma: no cover - QGIS provides this in normal use
    QgsLayerTreeLayer = None


PLUGIN_NAME = "LayerPanel2GeoPackage"
INVALID_NAME_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def sanitize_output_name(name, fallback="layer"):
    """Return a safe output layer/file base name while keeping Japanese text."""
    text = str(name or "").strip()
    text = INVALID_NAME_RE.sub("_", text)
    text = re.sub(r"\s+", " ", text).strip()
    # Windows does not like trailing dots/spaces in file names. Keep spaces inside.
    text = text.rstrip(". ")
    if not text:
        text = fallback
    return text


def crs_suffix(layer):
    """Return EPSG code suffix where possible, otherwise a safe CRS suffix."""
    try:
        crs = layer.crs()
        if crs and crs.isValid():
            authid = crs.authid() or ""
            if authid.upper().startswith("EPSG:"):
                code = authid.split(":", 1)[1]
                return sanitize_output_name(code, "noCRS")
            if authid:
                return sanitize_output_name(authid.replace(":", "_"), "noCRS")
    except Exception:
        pass
    return "noCRS"


def layer_type_name(layer):
    if layer.type() == QgsMapLayer.VectorLayer:
        return "ベクタ"
    if layer.type() == QgsMapLayer.RasterLayer:
        return "ラスタ"
    return "対象外"


def is_vector_layer(layer):
    return layer and layer.isValid() and layer.type() == QgsMapLayer.VectorLayer


def is_gdal_raster_layer(layer):
    if not layer or not layer.isValid() or layer.type() != QgsMapLayer.RasterLayer:
        return False
    try:
        return (layer.providerType() or "").lower() == "gdal"
    except Exception:
        return False


def make_unique_directory(base_dir):
    """Create and return a new unique directory path."""
    if not os.path.exists(base_dir):
        os.makedirs(base_dir)
        return base_dir
    index = 2
    while True:
        candidate = f"{base_dir}_{index}"
        if not os.path.exists(candidate):
            os.makedirs(candidate)
            return candidate
        index += 1


def vector_writer_error_message(result):
    """Normalize PyQGIS writer return values across QGIS 3 versions."""
    if isinstance(result, tuple):
        err = result[0]
        msg_parts = []
        for part in result[1:]:
            if isinstance(part, str) and part:
                msg_parts.append(part)
        return err, " / ".join(msg_parts)
    return result, ""


def is_no_error(error_code):
    try:
        return int(error_code) == int(QgsVectorFileWriter.NoError)
    except Exception:
        return error_code == QgsVectorFileWriter.NoError


class ExportSettingsDialog(QDialog):
    """Main settings dialog."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(PLUGIN_NAME)
        self.resize(640, 260)

        self.path_edit = QLineEdit(self)
        self.path_edit.setPlaceholderText("例：D:/work/output.gpkg")
        browse_button = QPushButton("参照...", self)
        browse_button.clicked.connect(self.browse_gpkg)

        path_layout = QHBoxLayout()
        path_layout.addWidget(self.path_edit, 1)
        path_layout.addWidget(browse_button)

        self.vector_check = QCheckBox("ベクタレイヤをGeoPackageに保存", self)
        self.vector_check.setChecked(True)
        self.vector_style_check = QCheckBox("ベクタスタイルをGeoPackage内に保存", self)
        self.vector_style_check.setChecked(True)
        self.raster_check = QCheckBox("ラスタレイヤを同階層の新規フォルダにGeoTIFF保存", self)
        self.raster_check.setChecked(True)
        self.raster_style_check = QCheckBox("ラスタスタイルを.qmlとして保存", self)
        self.raster_style_check.setChecked(True)

        option_box = QGroupBox("保存内容", self)
        option_layout = QVBoxLayout(option_box)
        option_layout.addWidget(self.vector_check)
        option_layout.addWidget(self.vector_style_check)
        option_layout.addWidget(self.raster_check)
        option_layout.addWidget(self.raster_style_check)

        note = QLabel(
            "保存名は、レイヤ名の末尾に _EPSGコード を付けます。\n"
            "例：建物 → 建物_6668、DEM → DEM_6668.tif\n"
            "重複する保存名がある場合は、実行前に編集ウィンドウを表示します。",
            self,
        )
        note.setWordWrap(True)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        buttons.button(QDialogButtonBox.Ok).setText("実行")
        buttons.button(QDialogButtonBox.Cancel).setText("キャンセル")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.addRow("出力先GeoPackage：", path_layout)
        layout.addLayout(form)
        layout.addWidget(option_box)
        layout.addWidget(note)
        layout.addStretch(1)
        layout.addWidget(buttons)

        self.vector_check.toggled.connect(self.vector_style_check.setEnabled)
        self.raster_check.toggled.connect(self.raster_style_check.setEnabled)

    def browse_gpkg(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            "出力先GeoPackageを選択",
            "",
            "GeoPackage (*.gpkg)",
        )
        if path:
            if not path.lower().endswith(".gpkg"):
                path += ".gpkg"
            self.path_edit.setText(path)

    def settings(self):
        return {
            "gpkg_path": self.path_edit.text().strip(),
            "save_vectors": self.vector_check.isChecked(),
            "save_vector_styles": self.vector_style_check.isChecked(),
            "save_rasters": self.raster_check.isChecked(),
            "save_raster_styles": self.raster_style_check.isChecked(),
        }

    def accept(self):
        path = self.path_edit.text().strip()
        if not path:
            QMessageBox.warning(self, PLUGIN_NAME, "出力先GeoPackageを指定してください。")
            return
        if not path.lower().endswith(".gpkg"):
            path += ".gpkg"
            self.path_edit.setText(path)
        parent_dir = os.path.dirname(path)
        if not parent_dir:
            QMessageBox.warning(self, PLUGIN_NAME, "保存先フォルダを含むパスを指定してください。")
            return
        if not os.path.isdir(parent_dir):
            QMessageBox.warning(self, PLUGIN_NAME, "保存先フォルダが存在しません。")
            return
        if not self.vector_check.isChecked() and not self.raster_check.isChecked():
            QMessageBox.warning(self, PLUGIN_NAME, "保存対象を1つ以上選択してください。")
            return
        super().accept()


class NameEditDialog(QDialog):
    """Dialog shown when duplicate output names need user confirmation/editing."""

    def __init__(self, entries, parent=None):
        super().__init__(parent)
        self.entries = entries
        self.setWindowTitle("保存名の確認・編集")
        self.resize(820, 420)

        label = QLabel(
            "重複する保存名があるため、自動で _2, _3... を付けました。\n"
            "必要に応じて、保存先名を編集してください。",
            self,
        )
        label.setWordWrap(True)

        self.table = QTableWidget(self)
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["種別", "元レイヤ名", "CRS", "保存先名"])
        self.table.setRowCount(len(entries))
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setAlternatingRowColors(True)

        for row, entry in enumerate(entries):
            type_item = QTableWidgetItem("ベクタ" if entry["kind"] == "vector" else "ラスタ")
            source_item = QTableWidgetItem(entry["source_name"])
            crs_item = QTableWidgetItem(entry["crs_label"])
            target_item = QTableWidgetItem(entry["target_name"])
            for item in (type_item, source_item, crs_item):
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
            if entry.get("auto_renamed"):
                target_item.setToolTip("重複回避のため自動変更されています。")
            self.table.setItem(row, 0, type_item)
            self.table.setItem(row, 1, source_item)
            self.table.setItem(row, 2, crs_item)
            self.table.setItem(row, 3, target_item)

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.Stretch)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, self)
        buttons.button(QDialogButtonBox.Ok).setText("この名前で保存")
        buttons.button(QDialogButtonBox.Cancel).setText("キャンセル")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addWidget(label)
        layout.addWidget(self.table, 1)
        layout.addWidget(buttons)

    def accept(self):
        seen = {}
        cleaned_names = []
        for row, entry in enumerate(self.entries):
            item = self.table.item(row, 3)
            name = sanitize_output_name(item.text() if item else "", f"layer_{row + 1}")
            if not name:
                QMessageBox.warning(self, PLUGIN_NAME, "保存先名が空の行があります。")
                return
            key = (entry["kind"], name.casefold())
            if key in seen:
                first = seen[key] + 1
                QMessageBox.warning(
                    self,
                    PLUGIN_NAME,
                    f"保存先名が重複しています。\n\n{first}行目 と {row + 1}行目：{name}",
                )
                return
            seen[key] = row
            cleaned_names.append(name)

        for row, name in enumerate(cleaned_names):
            self.entries[row]["target_name"] = name
        super().accept()


class LogDialog(QDialog):
    """Scrollable export result dialog."""

    def __init__(self, title, text, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(780, 520)
        edit = QTextEdit(self)
        edit.setReadOnly(True)
        edit.setPlainText(text)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok, self)
        buttons.button(QDialogButtonBox.Ok).setText("閉じる")
        buttons.accepted.connect(self.accept)
        layout = QVBoxLayout(self)
        layout.addWidget(edit, 1)
        layout.addWidget(buttons)


class LayerPanel2GeoPackage:
    """Main plugin class."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.toolbar = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.action = QAction(QIcon(icon_path), PLUGIN_NAME, self.iface.mainWindow())
        self.action.setObjectName("LayerPanel2GeoPackageAction")
        self.action.setToolTip("レイヤパネル上のレイヤをGeoPackageへ一括保存")
        self.action.triggered.connect(self.run)

        # layer2shp と同じ「拡張機能」共通ツールバーへ追加する。
        toolbar_name = "拡張機能"
        self.toolbar = self.iface.mainWindow().findChild(QToolBar, toolbar_name)
        if self.toolbar is None:
            self.toolbar = self.iface.addToolBar(toolbar_name)
            self.toolbar.setObjectName(toolbar_name)
        self.toolbar.addAction(self.action)
        self.toolbar.setVisible(True)

        self.iface.addPluginToMenu(PLUGIN_NAME, self.action)

    def unload(self):
        if self.action is not None:
            if self.toolbar is not None:
                self.toolbar.removeAction(self.action)
            self.iface.removePluginMenu(PLUGIN_NAME, self.action)
            self.action = None
        self.toolbar = None

    def run(self):
        dialog = ExportSettingsDialog(self.iface.mainWindow())
        if dialog.exec_() != QDialog.Accepted:
            return
        settings = dialog.settings()
        try:
            self.export_layers(**settings)
        except Exception as exc:
            detail = traceback.format_exc()
            QMessageBox.critical(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                f"処理中に予期しないエラーが発生しました。\n\n{exc}\n\n{detail}",
            )

    def layer_panel_layers(self):
        """Return layers in layer panel order, traversing groups."""
        root = QgsProject.instance().layerTreeRoot()
        result = []
        seen_ids = set()

        def walk(node):
            for child in node.children():
                if QgsLayerTreeLayer is not None and isinstance(child, QgsLayerTreeLayer):
                    layer = child.layer()
                    if layer is not None and layer.id() not in seen_ids:
                        result.append(layer)
                        seen_ids.add(layer.id())
                elif hasattr(child, "children"):
                    walk(child)

        walk(root)
        return result

    def build_entries(self, layers, save_vectors=True, save_rasters=True):
        entries = []
        skipped = []

        for layer in layers:
            if not layer or not layer.isValid():
                name = layer.name() if layer else "不明なレイヤ"
                skipped.append(f"SKIP: {name} / 無効なレイヤ")
                continue

            if layer.type() == QgsMapLayer.VectorLayer:
                if not save_vectors:
                    continue
                kind = "vector"
            elif layer.type() == QgsMapLayer.RasterLayer:
                if not save_rasters:
                    continue
                if not is_gdal_raster_layer(layer):
                    skipped.append(
                        f"SKIP: {layer.name()} / ラスタですが provider={layer.providerType()} のためスキップ"
                    )
                    continue
                kind = "raster"
            else:
                skipped.append(f"SKIP: {layer.name()} / 対象外レイヤ種別")
                continue

            suffix = crs_suffix(layer)
            base_name = sanitize_output_name(layer.name(), "layer")
            target_name = f"{base_name}_{suffix}"
            crs_label = ""
            try:
                crs_label = layer.crs().authid() if layer.crs() and layer.crs().isValid() else "CRS未設定"
            except Exception:
                crs_label = "CRS未設定"

            entries.append(
                {
                    "layer": layer,
                    "kind": kind,
                    "source_name": layer.name(),
                    "target_name": target_name,
                    "crs_label": crs_label,
                    "auto_renamed": False,
                }
            )

        duplicates_found = self.apply_auto_suffix_for_duplicates(entries)
        return entries, skipped, duplicates_found

    def apply_auto_suffix_for_duplicates(self, entries):
        counts = {}
        duplicates_found = False
        for entry in entries:
            base = entry["target_name"]
            key = (entry["kind"], base.casefold())
            if key not in counts:
                counts[key] = 1
                continue
            duplicates_found = True
            counts[key] += 1
            new_name = f"{base}_{counts[key]}"
            while (entry["kind"], new_name.casefold()) in counts:
                counts[key] += 1
                new_name = f"{base}_{counts[key]}"
            entry["target_name"] = new_name
            entry["auto_renamed"] = True
            counts[(entry["kind"], new_name.casefold())] = 1
        return duplicates_found

    def export_layers(self, gpkg_path, save_vectors, save_vector_styles, save_rasters, save_raster_styles):
        layers = self.layer_panel_layers()
        if not layers:
            QMessageBox.information(self.iface.mainWindow(), PLUGIN_NAME, "レイヤパネルにレイヤがありません。")
            return

        entries, skipped, duplicates_found = self.build_entries(layers, save_vectors, save_rasters)
        if not entries:
            LogDialog(PLUGIN_NAME, "保存対象レイヤがありません。\n\n" + "\n".join(skipped), self.iface.mainWindow()).exec_()
            return

        if duplicates_found:
            name_dialog = NameEditDialog(entries, self.iface.mainWindow())
            if name_dialog.exec_() != QDialog.Accepted:
                return

        vector_entries = [e for e in entries if e["kind"] == "vector"]
        raster_entries = [e for e in entries if e["kind"] == "raster"]

        if vector_entries and os.path.exists(gpkg_path):
            ret = QMessageBox.question(
                self.iface.mainWindow(),
                PLUGIN_NAME,
                "指定されたGeoPackageは既に存在します。\n\n上書きしてよろしいですか？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if ret != QMessageBox.Yes:
                return
            try:
                os.remove(gpkg_path)
            except Exception as exc:
                QMessageBox.critical(
                    self.iface.mainWindow(),
                    PLUGIN_NAME,
                    f"既存GeoPackageを削除できませんでした。\nファイルをQGISや他のアプリで開いていないか確認してください。\n\n{exc}",
                )
                return

        log = []
        log.append(f"出力先GeoPackage: {gpkg_path}")
        log.append("")

        vector_ok = 0
        vector_style_ok = 0
        raster_ok = 0
        raster_style_ok = 0
        error_count = 0

        if vector_entries:
            log.append("[ベクタ保存]")
            for index, entry in enumerate(vector_entries):
                layer = entry["layer"]
                target_name = entry["target_name"]
                try:
                    options = QgsVectorFileWriter.SaveVectorOptions()
                    options.driverName = "GPKG"
                    options.fileEncoding = "UTF-8"
                    options.layerName = target_name
                    if index == 0 or not os.path.exists(gpkg_path):
                        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
                    else:
                        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer

                    result = QgsVectorFileWriter.writeAsVectorFormatV3(
                        layer,
                        gpkg_path,
                        QgsProject.instance().transformContext(),
                        options,
                    )
                    err, msg = vector_writer_error_message(result)
                    if is_no_error(err):
                        vector_ok += 1
                        log.append(f"OK: {layer.name()} -> {target_name}")
                        if save_vector_styles:
                            if self.save_vector_style_to_gpkg(layer, gpkg_path, target_name, log):
                                vector_style_ok += 1
                    else:
                        error_count += 1
                        log.append(f"ERROR: {layer.name()} -> {target_name} / {msg or err}")
                except Exception as exc:
                    error_count += 1
                    log.append(f"ERROR: {layer.name()} -> {target_name} / {exc}")
            log.append("")
        else:
            log.append("[ベクタ保存] 対象なし")
            log.append("")

        raster_dir = ""
        if raster_entries:
            gpkg_dir = os.path.dirname(gpkg_path)
            gpkg_base = os.path.splitext(os.path.basename(gpkg_path))[0]
            raster_dir = make_unique_directory(os.path.join(gpkg_dir, f"{gpkg_base}_raster"))
            log.append(f"[ラスタ保存] 保存先フォルダ: {raster_dir}")
            for entry in raster_entries:
                layer = entry["layer"]
                target_name = entry["target_name"]
                tif_path = os.path.join(raster_dir, f"{target_name}.tif")
                try:
                    if self.export_raster_to_geotiff(layer, tif_path):
                        raster_ok += 1
                        log.append(f"OK: {layer.name()} -> {os.path.basename(tif_path)}")
                        if save_raster_styles:
                            qml_path = os.path.join(raster_dir, f"{target_name}.qml")
                            if self.save_qml_style(layer, qml_path, log):
                                raster_style_ok += 1
                    else:
                        error_count += 1
                        log.append(f"ERROR: {layer.name()} -> {os.path.basename(tif_path)} / ラスタ書き出し失敗")
                except Exception as exc:
                    error_count += 1
                    log.append(f"ERROR: {layer.name()} -> {os.path.basename(tif_path)} / {exc}")
            log.append("")
        else:
            log.append("[ラスタ保存] 対象なし")
            log.append("")

        if skipped:
            log.append("[スキップ]")
            log.extend(skipped)
            log.append("")

        log.append("[結果]")
        log.append(f"ベクタ保存成功: {vector_ok} 件")
        log.append(f"ベクタスタイル保存成功: {vector_style_ok} 件")
        log.append(f"ラスタ保存成功: {raster_ok} 件")
        log.append(f"ラスタスタイル保存成功: {raster_style_ok} 件")
        log.append(f"スキップ: {len(skipped)} 件")
        log.append(f"エラー: {error_count} 件")
        if raster_dir:
            log.append(f"ラスタ保存フォルダ: {raster_dir}")

        LogDialog(PLUGIN_NAME, "\n".join(log), self.iface.mainWindow()).exec_()

        if error_count == 0:
            self.iface.messageBar().pushSuccess(PLUGIN_NAME, "保存が完了しました。")
        else:
            self.iface.messageBar().pushWarning(PLUGIN_NAME, "保存が完了しましたが、一部エラーがあります。")

    def save_vector_style_to_gpkg(self, source_layer, gpkg_path, target_name, log):
        """Copy source style to exported GPKG layer and save it into the database."""
        tmp_qml = ""
        try:
            fd, tmp_qml = tempfile.mkstemp(suffix=".qml")
            os.close(fd)
            self.save_qml_style(source_layer, tmp_qml, log=None)

            uri = f"{gpkg_path}|layername={target_name}"
            exported = QgsVectorLayer(uri, target_name, "ogr")
            if not exported.isValid():
                log.append(f"STYLE ERROR: {target_name} / 出力レイヤを再読込できませんでした")
                return False
            exported.loadNamedStyle(tmp_qml)
            try:
                exported.saveStyleToDatabase("default", f"Copied from {source_layer.name()}", True, "")
                log.append(f"STYLE OK: {target_name} / GeoPackage内に保存")
                return True
            except Exception as exc:
                log.append(f"STYLE ERROR: {target_name} / GeoPackage内スタイル保存失敗: {exc}")
                return False
        except Exception as exc:
            log.append(f"STYLE ERROR: {target_name} / {exc}")
            return False
        finally:
            if tmp_qml and os.path.exists(tmp_qml):
                try:
                    os.remove(tmp_qml)
                except Exception:
                    pass

    def save_qml_style(self, layer, qml_path, log=None):
        try:
            result = layer.saveNamedStyle(qml_path)
            ok = True
            if isinstance(result, tuple):
                # QGIS commonly returns (message, success) or similar depending on version.
                bools = [v for v in result if isinstance(v, bool)]
                if bools:
                    ok = bools[-1]
            if log is not None:
                if ok:
                    log.append(f"STYLE OK: {layer.name()} -> {os.path.basename(qml_path)}")
                else:
                    log.append(f"STYLE ERROR: {layer.name()} -> {os.path.basename(qml_path)}")
            return ok
        except Exception as exc:
            if log is not None:
                log.append(f"STYLE ERROR: {layer.name()} -> {os.path.basename(qml_path)} / {exc}")
            return False

    def export_raster_to_geotiff(self, layer, output_path):
        pipe = QgsRasterPipe()
        provider = layer.dataProvider()
        if provider is None:
            return False
        if not pipe.set(provider.clone()):
            return False

        writer = QgsRasterFileWriter(output_path)
        writer.setOutputFormat("GTiff")
        feedback = QgsRasterBlockFeedback()
        result = writer.writeRaster(
            pipe,
            layer.width(),
            layer.height(),
            layer.extent(),
            layer.crs(),
            feedback,
        )
        try:
            return int(result) == int(QgsRasterFileWriter.NoError)
        except Exception:
            return result == QgsRasterFileWriter.NoError
