# -*- coding: utf-8 -*-


def classFactory(iface):
    from .layerpanel2geopackage import LayerPanel2GeoPackage
    return LayerPanel2GeoPackage(iface)
