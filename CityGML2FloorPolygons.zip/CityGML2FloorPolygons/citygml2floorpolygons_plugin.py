# -*- coding: utf-8 -*-

import os

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QToolBar

from .dialog import CityGML2FloorPolygonsDialog


class CityGML2FloorPolygonsPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None
        self.menu_name = '&CityGML2FloorPolygons'
        self.toolbar_name = '拡張機能'
        self.toolbar = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.action = QAction(QIcon(icon_path), 'CityGML2FloorPolygons', self.iface.mainWindow())
        self.action.setObjectName('CityGML2FloorPolygonsAction')
        self.action.setWhatsThis('PLATEAU / CityGML 建築物から階別高さポリゴンを生成します。')
        self.action.setStatusTip('CityGMLから階別高さポリゴンを生成')
        self.action.triggered.connect(self.run)
        # layer2shp と同じ共有ツールバー「拡張機能」に追加します。
        self.toolbar = self.iface.mainWindow().findChild(QToolBar, self.toolbar_name)
        if self.toolbar is None:
            self.toolbar = self.iface.addToolBar(self.toolbar_name)
            self.toolbar.setObjectName(self.toolbar_name)
        self.toolbar.addAction(self.action)
        self.toolbar.setVisible(True)

        self.iface.addPluginToMenu(self.menu_name, self.action)

    def unload(self):
        if self.action is not None:
            if self.toolbar is not None:
                self.toolbar.removeAction(self.action)
            self.iface.removePluginMenu(self.menu_name, self.action)
            self.action = None
        self.toolbar = None
        self.dialog = None

    def run(self):
        self.dialog = CityGML2FloorPolygonsDialog(self.iface, self.iface.mainWindow())
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
