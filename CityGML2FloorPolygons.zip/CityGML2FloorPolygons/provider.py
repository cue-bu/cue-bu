# -*- coding: utf-8 -*-

from qgis.core import QgsProcessingProvider
from .algorithm import CityGML2FloorPolygonsAlgorithm, FloorPolygonsToHtmlViewerAlgorithm


class CityGML2FloorPolygonsProvider(QgsProcessingProvider):
    def loadAlgorithms(self):
        self.addAlgorithm(CityGML2FloorPolygonsAlgorithm())
        self.addAlgorithm(FloorPolygonsToHtmlViewerAlgorithm())

    def id(self):
        return 'citygml2floorpolygons'

    def name(self):
        return 'CityGML2FloorPolygons'

    def longName(self):
        return 'CityGML2FloorPolygons'
