# CityGML2FloorPolygons v0.4.22

修正点:
- v0.4.20で CityGMLファイル追加ボタンの初期フォルダが Downloads 固定のようになる問題を修正しました。
- CityGMLファイル追加ボタンは以下の挙動に戻しました。
  - 既にCityGMLを選んでいる場合: そのフォルダ
  - まだ何も選んでいない場合: 空文字にして、QGIS/Windows側の自然な初期位置に任せる

維持:
- v0.4.20の設定画面タイトルのバージョン表示
- GeoPackage保存先ダイアログの初期フォルダ改善
- HTMLビューワー保存先ダイアログの初期フォルダ改善
- HTML未指定時、GeoPackage出力先フォルダへHTMLを出す処理
- v0.4.19のCesium版Viewer機能
- v0.4.18の起動セット安定化
