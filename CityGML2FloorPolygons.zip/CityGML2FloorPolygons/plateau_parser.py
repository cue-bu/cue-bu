# -*- coding: utf-8 -*-
"""Dependency-free PLATEAU / CityGML building parser.

The parser intentionally avoids QGIS imports so it can be smoke-tested outside
QGIS. QGIS-specific geometry creation is handled in floor_generator.py.
"""

from __future__ import annotations

import math
import os
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Dict, Generator, List, Optional, Tuple

NS: Dict[str, str] = {
    'core': 'http://www.opengis.net/citygml/2.0',
    'bldg': 'http://www.opengis.net/citygml/building/2.0',
    'gml': 'http://www.opengis.net/gml',
    # PLATEAU versions differ by dataset; local-name search is also used.
    'uro32': 'https://www.geospatial.jp/iur/uro/3.2',
    'uro31': 'https://www.geospatial.jp/iur/uro/3.1',
    'uro30': 'https://www.geospatial.jp/iur/uro/3.0',
    'uro20': 'https://www.geospatial.jp/iur/uro/2.0',
}

GML_ID = '{http://www.opengis.net/gml}id'
BLDG_BUILDING = '{http://www.opengis.net/citygml/building/2.0}Building'
BLDG_BUILDING_PART = '{http://www.opengis.net/citygml/building/2.0}BuildingPart'

Coord3 = Tuple[float, float, Optional[float]]
Ring3 = List[Coord3]
Polygon3 = List[Ring3]      # [exterior, interior1, interior2, ...]
MultiPolygon3 = List[Polygon3]


@dataclass
class PlateauBuilding:
    gml_id: str
    building_id: str
    object_type: str
    measured_height: Optional[float]
    storeys_above_ground: Optional[int]
    storeys_below_ground: Optional[int]
    storey_heights_above_ground: List[float]
    storey_heights_below_ground: List[float]
    lod1_min_z: Optional[float]
    lod1_max_z: Optional[float]
    footprint_lod0: MultiPolygon3
    footprint_lod1_bottom: MultiPolygon3
    source_file: str


def _local_name(tag: str) -> str:
    if '}' in tag:
        return tag.rsplit('}', 1)[1]
    return tag


def _first_text(elem: ET.Element, path: str) -> str:
    found = elem.find(path, NS)
    if found is None or found.text is None:
        return ''
    return found.text.strip()


def _first_text_by_local_name(elem: ET.Element, local_name: str) -> str:
    for child in elem.iter():
        if _local_name(child.tag) == local_name and child.text:
            return child.text.strip()
    return ''


def _to_float(value: str) -> Optional[float]:
    try:
        v = float(value)
    except Exception:
        return None
    if math.isnan(v) or math.isinf(v):
        return None
    return v


def _to_int(value: str) -> Optional[int]:
    try:
        return int(float(value))
    except Exception:
        return None


def _valid_height(value: Optional[float]) -> bool:
    return value is not None and value > 0 and abs(value + 9999) > 1e-9


def parse_poslist(text: str) -> Ring3:
    """Parse a GML posList into [(a, b, z), ...].

    PLATEAU geographic CRS GML often stores values as latitude, longitude, Z.
    Axis swapping is handled later by the QGIS generator.
    """
    if not text:
        return []
    values: List[float] = []
    for token in text.replace('\n', ' ').replace('\t', ' ').split():
        try:
            values.append(float(token))
        except Exception:
            pass
    if not values:
        return []

    if len(values) % 3 == 0:
        step = 3
    elif len(values) % 2 == 0:
        step = 2
    else:
        step = 3 if len(values) >= 3 else 2

    coords: Ring3 = []
    usable = len(values) - (len(values) % step)
    for i in range(0, usable, step):
        a = values[i]
        b = values[i + 1]
        z = values[i + 2] if step == 3 else None
        coords.append((a, b, z))
    return coords


def _polygon_from_gml_polygon(poly: ET.Element) -> Polygon3:
    rings: Polygon3 = []
    exterior = poly.find('./gml:exterior/gml:LinearRing/gml:posList', NS)
    if exterior is None:
        exterior = poly.find('.//gml:exterior//gml:posList', NS)
    if exterior is None or not exterior.text:
        return []
    outer = parse_poslist(exterior.text)
    if len(outer) < 4:
        return []
    rings.append(outer)

    for interior in poly.findall('./gml:interior/gml:LinearRing/gml:posList', NS):
        if interior.text:
            ring = parse_poslist(interior.text)
            if len(ring) >= 4:
                rings.append(ring)
    return rings


def _polygons_under(elem: ET.Element, path: str) -> MultiPolygon3:
    out: MultiPolygon3 = []
    for poly in elem.findall(path, NS):
        p = _polygon_from_gml_polygon(poly)
        if p:
            out.append(p)
    return out


def _z_values_from_multipolygon(mp: MultiPolygon3) -> List[float]:
    z_values: List[float] = []
    for poly in mp:
        for ring in poly:
            for _, _, z in ring:
                if z is not None:
                    z_values.append(z)
    return z_values


def _all_lod1_z_values(elem: ET.Element) -> List[float]:
    z_values: List[float] = []
    for pos in elem.findall('.//bldg:lod1Solid//gml:posList', NS):
        if pos.text:
            for _, _, z in parse_poslist(pos.text):
                if z is not None:
                    z_values.append(z)
    return z_values


def _extract_lod0_footprint(elem: ET.Element) -> MultiPolygon3:
    # PLATEAU LOD0 buildings commonly use lod0RoofEdge. lod0FootPrint is also
    # supported when present.
    mp = _polygons_under(elem, './/bldg:lod0RoofEdge//gml:Polygon')
    if mp:
        return mp
    return _polygons_under(elem, './/bldg:lod0FootPrint//gml:Polygon')


def _extract_lod1_bottom_footprint(elem: ET.Element, z_tol: float = 0.05) -> MultiPolygon3:
    """Extract horizontal polygons at lod1Solid minimum Z as a footprint fallback."""
    all_polys = _polygons_under(elem, './/bldg:lod1Solid//gml:Polygon')
    z_values = _z_values_from_multipolygon(all_polys)
    if not z_values:
        return []
    min_z = min(z_values)
    bottom: MultiPolygon3 = []
    for poly in all_polys:
        ring_z = _z_values_from_multipolygon([poly])
        if not ring_z:
            continue
        if max(ring_z) - min(ring_z) <= z_tol and abs(sum(ring_z) / len(ring_z) - min_z) <= z_tol:
            bottom.append(poly)
    return bottom


def _storey_heights(elem: ET.Element, local_names) -> List[float]:
    heights: List[float] = []
    if isinstance(local_names, str):
        local_names = [local_names]
    wanted = set(local_names)
    # Direct child is the normal CityGML building attribute location.
    # local-name based extraction is used to tolerate PLATEAU / CityGML namespace variations.
    for h_elem in list(elem):
        if _local_name(h_elem.tag) in wanted and h_elem.text:
            for token in h_elem.text.replace('\n', ' ').replace('\t', ' ').split():
                v = _to_float(token)
                if _valid_height(v):
                    heights.append(float(v))
    return heights


def parse_building(elem: ET.Element, source_file: str) -> PlateauBuilding:
    gml_id = elem.attrib.get(GML_ID, '')
    object_type = 'BuildingPart' if elem.tag == BLDG_BUILDING_PART else 'Building'

    measured_height = _to_float(_first_text(elem, './bldg:measuredHeight'))
    storeys_above = _to_int(_first_text(elem, './bldg:storeysAboveGround'))
    storeys_below = _to_int(_first_text(elem, './bldg:storeysBelowGround'))
    building_id = _first_text_by_local_name(elem, 'buildingID')

    z_values = _all_lod1_z_values(elem)
    lod1_min_z = min(z_values) if z_values else None
    lod1_max_z = max(z_values) if z_values else None

    return PlateauBuilding(
        gml_id=gml_id,
        building_id=building_id,
        object_type=object_type,
        measured_height=measured_height,
        storeys_above_ground=storeys_above,
        storeys_below_ground=storeys_below,
        storey_heights_above_ground=_storey_heights(elem, 'storeyHeightsAboveGround'),
        storey_heights_below_ground=_storey_heights(elem, ['storeyHeightsBelowGround', 'storeyHeightsBelowground']),
        lod1_min_z=lod1_min_z,
        lod1_max_z=lod1_max_z,
        footprint_lod0=_extract_lod0_footprint(elem),
        footprint_lod1_bottom=_extract_lod1_bottom_footprint(elem),
        source_file=os.path.basename(source_file),
    )


def iter_buildings(path: str) -> Generator[PlateauBuilding, None, None]:
    """Yield Building and BuildingPart objects from a PLATEAU CityGML file."""
    context = ET.iterparse(path, events=('end',))
    for _event, elem in context:
        if elem.tag in (BLDG_BUILDING, BLDG_BUILDING_PART):
            yield parse_building(elem, path)
            elem.clear()


if __name__ == '__main__':
    import sys
    from collections import Counter

    p = sys.argv[1]
    c = Counter()
    total = 0
    first = None
    for b in iter_buildings(p):
        total += 1
        c[b.storeys_above_ground] += 1
        if first is None:
            first = b
    print('buildings:', total)
    print('storeys:', sorted(c.items(), key=lambda x: (-1 if x[0] is None else x[0])))
    if first:
        print('first:', first.gml_id, first.building_id, first.measured_height, first.storeys_above_ground, first.lod1_min_z, first.lod1_max_z)
