# -*- coding: utf-8 -*-

from __future__ import annotations

import json
import os
from typing import List

from qgis.PyQt.QtWidgets import QFileDialog, QHBoxLayout, QLineEdit, QPushButton, QWidget, QCheckBox
from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterCrs,
    QgsProcessingParameterEnum,
    QgsProcessingParameterField,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterNumber,
    QgsProcessingParameterString,
    QgsProcessingParameterVectorDestination,
    QgsProcessingParameterVectorLayer,
)

try:
    from processing.gui.wrappers import WidgetWrapper
except Exception:
    class WidgetWrapper(object):
        def __init__(self, *args, **kwargs):
            pass

from .dialog import clean_source_to_path
from .floor_generator import (
    GenerateOptions,
    default_downloads_dir,
    generate_floor_polygons,
    generate_html_viewer_from_layer,
)


def _parse_input_file_value(value) -> List[str]:
    if not value:
        return []
    if isinstance(value, (list, tuple)):
        return [os.path.normpath(str(p)) for p in value if str(p)]
    text = str(value).strip()
    if not text:
        return []
    if text.startswith('['):
        try:
            data = json.loads(text)
            if isinstance(data, list):
                return [os.path.normpath(str(p)) for p in data if str(p)]
        except Exception:
            pass
    for sep in ['\n', '||', ';']:
        if sep in text:
            return [os.path.normpath(p.strip()) for p in text.split(sep) if p.strip()]
    return [os.path.normpath(text)]


def _parse_html_viewer_value(value):
    if value is None:
        return False, ''
    if isinstance(value, dict):
        return bool(value.get('enabled')), os.path.normpath(str(value.get('path') or ''))
    text = str(value).strip()
    if not text:
        return False, ''
    if text.startswith('{'):
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                return bool(data.get('enabled')), os.path.normpath(str(data.get('path') or ''))
        except Exception:
            pass
    lowered = text.lower()
    if lowered in ('0', 'false', 'no', 'off', 'なし'):
        return False, ''
    if lowered in ('1', 'true', 'yes', 'on', 'あり'):
        return True, ''
    return True, os.path.normpath(text)


def _parse_csv_names(value) -> List[str]:
    text = str(value or '').strip()
    if not text:
        return []
    if text.startswith('['):
        try:
            data = json.loads(text)
            if isinstance(data, list):
                return [str(v).strip() for v in data if str(v).strip()]
        except Exception:
            pass
    return [v.strip() for v in text.split(',') if v.strip()]


class MultiCityGMLFileWidgetWrapper(WidgetWrapper):
    def createWidget(self):
        self._files = []
        self._widget = QWidget()
        layout = QHBoxLayout(self._widget)
        layout.setContentsMargins(0, 0, 0, 0)
        self._line = QLineEdit()
        self._line.setReadOnly(True)
        self._line.setPlaceholderText('CityGML/GMLファイルを選択してください')
        self._button = QPushButton('...')
        self._button.setFixedWidth(34)
        self._button.clicked.connect(self._browse)
        layout.addWidget(self._line, 1)
        layout.addWidget(self._button)
        return self._widget

    def _browse(self):
        start_dir = ''
        if getattr(self, '_files', None):
            start_dir = os.path.dirname(self._files[0])
        files, _ = QFileDialog.getOpenFileNames(
            self._widget,
            'CityGMLファイルを選択',
            start_dir,
            'CityGML/GML (*.gml *.xml *.citygml);;All files (*.*)'
        )
        if files:
            self._files = [os.path.normpath(p) for p in files]
            self._update_line()

    def _update_line(self):
        if not getattr(self, '_line', None):
            return
        if not self._files:
            self._line.setText('')
        elif len(self._files) == 1:
            self._line.setText(self._files[0])
        else:
            self._line.setText(f'{len(self._files)} 個のファイルが選択されました')

    def setValue(self, value):
        self._files = _parse_input_file_value(value)
        self._update_line()

    def value(self):
        return json.dumps(getattr(self, '_files', []), ensure_ascii=False)


class HtmlViewerOutputWidgetWrapper(WidgetWrapper):
    def createWidget(self):
        self._widget = QWidget()
        layout = QHBoxLayout(self._widget)
        layout.setContentsMargins(0, 0, 0, 0)
        self._check = QCheckBox('HTMLビューワーを出力する')
        self._line = QLineEdit()
        self._line.setPlaceholderText(f'HTMLビューワーの保存先（未指定なら {default_downloads_dir()}）')
        self._button = QPushButton('...')
        self._button.setFixedWidth(34)
        layout.addWidget(self._check)
        layout.addWidget(self._line, 1)
        layout.addWidget(self._button)
        self._check.toggled.connect(self._on_checked)
        self._button.clicked.connect(self._browse)
        self._sync_enabled()
        return self._widget

    def _on_checked(self, checked):
        self._sync_enabled()
        if checked and not self._line.text().strip():
            self._browse(silent_cancel=True)

    def _sync_enabled(self):
        enabled = bool(getattr(self, '_check', None) and self._check.isChecked())
        if getattr(self, '_line', None):
            self._line.setEnabled(enabled)
        if getattr(self, '_button', None):
            self._button.setEnabled(enabled)

    def _browse(self, silent_cancel=False):
        start_path = self._line.text().strip() if getattr(self, '_line', None) else ''
        start_dir = os.path.dirname(start_path) if start_path else default_downloads_dir()
        path, _ = QFileDialog.getSaveFileName(
            self._widget,
            'HTMLビューワーの保存先を指定',
            os.path.join(start_dir, 'floor_polygons_viewer.html'),
            'HTML files (*.html *.htm);;All files (*.*)'
        )
        if path:
            if not path.lower().endswith(('.html', '.htm')):
                path += '.html'
            self._line.setText(os.path.normpath(path))
        elif not silent_cancel:
            pass

    def setValue(self, value):
        enabled, path = _parse_html_viewer_value(value)
        self._check.setChecked(enabled)
        self._line.setText(path or '')
        self._sync_enabled()

    def value(self):
        return json.dumps({'enabled': bool(self._check.isChecked()), 'path': self._line.text().strip()}, ensure_ascii=False)


class CityGML2FloorPolygonsAlgorithm(QgsProcessingAlgorithm):
    INPUT_FILE = 'INPUT_FILE'
    INPUT_LAYERS = 'INPUT_LAYERS'
    OUTPUT = 'OUTPUT'
    LAYER_NAME = 'LAYER_NAME'
    OUTPUT_CRS = 'OUTPUT_CRS'
    SWAP_AXIS = 'SWAP_AXIS'
    POLYGON_Z = 'POLYGON_Z'
    FOOTPRINT_SOURCE = 'FOOTPRINT_SOURCE'
    HEIGHT_SOURCE = 'HEIGHT_SOURCE'
    INVALID_HANDLING = 'INVALID_HANDLING'
    DEFAULT_FLOOR_HEIGHT = 'DEFAULT_FLOOR_HEIGHT'
    HTML_VIEWER = 'HTML_VIEWER'
    HTML_COLOR_ATTRIBUTE = 'HTML_COLOR_ATTRIBUTE'
    HTML_ATTRIBUTE_NAMES = 'HTML_ATTRIBUTE_NAMES'

    FOOTPRINT_OPTIONS = [
        'lod0RoofEdge / lod0FootPrint を優先し、なければ lod1Solid 下端面を使う',
        'lod1Solid 下端面を優先し、なければ lod0RoofEdge / lod0FootPrint を使う',
    ]
    HEIGHT_OPTIONS = ['bldg:measuredHeight を優先する', 'lod1Solid の Z 範囲を優先する']
    INVALID_OPTIONS = ['スキップする', '建物全体を1階分として出力する', '高さとデフォルト階高から階数を推定する']

    def tr(self, string):
        return string

    def createInstance(self):
        return CityGML2FloorPolygonsAlgorithm()

    def name(self):
        return 'citygml2floorpolygons'

    def displayName(self):
        return 'CityGMLから階別高さポリゴンを生成'

    def group(self):
        return ''

    def groupId(self):
        return ''

    def shortHelpString(self):
        return (
            'PLATEAU / CityGML の bldg:Building を読み込み、階ごとの高さ属性を持つポリゴンを生成します。\n\n'
            '【入力CityGML】\n'
            'CityGMLファイル、またはQGISに読み込み済みのCityGML/GMLレイヤを指定します。'
            'CityGMLファイル欄の「...」から複数の .gml / .xml / .citygml を同時選択できます。\n\n'
            '【出力】\n'
            '出力ファイルを空欄のままにすると、一時出力として階別高さポリゴンを作成します。'
            'HTMLビューワーにチェックを入れた場合は、同時に HTML + data.js を作成します。'
            'HTML保存先が未指定の場合は Windows のダウンロードフォルダに保存します。\n\n'
            '【計算設定】\n'
            'storeyHeightsAboveGround があれば各階高として優先します。なければ、選択した建物高さを storeysAboveGround で割って平均階高にします。'
            '各階の z_base はその階の床高さ、z_top はその階の天井高さです。2階の z_base は1階の z_top と同じ値になります。\n\n'
            'HTMLの色分け属性は初期値として指定できます。HTMLに出力する属性は、カンマ区切りで指定した項目だけをビューワーへ埋め込みます。'
            '更新後にHTMLを作り直したい場合は、「階別高さポリゴンからHTMLビューワーを更新」ツールを使ってください。'
        )

    def initAlgorithm(self, config=None):
        p = QgsProcessingParameterString(self.INPUT_FILE, '入力CityGML：CityGMLファイル（複数ファイル・任意）', defaultValue='', optional=True)
        p.setMetadata({'widget_wrapper': {'class': MultiCityGMLFileWidgetWrapper}})
        self.addParameter(p)
        self.addParameter(QgsProcessingParameterMultipleLayers(
            self.INPUT_LAYERS,
            '入力CityGML：読み込み済みCityGML/GMLレイヤ（任意）',
            layerType=QgsProcessing.TypeVectorAnyGeometry,
            optional=True,
        ))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT, '出力：階別高さポリゴン', type=QgsProcessing.TypeVectorPolygon))
        self.addParameter(QgsProcessingParameterString(self.LAYER_NAME, '出力レイヤ名', defaultValue='floor_polygons'))
        self.addParameter(QgsProcessingParameterCrs(self.OUTPUT_CRS, '出力CRS', defaultValue='EPSG:6668'))
        self.addParameter(QgsProcessingParameterBoolean(self.SWAP_AXIS, 'PLATEAUの緯度・経度順を、QGIS用の経度・緯度順へ変換する', defaultValue=True))
        self.addParameter(QgsProcessingParameterBoolean(self.POLYGON_Z, '出力ジオメトリを床面Z付き PolygonZ にする', defaultValue=False))
        self.addParameter(QgsProcessingParameterEnum(self.FOOTPRINT_SOURCE, 'フットプリントの取得方法', options=self.FOOTPRINT_OPTIONS, defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(self.HEIGHT_SOURCE, '建物高さの取得方法', options=self.HEIGHT_OPTIONS, defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(self.INVALID_HANDLING, '階数または高さが無効な建物の扱い', options=self.INVALID_OPTIONS, defaultValue=1))
        self.addParameter(QgsProcessingParameterNumber(self.DEFAULT_FLOOR_HEIGHT, 'デフォルト階高（m）', type=QgsProcessingParameterNumber.Double, defaultValue=3.0, minValue=0.1))
        hp = QgsProcessingParameterString(self.HTML_VIEWER, 'HTMLビューワー出力', defaultValue=json.dumps({'enabled': False, 'path': ''}, ensure_ascii=False), optional=True)
        hp.setMetadata({'widget_wrapper': {'class': HtmlViewerOutputWidgetWrapper}})
        self.addParameter(hp)
        self.addParameter(QgsProcessingParameterString(self.HTML_COLOR_ATTRIBUTE, 'HTMLの初期色分け属性（空欄で floor_no）', defaultValue='floor_no', optional=True))
        self.addParameter(QgsProcessingParameterString(self.HTML_ATTRIBUTE_NAMES, 'HTMLに出力する属性（カンマ区切り・空欄で主な属性）', defaultValue='', optional=True))

    def processAlgorithm(self, parameters, context, feedback):
        input_paths: List[str] = []
        input_file_value = self.parameterAsString(parameters, self.INPUT_FILE, context)
        for p in _parse_input_file_value(input_file_value):
            if p and p not in input_paths:
                input_paths.append(p)
        layers = self.parameterAsLayerList(parameters, self.INPUT_LAYERS, context)
        for layer in layers or []:
            p = clean_source_to_path(layer.source())
            if p and os.path.exists(p) and p not in input_paths:
                input_paths.append(p)
        if not input_paths:
            raise QgsProcessingException('CityGMLファイル、または読み込み済みCityGML/GMLレイヤを指定してください。')

        output_path = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)
        if not output_path or output_path == QgsProcessing.TEMPORARY_OUTPUT:
            import tempfile
            output_path = os.path.join(tempfile.mkdtemp(prefix='citygml2floorpolygons_'), 'floor_polygons.gpkg')
        output_path = str(output_path).split('|')[0]

        crs = self.parameterAsCrs(parameters, self.OUTPUT_CRS, context)
        crs_authid = crs.authid() if crs and crs.isValid() else 'EPSG:6668'
        html_enabled, html_path = _parse_html_viewer_value(self.parameterAsString(parameters, self.HTML_VIEWER, context))
        layer_name = self.parameterAsString(parameters, self.LAYER_NAME, context) or 'floor_polygons'
        options = GenerateOptions(
            output_crs_authid=crs_authid,
            swap_axis=self.parameterAsBoolean(parameters, self.SWAP_AXIS, context),
            footprint_source=self.parameterAsEnum(parameters, self.FOOTPRINT_SOURCE, context),
            height_source=self.parameterAsEnum(parameters, self.HEIGHT_SOURCE, context),
            invalid_handling=self.parameterAsEnum(parameters, self.INVALID_HANDLING, context),
            default_floor_height=self.parameterAsDouble(parameters, self.DEFAULT_FLOOR_HEIGHT, context),
            polygon_z=self.parameterAsBoolean(parameters, self.POLYGON_Z, context),
            layer_name=layer_name,
            html_viewer=html_enabled,
            html_output_path=html_path,
            html_color_attribute=self.parameterAsString(parameters, self.HTML_COLOR_ATTRIBUTE, context) or 'floor_no',
            html_attribute_names=_parse_csv_names(self.parameterAsString(parameters, self.HTML_ATTRIBUTE_NAMES, context)),
        )
        try:
            generate_floor_polygons(input_paths, output_path, options, feedback)
        except Exception as e:
            raise QgsProcessingException(str(e))

        result_uri = output_path
        if output_path.lower().endswith('.gpkg'):
            result_uri = output_path + '|layername=' + layer_name
        return {self.OUTPUT: result_uri}


class FloorPolygonsToHtmlViewerAlgorithm(QgsProcessingAlgorithm):
    INPUT_LAYER = 'INPUT_LAYER'
    HTML_PATH = 'HTML_PATH'
    COLOR_FIELD = 'COLOR_FIELD'
    ATTRIBUTE_FIELDS = 'ATTRIBUTE_FIELDS'

    def tr(self, string):
        return string

    def createInstance(self):
        return FloorPolygonsToHtmlViewerAlgorithm()

    def name(self):
        return 'floorpolygonstohtmlviewer'

    def displayName(self):
        return '階別高さポリゴンからHTMLビューワーを更新'

    def group(self):
        return ''

    def groupId(self):
        return ''

    def shortHelpString(self):
        return (
            '既存の階別高さポリゴンレイヤから、HTMLビューワー（HTML + data.js）を更新します。\n\n'
            'QGIS上で属性を編集・追加したあとに、このツールを実行するとHTML側も更新できます。'
            'HTML保存先が未指定の場合は Windows のダウンロードフォルダに保存します。'
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(self.INPUT_LAYER, '入力：階別高さポリゴンレイヤ', [QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterString(self.HTML_PATH, 'HTML保存先（未指定ならダウンロードフォルダ）', defaultValue='', optional=True))
        self.addParameter(QgsProcessingParameterField(self.COLOR_FIELD, 'HTMLの初期色分け属性', parentLayerParameterName=self.INPUT_LAYER, type=QgsProcessingParameterField.Any, optional=True, allowMultiple=False, defaultValue='floor_no'))
        self.addParameter(QgsProcessingParameterField(self.ATTRIBUTE_FIELDS, 'HTMLに出力する属性', parentLayerParameterName=self.INPUT_LAYER, type=QgsProcessingParameterField.Any, optional=True, allowMultiple=True))

    def processAlgorithm(self, parameters, context, feedback):
        layer = self.parameterAsVectorLayer(parameters, self.INPUT_LAYER, context)
        if layer is None:
            raise QgsProcessingException('入力レイヤを指定してください。')
        html_path = self.parameterAsString(parameters, self.HTML_PATH, context)
        color_field = self.parameterAsString(parameters, self.COLOR_FIELD, context) or 'floor_no'
        attr_fields = self.parameterAsFields(parameters, self.ATTRIBUTE_FIELDS, context)
        try:
            html_path, data_path, cesium_path = generate_html_viewer_from_layer(
                layer,
                html_path,
                feedback=feedback,
                color_attribute=color_field,
                attribute_names=attr_fields,
                title=layer.name() or 'floor_polygons',
            )
        except Exception as e:
            raise QgsProcessingException(str(e))
        feedback.pushInfo(f'HTMLビューワー: {html_path}')
        feedback.pushInfo(f'HTMLデータ: {data_path}')
        feedback.pushInfo(f'Cesium版ビューワー（試作）: {cesium_path}')
        return {'HTML_PATH': html_path, 'DATA_JS': data_path, 'CESIUM_HTML': cesium_path}
