# -*- coding: utf-8 -*-

from __future__ import annotations

import os
import tempfile
from urllib.parse import unquote, urlparse

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsMapLayerType,
    QgsProject,
    QgsVectorLayer,
    QgsWkbTypes,
    Qgis,
)
from qgis.gui import QgsProjectionSelectionWidget

from .floor_generator import (
    DEFAULT_HTML_ATTRIBUTES,
    GenerateOptions,
    default_downloads_dir,
    fields as output_fields,
    generate_floor_polygons,
    generate_floor_polygons_memory,
    generate_html_viewer_from_layer,
)



def plugin_version() -> str:
    """metadata.txt の version を設定画面タイトルへ表示します。"""
    try:
        meta_path = os.path.join(os.path.dirname(__file__), 'metadata.txt')
        with open(meta_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.lower().startswith('version='):
                    return line.split('=', 1)[1].strip()
    except Exception:
        pass
    return ''

class DialogFeedback:
    def __init__(self, dialog: QDialog):
        self.dialog = dialog
        self.messages = []
        self._canceled = False

    def pushInfo(self, msg: str):
        self.messages.append(str(msg))
        QApplication.processEvents()

    def reportError(self, msg: str):
        self.messages.append('[ERROR] ' + str(msg))
        QApplication.processEvents()

    def isCanceled(self) -> bool:
        return self._canceled


class CityGML2FloorPolygonsDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.file_paths = []
        self.output_path = ''
        version = plugin_version()
        self.setWindowTitle(f'CityGML2FloorPolygons v{version}' if version else 'CityGML2FloorPolygons')
        self.resize(860, 700)
        self.setMinimumSize(700, 460)
        self.setSizeGripEnabled(True)
        self._build_ui()
        self.refresh_input_layers()
        self.refresh_html_update_layers()
        self._set_attribute_fields([f.name() for f in output_fields()], default=True)
        self._update_file_display()
        self._sync_output_mode()
        self._sync_html_enabled()

    def _build_ui(self):
        outer = QVBoxLayout(self)

        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        content = QWidget()
        root = QVBoxLayout(content)
        self.scroll_area.setWidget(content)
        outer.addWidget(self.scroll_area, 1)

        intro = QLabel('PLATEAU / CityGML の建築物から、階ごとの高さ属性 z_base / z_top を持つポリゴンを生成します。')
        intro.setWordWrap(True)
        root.addWidget(intro)

        input_box = QGroupBox('入力CityGML')
        input_layout = QVBoxLayout(input_box)
        file_row = QHBoxLayout()
        self.file_edit = QLineEdit()
        self.file_edit.setReadOnly(True)
        self.file_edit.setPlaceholderText('CityGML/GMLファイルを選択してください')
        self.btn_browse_files = QPushButton('CityGMLファイルを追加...')
        self.btn_browse_files.clicked.connect(self.browse_files)
        self.btn_clear_files = QPushButton('ファイルをクリア')
        self.btn_clear_files.clicked.connect(self.clear_files)
        file_row.addWidget(self.file_edit, 1)
        file_row.addWidget(self.btn_browse_files)
        file_row.addWidget(self.btn_clear_files)
        input_layout.addLayout(file_row)

        layer_btns = QHBoxLayout()
        layer_btns.addWidget(QLabel('読み込み済みCityGML/GMLレイヤ'))
        layer_btns.addStretch(1)
        self.btn_refresh_input = QPushButton('更新')
        self.btn_select_all_input = QPushButton('すべて選択')
        self.btn_clear_input = QPushButton('選択を解除')
        self.btn_refresh_input.clicked.connect(self.refresh_input_layers)
        self.btn_select_all_input.clicked.connect(lambda: self._set_all_checked(self.input_layer_list, True))
        self.btn_clear_input.clicked.connect(lambda: self._set_all_checked(self.input_layer_list, False))
        layer_btns.addWidget(self.btn_refresh_input)
        layer_btns.addWidget(self.btn_select_all_input)
        layer_btns.addWidget(self.btn_clear_input)
        input_layout.addLayout(layer_btns)
        self.input_layer_list = QListWidget()
        self.input_layer_list.setMaximumHeight(140)
        input_layout.addWidget(self.input_layer_list)
        root.addWidget(input_box)

        output_box = QGroupBox('出力')
        output_form = QFormLayout(output_box)
        self.layer_name = QLineEdit('floor_polygons')
        output_form.addRow('出力レイヤ名:', self.layer_name)
        self.output_crs = QgsProjectionSelectionWidget()
        self.output_crs.setCrs(QgsCoordinateReferenceSystem('EPSG:6668'))
        output_form.addRow('出力CRS:', self.output_crs)

        output_mode_row = QHBoxLayout()
        self.output_temp_radio = QRadioButton('一時レイヤとして出力')
        self.output_gpkg_radio = QRadioButton('GeoPackageに保存')
        self.output_temp_radio.setChecked(True)
        self.output_temp_radio.toggled.connect(self._sync_output_mode)
        self.output_gpkg_radio.toggled.connect(self._sync_output_mode)
        output_mode_row.addWidget(self.output_temp_radio)
        output_mode_row.addWidget(self.output_gpkg_radio)
        output_mode_row.addStretch(1)
        output_form.addRow('出力方法:', output_mode_row)

        out_row = QHBoxLayout()
        self.output_edit = QLineEdit()
        self.output_edit.setReadOnly(True)
        self.btn_output = QPushButton('...')
        self.btn_output.setFixedWidth(34)
        self.btn_output.clicked.connect(self.browse_output)
        out_row.addWidget(self.output_edit, 1)
        out_row.addWidget(self.btn_output)
        output_form.addRow('GeoPackage保存先:', out_row)

        self.add_to_project = QCheckBox('処理後に出力レイヤをQGISへ読み込む')
        self.add_to_project.setChecked(True)
        output_form.addRow('', self.add_to_project)
        root.addWidget(output_box)

        opt_box = QGroupBox('計算設定')
        opt_form = QFormLayout(opt_box)
        self.swap_axis = QCheckBox('PLATEAUの緯度・経度順を、QGIS用の経度・緯度順へ変換する')
        self.swap_axis.setChecked(True)
        opt_form.addRow('', self.swap_axis)
        self.polygon_z = QCheckBox('出力ジオメトリを床面Z付き PolygonZ にする')
        self.polygon_z.setChecked(False)
        opt_form.addRow('', self.polygon_z)
        self.footprint_combo = QComboBox()
        self.footprint_combo.addItems([
            'lod0RoofEdge / lod0FootPrint を優先し、なければ lod1Solid 下端面',
            'lod1Solid 下端面を優先し、なければ lod0RoofEdge / lod0FootPrint',
        ])
        opt_form.addRow('フットプリント:', self.footprint_combo)
        self.height_combo = QComboBox()
        self.height_combo.addItems(['bldg:measuredHeight を優先', 'lod1Solid の Z 範囲を優先'])
        self.height_combo.setCurrentIndex(0)
        opt_form.addRow('建物高さ:', self.height_combo)
        self.invalid_combo = QComboBox()
        self.invalid_combo.addItems(['階数または高さが無効な建物はスキップ', '建物全体を1階分として出力', '高さとデフォルト階高から階数を推定'])
        self.invalid_combo.setCurrentIndex(1)
        opt_form.addRow('無効値の扱い:', self.invalid_combo)
        self.default_floor_height = QDoubleSpinBox()
        self.default_floor_height.setDecimals(2)
        self.default_floor_height.setMinimum(0.10)
        self.default_floor_height.setMaximum(20.00)
        self.default_floor_height.setValue(3.00)
        self.default_floor_height.setSuffix(' m')
        opt_form.addRow('デフォルト階高:', self.default_floor_height)
        root.addWidget(opt_box)

        html_box = QGroupBox('HTMLビューワー')
        html_layout = QVBoxLayout(html_box)
        self.html_enable = QCheckBox('HTMLビューワーを出力する')
        self.html_enable.setChecked(False)
        self.html_enable.toggled.connect(self._on_html_enabled)
        html_layout.addWidget(self.html_enable)
        html_row = QHBoxLayout()
        self.html_path_edit = QLineEdit()
        self.html_path_edit.setPlaceholderText('HTML保存先（未指定ならGeoPackage保存先／一時レイヤはDownloads）')
        self.btn_html_path = QPushButton('...')
        self.btn_html_path.setFixedWidth(34)
        self.btn_html_path.clicked.connect(self.browse_html_output)
        html_row.addWidget(self.html_path_edit, 1)
        html_row.addWidget(self.btn_html_path)
        html_layout.addLayout(html_row)

        attrs_header = QHBoxLayout()
        attrs_header.addWidget(QLabel('HTMLに出力する属性'))
        attrs_header.addStretch(1)
        self.btn_attr_default = QPushButton('標準属性')
        self.btn_attr_all = QPushButton('すべて選択')
        self.btn_attr_clear = QPushButton('選択を解除')
        self.btn_attr_default.clicked.connect(lambda: self._set_default_attrs())
        self.btn_attr_all.clicked.connect(lambda: self._set_all_checked(self.attr_list, True))
        self.btn_attr_clear.clicked.connect(lambda: self._set_all_checked(self.attr_list, False))
        attrs_header.addWidget(self.btn_attr_default)
        attrs_header.addWidget(self.btn_attr_all)
        attrs_header.addWidget(self.btn_attr_clear)
        html_layout.addLayout(attrs_header)
        self.attr_list = QListWidget()
        self.attr_list.setMaximumHeight(150)
        html_layout.addWidget(self.attr_list)
        color_row = QFormLayout()
        self.color_attr_combo = QComboBox()
        color_row.addRow('HTMLの初期色分け属性:', self.color_attr_combo)
        self.color_scheme_combo = QComboBox()
        self.color_scheme_combo.addItem('レインボー（階別・前の色）', 'floorRainbow')
        self.color_scheme_combo.addItem('連続レインボー（紫→青→緑→黄→赤）', 'rainbow')
        self.color_scheme_combo.addItem('紫→青緑→黄', 'viridis')
        self.color_scheme_combo.addItem('茶→白→緑', 'terrain')
        self.color_scheme_combo.addItem('黄→橙→赤', 'heat')
        self.color_scheme_combo.addItem('ピンク→白→緑', 'pinkgreen')
        self.color_scheme_combo.addItem('赤→黄→青', 'redblue')
        color_row.addRow('カラーバリエーション:', self.color_scheme_combo)
        html_layout.addLayout(color_row)

        update_box = QGroupBox('既存の階別高さポリゴンからHTMLを更新')
        update_form = QFormLayout(update_box)
        update_layer_row = QHBoxLayout()
        self.update_layer_combo = QComboBox()
        self.update_layer_combo.currentIndexChanged.connect(self._on_update_layer_changed)
        self.btn_refresh_update_layers = QPushButton('更新')
        self.btn_refresh_update_layers.clicked.connect(self.refresh_html_update_layers)
        update_layer_row.addWidget(self.update_layer_combo, 1)
        update_layer_row.addWidget(self.btn_refresh_update_layers)
        update_form.addRow('入力レイヤ:', update_layer_row)
        self.btn_update_html_only = QPushButton('HTMLだけ更新')
        self.btn_update_html_only.clicked.connect(self.update_html_only)
        update_form.addRow('', self.btn_update_html_only)
        html_layout.addWidget(update_box)
        root.addWidget(html_box)

        note = QLabel('計算: storeyHeightsAboveGround があれば優先します。なければ選択した建物高さを storeysAboveGround で割って平均階高にします。2階の z_base は、1階の z_top と同じ値になります。HTMLは HTML + data.js の2ファイルで作成します。')
        note.setWordWrap(True)
        root.addWidget(note)

        self.buttons = QDialogButtonBox()
        self.btn_run = self.buttons.addButton('実行', QDialogButtonBox.AcceptRole)
        self.btn_close = self.buttons.addButton('閉じる', QDialogButtonBox.RejectRole)
        self.btn_run.clicked.connect(self.run)
        self.btn_close.clicked.connect(self.reject)
        outer.addWidget(self.buttons)

    def _set_all_checked(self, list_widget: QListWidget, checked: bool):
        state = Qt.Checked if checked else Qt.Unchecked
        for i in range(list_widget.count()):
            list_widget.item(i).setCheckState(state)

    def _set_attribute_fields(self, names, default=True):
        current_color = self.color_attr_combo.currentText() if hasattr(self, 'color_attr_combo') else ''
        self.attr_list.clear()
        self.color_attr_combo.clear()
        seen = []
        for name in names:
            if name and name not in seen:
                seen.append(name)
        for name in seen:
            item = QListWidgetItem(name)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setData(Qt.UserRole, name)
            item.setCheckState(Qt.Checked if (not default or name in DEFAULT_HTML_ATTRIBUTES) else Qt.Unchecked)
            self.attr_list.addItem(item)
            self.color_attr_combo.addItem(name)
        # 初期色分け属性は必ず floor_no を優先します。
        # gml_id だと建物ごとのカテゴリ色になり、階層の見た目が分かりにくくなるためです。
        idx = self.color_attr_combo.findText('floor_no')
        if idx < 0 and current_color and current_color != 'gml_id':
            idx = self.color_attr_combo.findText(current_color)
        self.color_attr_combo.setCurrentIndex(idx if idx >= 0 else 0)

    def _set_default_attrs(self):
        for i in range(self.attr_list.count()):
            item = self.attr_list.item(i)
            item.setCheckState(Qt.Checked if item.data(Qt.UserRole) in DEFAULT_HTML_ATTRIBUTES else Qt.Unchecked)

    def _checked_attrs(self):
        out = []
        for i in range(self.attr_list.count()):
            item = self.attr_list.item(i)
            if item.checkState() == Qt.Checked:
                out.append(item.data(Qt.UserRole))
        return out

    def _on_html_enabled(self, checked):
        self._sync_html_enabled()
        if checked and not self.html_path_edit.text().strip():
            # キャンセルされた場合は、実行時にダウンロードフォルダへ自動保存します。
            self.browse_html_output(silent_cancel=True)

    def _sync_html_enabled(self):
        enabled = self.html_enable.isChecked()
        for w in [self.html_path_edit, self.btn_html_path, self.attr_list, self.color_attr_combo, self.color_scheme_combo, self.btn_attr_default, self.btn_attr_all, self.btn_attr_clear]:
            w.setEnabled(enabled)

    def _first_input_dir(self):
        candidates = []
        candidates.extend(getattr(self, 'file_paths', []) or [])
        try:
            candidates.extend(self.checked_input_layer_paths())
        except Exception:
            pass
        for p in candidates:
            if not p:
                continue
            d = os.path.dirname(os.path.normpath(p))
            if d and os.path.isdir(d):
                return d
        return ''

    def _gpkg_start_path(self):
        if self.output_path:
            return self.output_path
        start_dir = self._first_input_dir() or default_downloads_dir()
        return os.path.join(start_dir, 'citygml_floor_polygons.gpkg')

    def _html_start_dir(self):
        html_path = self.html_path_edit.text().strip() if hasattr(self, 'html_path_edit') else ''
        if html_path:
            d = os.path.dirname(os.path.normpath(html_path))
            if d and os.path.isdir(d):
                return d
        if self.output_path:
            d = os.path.dirname(os.path.normpath(self.output_path))
            if d and os.path.isdir(d):
                return d
        input_dir = self._first_input_dir()
        if input_dir:
            return input_dir
        return default_downloads_dir()

    def browse_files(self):
        start_dir = self._first_input_dir() or ''
        files, _ = QFileDialog.getOpenFileNames(self, 'CityGMLファイルを選択', start_dir, 'CityGML/GML (*.gml *.xml *.citygml);;All files (*.*)')
        if files:
            self.file_paths = [os.path.normpath(p) for p in files]
            self._update_file_display()

    def clear_files(self):
        self.file_paths = []
        self._update_file_display()

    def _update_file_display(self):
        if not self.file_paths:
            self.file_edit.setText('')
        elif len(self.file_paths) == 1:
            self.file_edit.setText(self.file_paths[0])
        else:
            self.file_edit.setText(f'{len(self.file_paths)} 個のファイルが選択されました')

    def refresh_input_layers(self):
        checked_paths = set(self.checked_input_layer_paths()) if hasattr(self, 'input_layer_list') else set()
        self.input_layer_list.clear()
        for layer in QgsProject.instance().mapLayers().values():
            try:
                if layer.type() != QgsMapLayerType.VectorLayer:
                    continue
                path = clean_source_to_path(layer.source())
                if not path or not path.lower().endswith(('.gml', '.xml', '.citygml')):
                    continue
                label = f'{layer.name()} [{layer.crs().authid()}]'
                item = QListWidgetItem(label)
                item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                item.setData(Qt.UserRole, path)
                item.setCheckState(Qt.Checked if path in checked_paths else Qt.Unchecked)
                self.input_layer_list.addItem(item)
            except Exception:
                continue

    def checked_input_layer_paths(self):
        out = []
        for i in range(self.input_layer_list.count()):
            item = self.input_layer_list.item(i)
            if item.checkState() == Qt.Checked:
                out.append(item.data(Qt.UserRole))
        return out

    def refresh_html_update_layers(self):
        current = self.update_layer_combo.currentData() if hasattr(self, 'update_layer_combo') else None
        self.update_layer_combo.blockSignals(True)
        self.update_layer_combo.clear()
        for layer in QgsProject.instance().mapLayers().values():
            try:
                if layer.type() != QgsMapLayerType.VectorLayer:
                    continue
                if QgsWkbTypes.geometryType(layer.wkbType()) != QgsWkbTypes.PolygonGeometry:
                    continue
                self.update_layer_combo.addItem(f'{layer.name()} [{layer.crs().authid()}]', layer.id())
            except Exception:
                continue
        if current:
            idx = self.update_layer_combo.findData(current)
            if idx >= 0:
                self.update_layer_combo.setCurrentIndex(idx)
        self.update_layer_combo.blockSignals(False)
        self._on_update_layer_changed()

    def _selected_update_layer(self):
        lid = self.update_layer_combo.currentData()
        return QgsProject.instance().mapLayer(lid) if lid else None

    def _on_update_layer_changed(self):
        layer = self._selected_update_layer()
        if layer:
            self._set_attribute_fields([f.name() for f in layer.fields()], default=True)
        else:
            self._set_attribute_fields([f.name() for f in output_fields()], default=True)

    def browse_output(self):
        start = self._gpkg_start_path()
        path, _ = QFileDialog.getSaveFileName(self, 'GeoPackage保存先を指定', start, 'GeoPackage (*.gpkg);;All files (*.*)')
        if not path:
            return
        if not path.lower().endswith('.gpkg'):
            path += '.gpkg'
        self.output_path = os.path.normpath(path)
        self.output_gpkg_radio.setChecked(True)
        self._update_output_display()

    def _sync_output_mode(self):
        save_mode = self.output_gpkg_radio.isChecked()
        self.output_edit.setEnabled(save_mode)
        self.btn_output.setEnabled(save_mode)
        self._update_output_display()

    def _update_output_display(self):
        if self.output_temp_radio.isChecked():
            self.output_edit.setText('[QGISの一時レイヤとして出力]')
        else:
            self.output_edit.setText(self.output_path if self.output_path else '[GeoPackage保存先を指定してください]')

    def _is_temporary_output(self):
        return self.output_temp_radio.isChecked()

    def browse_html_output(self, silent_cancel=False):
        start_dir = self._html_start_dir()
        path, _ = QFileDialog.getSaveFileName(self, 'HTMLビューワーの保存先を指定', os.path.join(start_dir, 'floor_polygons_viewer.html'), 'HTML files (*.html *.htm);;All files (*.*)')
        if path:
            if not path.lower().endswith(('.html', '.htm')):
                path += '.html'
            self.html_path_edit.setText(os.path.normpath(path))
        elif not silent_cancel:
            pass

    def _resolved_output_path(self):
        return self.output_path if self.output_path else ''

    def input_paths(self):
        out = []
        seen = set()
        for p in list(self.file_paths) + list(self.checked_input_layer_paths()):
            if not p:
                continue
            p = os.path.normpath(p)
            if p in seen:
                continue
            seen.add(p)
            out.append(p)
        return out

    def _make_options(self, layer_name, html_enabled):
        crs = self.output_crs.crs()
        crs_authid = crs.authid() if crs and crs.isValid() else 'EPSG:6668'
        return GenerateOptions(
            output_crs_authid=crs_authid,
            swap_axis=self.swap_axis.isChecked(),
            footprint_source=self.footprint_combo.currentIndex(),
            height_source=self.height_combo.currentIndex(),
            invalid_handling=self.invalid_combo.currentIndex(),
            default_floor_height=self.default_floor_height.value(),
            polygon_z=self.polygon_z.isChecked(),
            layer_name=layer_name,
            html_viewer=html_enabled,
            html_output_path=self.html_path_edit.text().strip(),
            html_color_attribute=self.color_attr_combo.currentText() or 'floor_no',
            html_color_scheme=self.color_scheme_combo.currentData() or 'floorRainbow',
            html_attribute_names=self._checked_attrs(),
        )

    def run(self):
        input_paths = self.input_paths()
        if not input_paths:
            QMessageBox.warning(self, 'CityGML2FloorPolygons', '入力CityGMLファイル、または読み込み済みCityGML/GMLレイヤを指定してください。')
            return

        layer_name = self.layer_name.text().strip() or 'floor_polygons'
        temporary_output = self._is_temporary_output()
        output_path = '' if temporary_output else self._resolved_output_path()
        if not temporary_output and not output_path:
            QMessageBox.warning(self, 'CityGML2FloorPolygons', 'GeoPackageに保存する場合は、保存先を指定してください。')
            return

        options = self._make_options(layer_name, self.html_enable.isChecked())
        feedback = DialogFeedback(self)
        self.btn_run.setEnabled(False)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        output_layer = None
        try:
            if temporary_output:
                stats, output_layer = generate_floor_polygons_memory(input_paths, options, feedback)
            else:
                stats = generate_floor_polygons(input_paths, output_path, options, feedback)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            self.btn_run.setEnabled(True)
            QMessageBox.critical(self, 'CityGML2FloorPolygons', f'処理に失敗しました。\n\n{e}')
            return
        finally:
            try:
                QApplication.restoreOverrideCursor()
            except Exception:
                pass
            self.btn_run.setEnabled(True)

        if self.add_to_project.isChecked():
            if temporary_output:
                if output_layer is not None and output_layer.isValid():
                    QgsProject.instance().addMapLayer(output_layer)
                else:
                    self.iface.messageBar().pushMessage('CityGML2FloorPolygons', '一時レイヤのQGISへの追加に失敗しました。', level=Qgis.Warning, duration=6)
            else:
                uri = f'{output_path}|layername={layer_name}' if output_path.lower().endswith('.gpkg') else output_path
                vl = QgsVectorLayer(uri, layer_name, 'ogr')
                if vl.isValid():
                    QgsProject.instance().addMapLayer(vl)
                else:
                    self.iface.messageBar().pushMessage('CityGML2FloorPolygons', '出力は作成されましたが、QGISへの読み込みに失敗しました。', level=Qgis.Warning, duration=6)

        output_desc = 'QGIS一時レイヤ（メモリ）' if temporary_output else output_path
        msg = (f'完了しました。\n\n入力ファイル数: {len(input_paths)}\n建物数: {stats.buildings}\n出力フィーチャ数: {stats.output_features}\n'
               f'スキップ（ジオメトリなし）: {stats.skipped_no_geom}\nスキップ（階数・高さが無効）: {stats.skipped_invalid}\nスキップ（エラー）: {stats.skipped_error}\n\n出力: {output_desc}')
        if getattr(stats, 'html_path', ''):
            msg += f'\nHTMLビューワー: {stats.html_path}\nHTMLデータ: {stats.html_data_path}'
            if getattr(stats, 'cesium_html_path', ''):
                msg += f'\nCesium版ビューワー（試作）: {stats.cesium_html_path}'
        QMessageBox.information(self, 'CityGML2FloorPolygons', msg)
        self.refresh_html_update_layers()

    def update_html_only(self):
        layer = self._selected_update_layer()
        if not layer:
            QMessageBox.warning(self, 'CityGML2FloorPolygons', 'HTML更新に使う階別高さポリゴンレイヤを選択してください。')
            return
        feedback = DialogFeedback(self)
        self.btn_update_html_only.setEnabled(False)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            html_path, data_path, cesium_path = generate_html_viewer_from_layer(
                layer,
                self.html_path_edit.text().strip(),
                feedback=feedback,
                color_attribute=self.color_attr_combo.currentText() or 'floor_no',
                color_scheme=self.color_scheme_combo.currentData() or 'floorRainbow',
                attribute_names=self._checked_attrs(),
                title=layer.name(),
            )
        except Exception as e:
            QApplication.restoreOverrideCursor()
            self.btn_update_html_only.setEnabled(True)
            QMessageBox.critical(self, 'CityGML2FloorPolygons', f'HTML更新に失敗しました。\n\n{e}')
            return
        finally:
            try:
                QApplication.restoreOverrideCursor()
            except Exception:
                pass
            self.btn_update_html_only.setEnabled(True)
        QMessageBox.information(self, 'CityGML2FloorPolygons', f'HTMLを更新しました。\n\nHTMLビューワー: {html_path}\nHTMLデータ: {data_path}\nCesium版ビューワー（試作）: {cesium_path}')


def clean_source_to_path(source: str) -> str:
    if not source:
        return ''
    src = source.split('|', 1)[0]
    if src.startswith('file:'):
        parsed = urlparse(src)
        if parsed.scheme == 'file':
            src = unquote(parsed.path)
            if os.name == 'nt' and len(src) >= 3 and src[0] == '/' and src[2] == ':':
                src = src[1:]
    return os.path.normpath(src)
