# -*- coding: utf-8 -*-

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

from qgis.PyQt.QtCore import QVariant, QStandardPaths
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)

from .plateau_parser import PlateauBuilding, iter_buildings


DEFAULT_HTML_ATTRIBUTES = [
    'gml_id', 'building_id', 'floor_no', 'floor_label', 'is_underground',
    'floors_used', 'floor_h', 'ground_z', 'z_base', 'z_top', 'src_file'
]


@dataclass
class GenerateOptions:
    output_crs_authid: str = 'EPSG:6668'
    swap_axis: bool = True
    footprint_source: int = 0
    height_source: int = 0
    invalid_handling: int = 1
    default_floor_height: float = 3.0
    polygon_z: bool = False
    layer_name: str = 'floor_polygons'
    html_viewer: bool = False
    html_output_path: str = ''
    html_color_attribute: str = 'floor_no'
    html_color_scheme: str = 'rainbow'
    html_attribute_names: Optional[List[str]] = None


@dataclass
class GenerateStats:
    buildings: int = 0
    output_features: int = 0
    skipped_no_geom: int = 0
    skipped_invalid: int = 0
    skipped_error: int = 0
    files: int = 0
    html_path: str = ''
    html_data_path: str = ''
    cesium_html_path: str = ''


class NullFeedback:
    def pushInfo(self, msg: str):
        pass

    def reportError(self, msg: str):
        pass

    def isCanceled(self) -> bool:
        return False


def fields() -> QgsFields:
    f = QgsFields()
    f.append(QgsField('gml_id', QVariant.String, 'string', 120))
    f.append(QgsField('building_id', QVariant.String, 'string', 90))
    f.append(QgsField('obj_type', QVariant.String, 'string', 20))
    f.append(QgsField('floor_no', QVariant.Int))
    f.append(QgsField('floor_label', QVariant.String, 'string', 12))
    f.append(QgsField('is_underground', QVariant.Int))
    f.append(QgsField('floors_used', QVariant.Int))
    f.append(QgsField('storeys_raw', QVariant.Int))
    f.append(QgsField('storeys_b', QVariant.Int))
    f.append(QgsField('meas_h', QVariant.Double, 'double', 20, 4))
    f.append(QgsField('lod1_h', QVariant.Double, 'double', 20, 4))
    f.append(QgsField('total_h', QVariant.Double, 'double', 20, 4))
    f.append(QgsField('floor_h', QVariant.Double, 'double', 20, 4))
    f.append(QgsField('floor_z', QVariant.Double, 'double', 20, 4))
    f.append(QgsField('ceiling_z', QVariant.Double, 'double', 20, 4))
    f.append(QgsField('rel_floor', QVariant.Double, 'double', 20, 4))
    f.append(QgsField('rel_ceiling', QVariant.Double, 'double', 20, 4))
    f.append(QgsField('ground_z', QVariant.Double, 'double', 20, 4))
    f.append(QgsField('z_base', QVariant.Double, 'double', 20, 4))
    f.append(QgsField('z_top', QVariant.Double, 'double', 20, 4))
    f.append(QgsField('h_method', QVariant.String, 'string', 90))
    f.append(QgsField('height_src', QVariant.String, 'string', 90))
    f.append(QgsField('ground_src', QVariant.String, 'string', 90))
    f.append(QgsField('geom_src', QVariant.String, 'string', 90))
    f.append(QgsField('geom_z', QVariant.String, 'string', 20))
    f.append(QgsField('src_file', QVariant.String, 'string', 180))
    return f


def generate_floor_polygons(input_paths: List[str], output_path: str, options: GenerateOptions, feedback=None) -> GenerateStats:
    feedback = feedback or NullFeedback()
    stats = GenerateStats(files=len(input_paths))

    valid_inputs = []
    for p in input_paths:
        if p and os.path.exists(p):
            valid_inputs.append(p)
        else:
            feedback.reportError(f'入力ファイルが見つかりません: {p}')
    if not valid_inputs:
        raise ValueError('入力CityGMLファイルが見つかりません。')

    output_path = _normalize_output_path(output_path)
    crs = QgsCoordinateReferenceSystem(options.output_crs_authid or 'EPSG:6668')
    if not crs.isValid():
        crs = QgsCoordinateReferenceSystem('EPSG:6668')

    out_fields = fields()
    wkb_type = QgsWkbTypes.MultiPolygonZ if options.polygon_z else QgsWkbTypes.MultiPolygon

    if os.path.dirname(output_path):
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
    save_options = QgsVectorFileWriter.SaveVectorOptions()
    save_options.driverName = _driver_for_path(output_path)
    save_options.fileEncoding = 'UTF-8'
    if save_options.driverName == 'GPKG':
        save_options.layerName = options.layer_name or 'floor_polygons'
        if os.path.exists(output_path):
            save_options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        else:
            save_options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    else:
        save_options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile

    writer = QgsVectorFileWriter.create(
        output_path,
        out_fields,
        wkb_type,
        crs,
        QgsProject.instance().transformContext(),
        save_options,
    )
    if writer.hasError() != QgsVectorFileWriter.NoError:
        err = writer.errorMessage() if hasattr(writer, 'errorMessage') else str(writer.hasError())
        raise ValueError(f'出力ファイルを作成できませんでした: {err}')

    viewer_features: List[Dict] = []
    viewer_bounds = {'minx': None, 'maxx': None, 'miny': None, 'maxy': None, 'minz': None, 'maxz': None}
    html_attrs = _normalize_attribute_names(options.html_attribute_names)

    feedback.pushInfo('CityGMLを読み込み中...')
    feedback.pushInfo('floor_z は当該階の床面高さ、ceiling_z は当該階の天井高さです。2階の floor_z は1階の ceiling_z と同じ高さになります。')

    for input_path in valid_inputs:
        if feedback.isCanceled():
            break
        feedback.pushInfo(f'入力: {os.path.basename(input_path)}')
        for b in iter_buildings(input_path):
            if feedback.isCanceled():
                break
            stats.buildings += 1
            if stats.buildings % 500 == 0:
                feedback.pushInfo(f'{stats.buildings} 棟を処理中... 出力 {stats.output_features} フィーチャ')
            try:
                mp = select_footprint(b, options.footprint_source)
                if not mp:
                    stats.skipped_no_geom += 1
                    continue

                ground_z, ground_method = ground_z_method(b)
                total_height, total_height_method = total_height_method_for(b, options.height_source)

                floor_heights, floors_used, height_method = floor_heights_for(
                    b=b,
                    total_height=total_height,
                    total_height_method=total_height_method,
                    invalid_handling=options.invalid_handling,
                    default_floor_height=options.default_floor_height,
                )
                below_heights, below_floors_used, below_height_method = below_floor_heights_for(
                    b=b,
                    default_floor_height=options.default_floor_height,
                )
                if not floor_heights and not below_heights:
                    stats.skipped_invalid += 1
                    continue

                if below_heights:
                    z_current_below = ground_z
                    rel_current_below = 0.0
                    for below_idx, floor_h in enumerate(below_heights, start=1):
                        floor_z = z_current_below - floor_h
                        ceiling_z = z_current_below
                        rel_floor = rel_current_below - floor_h
                        rel_ceiling = rel_current_below
                        floor_no = -below_idx
                        floor_label = floor_label_for(floor_no)

                        geom = multipolygon_geometry(mp, options.swap_axis, floor_z if options.polygon_z else None)
                        if geom is None or geom.isEmpty():
                            stats.skipped_no_geom += 1
                            break

                        attr_values = {
                            'gml_id': b.gml_id,
                            'building_id': b.building_id,
                            'obj_type': b.object_type,
                            'floor_no': floor_no,
                            'floor_label': floor_label,
                            'is_underground': 1,
                            'floors_used': below_floors_used,
                            'storeys_raw': b.storeys_above_ground if b.storeys_above_ground is not None else None,
                            'storeys_b': b.storeys_below_ground if b.storeys_below_ground is not None else None,
                            'meas_h': b.measured_height if b.measured_height is not None else None,
                            'lod1_h': lod1_height(b),
                            'total_h': sum(below_heights),
                            'floor_h': floor_h,
                            'floor_z': floor_z,
                            'ceiling_z': ceiling_z,
                            'rel_floor': rel_floor,
                            'rel_ceiling': rel_ceiling,
                            'ground_z': ground_z,
                            'z_base': floor_z,
                            'z_top': ceiling_z,
                            'h_method': below_height_method,
                            'height_src': 'storeysBelowGround',
                            'ground_src': ground_method,
                            'geom_src': footprint_method(b, options.footprint_source),
                            'geom_z': 'PolygonZ_floor_z' if options.polygon_z else '2D_attributes_only',
                            'src_file': b.source_file,
                        }

                        feat = QgsFeature(out_fields)
                        feat.setGeometry(geom)
                        feat.setAttributes([attr_values[fld.name()] for fld in out_fields])
                        writer.addFeature(feat)
                        stats.output_features += 1

                        if options.html_viewer:
                            _append_viewer_feature(
                                viewer_features,
                                viewer_bounds,
                                b,
                                mp,
                                options.swap_axis,
                                floor_no,
                                below_floors_used,
                                floor_h,
                                floor_z,
                                ceiling_z,
                                ground_z,
                                b.source_file,
                                _select_attrs_map(attr_values, html_attrs),
                            )

                        z_current_below = floor_z
                        rel_current_below = rel_floor

                z_current = ground_z
                rel_current = 0.0
                for idx, floor_h in enumerate(floor_heights, start=1):
                    floor_z = z_current
                    ceiling_z = z_current + floor_h
                    rel_floor = rel_current
                    rel_ceiling = rel_current + floor_h

                    geom = multipolygon_geometry(mp, options.swap_axis, floor_z if options.polygon_z else None)
                    if geom is None or geom.isEmpty():
                        stats.skipped_no_geom += 1
                        break

                    attr_values = {
                        'gml_id': b.gml_id,
                        'building_id': b.building_id,
                        'obj_type': b.object_type,
                        'floor_no': idx,
                        'floor_label': floor_label_for(idx),
                        'is_underground': 0,
                        'floors_used': floors_used,
                        'storeys_raw': b.storeys_above_ground if b.storeys_above_ground is not None else None,
                        'storeys_b': b.storeys_below_ground if b.storeys_below_ground is not None else None,
                        'meas_h': b.measured_height if b.measured_height is not None else None,
                        'lod1_h': lod1_height(b),
                        'total_h': sum(floor_heights),
                        'floor_h': floor_h,
                        'floor_z': floor_z,
                        'ceiling_z': ceiling_z,
                        'rel_floor': rel_floor,
                        'rel_ceiling': rel_ceiling,
                        'ground_z': ground_z,
                        'z_base': floor_z,
                        'z_top': ceiling_z,
                        'h_method': height_method,
                        'height_src': total_height_method,
                        'ground_src': ground_method,
                        'geom_src': footprint_method(b, options.footprint_source),
                        'geom_z': 'PolygonZ_floor_z' if options.polygon_z else '2D_attributes_only',
                        'src_file': b.source_file,
                    }

                    feat = QgsFeature(out_fields)
                    feat.setGeometry(geom)
                    feat.setAttributes([attr_values[fld.name()] for fld in out_fields])
                    writer.addFeature(feat)
                    stats.output_features += 1

                    if options.html_viewer:
                        _append_viewer_feature(
                            viewer_features,
                            viewer_bounds,
                            b,
                            mp,
                            options.swap_axis,
                            idx,
                            floors_used,
                            floor_h,
                            floor_z,
                            ceiling_z,
                            ground_z,
                            b.source_file,
                            _select_attrs_map(attr_values, html_attrs),
                        )

                    z_current = ceiling_z
                    rel_current = rel_ceiling

            except Exception as e:
                stats.skipped_error += 1
                feedback.reportError(f'{b.gml_id or "(no gml:id)"}: {e}')
                continue

    del writer

    if options.html_viewer and viewer_features:
        html_path = resolve_html_path(options.html_output_path, output_path, options.layer_name or 'floor_polygons')
        try:
            html_path, data_path, cesium_path = write_html_viewer(
                html_path,
                viewer_features,
                viewer_bounds,
                options.layer_name or 'floor_polygons',
                default_color_attribute=options.html_color_attribute or 'floor_no',
                default_color_scheme=options.html_color_scheme or 'rainbow',
                selected_attributes=html_attrs,
            )
            stats.html_path = html_path
            stats.html_data_path = data_path
            stats.cesium_html_path = cesium_path
            feedback.pushInfo(f'HTMLビューワー: {html_path}')
            feedback.pushInfo(f'HTMLデータ: {data_path}')
            feedback.pushInfo(f'Cesium版ビューワー（試作）: {cesium_path}')
        except Exception as e:
            feedback.reportError(f'HTMLビューワーの作成に失敗しました: {e}')

    feedback.pushInfo('処理完了')
    feedback.pushInfo(f'建物数: {stats.buildings}')
    feedback.pushInfo(f'出力フィーチャ数: {stats.output_features}')
    feedback.pushInfo(f'スキップ（ジオメトリなし）: {stats.skipped_no_geom}')
    feedback.pushInfo(f'スキップ（階数・高さが無効）: {stats.skipped_invalid}')
    feedback.pushInfo(f'スキップ（エラー）: {stats.skipped_error}')
    return stats



def generate_floor_polygons_memory(input_paths: List[str], options: GenerateOptions, feedback=None):
    """CityGMLからQGISのメモリレイヤを作成します。

    ファイルは作成しません。HTMLビューワーをONにしている場合だけ、HTML/data.jsは指定先または
    ダウンロードフォルダへ保存します。
    """
    feedback = feedback or NullFeedback()
    stats = GenerateStats(files=len(input_paths))

    valid_inputs = []
    for p in input_paths:
        if p and os.path.exists(p):
            valid_inputs.append(p)
        else:
            feedback.reportError(f'入力ファイルが見つかりません: {p}')
    if not valid_inputs:
        raise ValueError('入力CityGMLファイルが見つかりません。')

    crs = QgsCoordinateReferenceSystem(options.output_crs_authid or 'EPSG:6668')
    if not crs.isValid():
        crs = QgsCoordinateReferenceSystem('EPSG:6668')

    layer_name = options.layer_name or 'floor_polygons'
    geom_type = 'MultiPolygonZ' if options.polygon_z else 'MultiPolygon'
    uri = f'{geom_type}?crs={crs.authid()}'
    layer = QgsVectorLayer(uri, layer_name, 'memory')
    if not layer.isValid() and options.polygon_z:
        # 環境によってZ付きmemory URIが通らない場合の保険です。
        layer = QgsVectorLayer(f'MultiPolygon?crs={crs.authid()}', layer_name, 'memory')
    if not layer.isValid():
        raise ValueError('一時レイヤを作成できませんでした。')

    out_fields = fields()
    provider = layer.dataProvider()
    provider.addAttributes(list(out_fields))
    layer.updateFields()

    viewer_features: List[Dict] = []
    viewer_bounds = {'minx': None, 'maxx': None, 'miny': None, 'maxy': None, 'minz': None, 'maxz': None}
    html_attrs = _normalize_attribute_names(options.html_attribute_names)

    feedback.pushInfo('CityGMLを読み込み中...')
    feedback.pushInfo('一時レイヤとして出力します。Windows TempのGeoPackageは作成しません。')
    feedback.pushInfo('floor_z は当該階の床面高さ、ceiling_z は当該階の天井高さです。2階の floor_z は1階の ceiling_z と同じ高さになります。')

    batch = []
    batch_size = 500

    for input_path in valid_inputs:
        if feedback.isCanceled():
            break
        feedback.pushInfo(f'入力: {os.path.basename(input_path)}')
        for b in iter_buildings(input_path):
            if feedback.isCanceled():
                break
            stats.buildings += 1
            if stats.buildings % 500 == 0:
                feedback.pushInfo(f'{stats.buildings} 棟を処理中... 出力 {stats.output_features} フィーチャ')
            try:
                mp = select_footprint(b, options.footprint_source)
                if not mp:
                    stats.skipped_no_geom += 1
                    continue

                ground_z, ground_method = ground_z_method(b)
                total_height, total_height_method = total_height_method_for(b, options.height_source)
                floor_heights, floors_used, height_method = floor_heights_for(
                    b=b,
                    total_height=total_height,
                    total_height_method=total_height_method,
                    invalid_handling=options.invalid_handling,
                    default_floor_height=options.default_floor_height,
                )
                below_heights, below_floors_used, below_height_method = below_floor_heights_for(
                    b=b,
                    default_floor_height=options.default_floor_height,
                )
                if not floor_heights and not below_heights:
                    stats.skipped_invalid += 1
                    continue

                if below_heights:
                    z_current_below = ground_z
                    rel_current_below = 0.0
                    for below_idx, floor_h in enumerate(below_heights, start=1):
                        floor_z = z_current_below - floor_h
                        ceiling_z = z_current_below
                        rel_floor = rel_current_below - floor_h
                        rel_ceiling = rel_current_below
                        floor_no = -below_idx
                        floor_label = floor_label_for(floor_no)

                        geom = multipolygon_geometry(mp, options.swap_axis, floor_z if options.polygon_z else None)
                        if geom is None or geom.isEmpty():
                            stats.skipped_no_geom += 1
                            break

                        attr_values = {
                            'gml_id': b.gml_id,
                            'building_id': b.building_id,
                            'obj_type': b.object_type,
                            'floor_no': floor_no,
                            'floor_label': floor_label,
                            'is_underground': 1,
                            'floors_used': below_floors_used,
                            'storeys_raw': b.storeys_above_ground if b.storeys_above_ground is not None else None,
                            'storeys_b': b.storeys_below_ground if b.storeys_below_ground is not None else None,
                            'meas_h': b.measured_height if b.measured_height is not None else None,
                            'lod1_h': lod1_height(b),
                            'total_h': sum(below_heights),
                            'floor_h': floor_h,
                            'floor_z': floor_z,
                            'ceiling_z': ceiling_z,
                            'rel_floor': rel_floor,
                            'rel_ceiling': rel_ceiling,
                            'ground_z': ground_z,
                            'z_base': floor_z,
                            'z_top': ceiling_z,
                            'h_method': below_height_method,
                            'height_src': 'storeysBelowGround',
                            'ground_src': ground_method,
                            'geom_src': footprint_method(b, options.footprint_source),
                            'geom_z': 'PolygonZ_floor_z' if options.polygon_z else '2D_attributes_only',
                            'src_file': b.source_file,
                        }

                        feat = QgsFeature(out_fields)
                        feat.setGeometry(geom)
                        feat.setAttributes([attr_values[fld.name()] for fld in out_fields])
                        batch.append(feat)
                        stats.output_features += 1
                        if len(batch) >= batch_size:
                            provider.addFeatures(batch)
                            batch = []

                        if options.html_viewer:
                            _append_viewer_feature(
                                viewer_features,
                                viewer_bounds,
                                b,
                                mp,
                                options.swap_axis,
                                floor_no,
                                below_floors_used,
                                floor_h,
                                floor_z,
                                ceiling_z,
                                ground_z,
                                b.source_file,
                                _select_attrs_map(attr_values, html_attrs),
                            )

                        z_current_below = floor_z
                        rel_current_below = rel_floor

                z_current = ground_z
                rel_current = 0.0
                for idx, floor_h in enumerate(floor_heights, start=1):
                    floor_z = z_current
                    ceiling_z = z_current + floor_h
                    rel_floor = rel_current
                    rel_ceiling = rel_current + floor_h

                    geom = multipolygon_geometry(mp, options.swap_axis, floor_z if options.polygon_z else None)
                    if geom is None or geom.isEmpty():
                        stats.skipped_no_geom += 1
                        break

                    attr_values = {
                        'gml_id': b.gml_id,
                        'building_id': b.building_id,
                        'obj_type': b.object_type,
                        'floor_no': idx,
                        'floor_label': floor_label_for(idx),
                        'is_underground': 0,
                        'floors_used': floors_used,
                        'storeys_raw': b.storeys_above_ground if b.storeys_above_ground is not None else None,
                        'storeys_b': b.storeys_below_ground if b.storeys_below_ground is not None else None,
                        'meas_h': b.measured_height if b.measured_height is not None else None,
                        'lod1_h': lod1_height(b),
                        'total_h': sum(floor_heights),
                        'floor_h': floor_h,
                        'floor_z': floor_z,
                        'ceiling_z': ceiling_z,
                        'rel_floor': rel_floor,
                        'rel_ceiling': rel_ceiling,
                        'ground_z': ground_z,
                        'z_base': floor_z,
                        'z_top': ceiling_z,
                        'h_method': height_method,
                        'height_src': total_height_method,
                        'ground_src': ground_method,
                        'geom_src': footprint_method(b, options.footprint_source),
                        'geom_z': 'PolygonZ_floor_z' if options.polygon_z else '2D_attributes_only',
                        'src_file': b.source_file,
                    }

                    feat = QgsFeature(out_fields)
                    feat.setGeometry(geom)
                    feat.setAttributes([attr_values[fld.name()] for fld in out_fields])
                    batch.append(feat)
                    stats.output_features += 1
                    if len(batch) >= batch_size:
                        provider.addFeatures(batch)
                        batch = []

                    if options.html_viewer:
                        _append_viewer_feature(
                            viewer_features,
                            viewer_bounds,
                            b,
                            mp,
                            options.swap_axis,
                            idx,
                            floors_used,
                            floor_h,
                            floor_z,
                            ceiling_z,
                            ground_z,
                            b.source_file,
                            _select_attrs_map(attr_values, html_attrs),
                        )

                    z_current = ceiling_z
                    rel_current = rel_ceiling

            except Exception as e:
                stats.skipped_error += 1
                feedback.reportError(f'{b.gml_id or "(no gml:id)"}: {e}')
                continue

    if batch:
        provider.addFeatures(batch)
    layer.updateExtents()

    if options.html_viewer and viewer_features:
        html_path = resolve_html_path(options.html_output_path, '', layer_name)
        try:
            html_path, data_path, cesium_path = write_html_viewer(
                html_path,
                viewer_features,
                viewer_bounds,
                layer_name,
                default_color_attribute=options.html_color_attribute or 'floor_no',
                default_color_scheme=options.html_color_scheme or 'floorRainbow',
                selected_attributes=html_attrs,
            )
            stats.html_path = html_path
            stats.html_data_path = data_path
            stats.cesium_html_path = cesium_path
            feedback.pushInfo(f'HTMLビューワー: {html_path}')
            feedback.pushInfo(f'HTMLデータ: {data_path}')
            feedback.pushInfo(f'Cesium版ビューワー（試作）: {cesium_path}')
        except Exception as e:
            feedback.reportError(f'HTMLビューワーの作成に失敗しました: {e}')

    feedback.pushInfo('処理完了')
    feedback.pushInfo(f'建物数: {stats.buildings}')
    feedback.pushInfo(f'出力フィーチャ数: {stats.output_features}')
    feedback.pushInfo(f'スキップ（ジオメトリなし）: {stats.skipped_no_geom}')
    feedback.pushInfo(f'スキップ（階数・高さが無効）: {stats.skipped_invalid}')
    feedback.pushInfo(f'スキップ（エラー）: {stats.skipped_error}')
    return stats, layer


def generate_html_viewer_from_layer(layer, html_path: str, feedback=None,
                                    color_attribute: str = 'floor_no',
                                    color_scheme: str = 'rainbow',
                                    attribute_names: Optional[List[str]] = None,
                                    title: Optional[str] = None) -> Tuple[str, str, str]:
    feedback = feedback or NullFeedback()
    if layer is None:
        raise ValueError('入力レイヤが指定されていません。')
    features, bounds, selected_attrs = viewer_features_from_layer(layer, attribute_names)
    if not features:
        raise ValueError('入力レイヤからHTML表示用のフィーチャを作成できませんでした。')
    html_path = resolve_html_path(html_path, '', layer.name() or 'floor_polygons')
    return write_html_viewer(
        html_path,
        features,
        bounds,
        title or layer.name() or 'floor_polygons',
        default_color_attribute=color_attribute or 'floor_no',
        default_color_scheme=color_scheme or 'rainbow',
        selected_attributes=selected_attrs,
    )


def viewer_features_from_layer(layer, attribute_names: Optional[List[str]] = None):
    selected_attrs = _normalize_attribute_names(attribute_names)
    field_names = [f.name() for f in layer.fields()]
    if not selected_attrs:
        selected_attrs = [n for n in DEFAULT_HTML_ATTRIBUTES if n in field_names]
        if not selected_attrs:
            selected_attrs = field_names[:]
    bounds = {'minx': None, 'maxx': None, 'miny': None, 'maxy': None, 'minz': None, 'maxz': None}
    out = []
    for feat in layer.getFeatures():
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            continue
        polygons = _geom_to_polygons_xy(geom)
        if not polygons:
            continue
        z_base = _safe_float(feat['z_base']) if 'z_base' in field_names else _safe_float(feat['floor_z'])
        z_top = _safe_float(feat['z_top']) if 'z_top' in field_names else _safe_float(feat['ceiling_z'])
        if z_base is None:
            z_base = 0.0
        if z_top is None:
            z_top = z_base + (_safe_float(feat['floor_h']) or 0.0)
        attrs_map = {name: _normalize_attr_value(feat[name]) for name in selected_attrs if name in field_names}
        for poly in polygons:
            for ring in poly:
                for x, y in ring:
                    _update_bounds(bounds, float(x), float(y), float(z_base))
                    _update_bounds(bounds, float(x), float(y), float(z_top))
        out.append({
            'gml_id': _normalize_attr_value(feat['gml_id']) if 'gml_id' in field_names else '',
            'building_id': _normalize_attr_value(feat['building_id']) if 'building_id' in field_names else '',
            'floor_no': int(_safe_float(feat['floor_no']) or 0),
            'floor_label': _normalize_attr_value(feat['floor_label']) if 'floor_label' in field_names else floor_label_for(int(_safe_float(feat['floor_no']) or 0)),
            'is_underground': int(_safe_float(feat['is_underground']) or (1 if int(_safe_float(feat['floor_no']) or 0) < 0 else 0)),
            'floors_used': int(_safe_float(feat['floors_used']) or 0),
            'floor_h': round(float((_safe_float(feat['floor_h']) or (z_top - z_base))), 4),
            'floor_z': round(float(z_base), 4),
            'ceiling_z': round(float(z_top), 4),
            'z_base': round(float(z_base), 4),
            'z_top': round(float(z_top), 4),
            'ground_z': round(float((_safe_float(feat['ground_z']) if 'ground_z' in field_names else z_base) or z_base), 4),
            'src_file': _normalize_attr_value(feat['src_file']) if 'src_file' in field_names else '',
            'attrs': attrs_map,
            'polygons': polygons,
        })
    return out, bounds, selected_attrs


def _geom_to_polygons_xy(geom: QgsGeometry):
    polygons = []
    if geom.isMultipart():
        mp = geom.asMultiPolygon()
    else:
        p = geom.asPolygon()
        mp = [p] if p else []
    for poly in mp:
        rings = []
        for ring in poly:
            pts = []
            for pt in ring:
                try:
                    x = pt.x()
                    y = pt.y()
                except Exception:
                    x = pt[0]
                    y = pt[1]
                pts.append([round(float(x), 9), round(float(y), 9)])
            if len(pts) >= 4:
                rings.append(pts)
        if rings:
            polygons.append(rings)
    return polygons


def _safe_float(v):
    try:
        if v is None or v == '':
            return None
        return float(v)
    except Exception:
        return None


def _normalize_attr_value(v):
    if v is None:
        return None
    if isinstance(v, (int, float, bool, str)):
        return v
    return str(v)


def _normalize_output_path(output_path: str) -> str:
    p = os.path.normpath(output_path.strip())
    root, ext = os.path.splitext(p)
    if not ext:
        p += '.gpkg'
    return p


def _driver_for_path(path: str) -> str:
    lower = path.lower()
    if lower.endswith('.shp'):
        return 'ESRI Shapefile'
    if lower.endswith(('.geojson', '.json')):
        return 'GeoJSON'
    return 'GPKG'


def _html_path_for_output(output_path: str, layer_name: str = 'floor_polygons') -> str:
    if output_path:
        root, _ext = os.path.splitext(output_path)
        return root + '_viewer.html'
    return os.path.join(default_downloads_dir(), f'{layer_name}_viewer.html')


def default_downloads_dir() -> str:
    try:
        path = QStandardPaths.writableLocation(QStandardPaths.DownloadLocation)
        if path and os.path.isdir(path):
            return os.path.normpath(path)
    except Exception:
        pass
    home = os.path.expanduser('~') or ''
    downloads = os.path.join(home, 'Downloads') if home else ''
    if downloads and os.path.isdir(downloads):
        return os.path.normpath(downloads)
    if home and os.path.isdir(home):
        return os.path.normpath(home)
    return os.getcwd()


def resolve_html_path(requested_html_path: str, output_path: str, layer_name: str) -> str:
    if requested_html_path:
        html_path = os.path.normpath(requested_html_path)
        if not html_path.lower().endswith(('.html', '.htm')):
            html_path += '.html'
        return html_path
    safe_name = ''.join(ch if ch not in '\\/:*?"<>|' else '_' for ch in (layer_name or 'floor_polygons'))
    base_dir = ''
    if output_path:
        try:
            base_dir = os.path.dirname(os.path.normpath(output_path))
        except Exception:
            base_dir = ''
    if not base_dir or not os.path.isdir(base_dir):
        base_dir = default_downloads_dir()
    return os.path.join(base_dir, f'{safe_name}_viewer.html')


def html_data_path_for(html_path: str) -> str:
    root, _ = os.path.splitext(html_path)
    return root + '_data.js'


def cesium_html_path_for(html_path: str) -> str:
    root, _ = os.path.splitext(html_path)
    return root + '_cesium.html'


def _normalize_attribute_names(names: Optional[List[str]]) -> List[str]:
    out = []
    for name in names or []:
        text = str(name).strip()
        if text and text not in out:
            out.append(text)
    return out


def _select_attrs_map(all_attrs: Dict, selected: List[str]) -> Dict:
    if not selected:
        selected = [n for n in DEFAULT_HTML_ATTRIBUTES if n in all_attrs]
    return {name: _normalize_attr_value(all_attrs.get(name)) for name in selected if name in all_attrs}


def _append_viewer_feature(viewer_features: List[Dict], bounds: Dict, b: PlateauBuilding, mp, swap_axis: bool,
                           floor_no: int, floors_used: int, floor_h: float, floor_z: float, ceiling_z: float,
                           ground_z: float, source_file: str, attrs_map: Dict):
    polygons = []
    for poly in mp:
        rings = []
        for ring in poly:
            pts = []
            for a, c, _z in ring:
                x, y = (c, a) if swap_axis else (a, c)
                pts.append([round(float(x), 9), round(float(y), 9)])
                _update_bounds(bounds, float(x), float(y), floor_z)
                _update_bounds(bounds, float(x), float(y), ceiling_z)
            if len(pts) >= 4:
                rings.append(pts)
        if rings:
            polygons.append(rings)
    if not polygons:
        return
    viewer_features.append({
        'gml_id': b.gml_id,
        'building_id': b.building_id,
        'floor_no': floor_no,
        'floor_label': floor_label_for(floor_no),
        'is_underground': 1 if floor_no < 0 else 0,
        'floors_used': floors_used,
        'floor_h': round(float(floor_h), 4),
        'floor_z': round(float(floor_z), 4),
        'ceiling_z': round(float(ceiling_z), 4),
        'z_base': round(float(floor_z), 4),
        'z_top': round(float(ceiling_z), 4),
        'ground_z': round(float(ground_z), 4),
        'src_file': source_file,
        'attrs': attrs_map,
        'polygons': polygons,
    })


def _update_bounds(bounds: Dict, x: float, y: float, z: float):
    for key, val in (('minx', x), ('maxx', x), ('miny', y), ('maxy', y), ('minz', z), ('maxz', z)):
        if bounds[key] is None:
            bounds[key] = val
    bounds['minx'] = min(bounds['minx'], x)
    bounds['maxx'] = max(bounds['maxx'], x)
    bounds['miny'] = min(bounds['miny'], y)
    bounds['maxy'] = max(bounds['maxy'], y)
    bounds['minz'] = min(bounds['minz'], z)
    bounds['maxz'] = max(bounds['maxz'], z)



def write_html_viewer(html_path: str, viewer_features: List[Dict], bounds: Dict, title: str,
                      default_color_attribute: str = 'floor_no', default_color_scheme: str = 'rainbow',
                      selected_attributes: Optional[List[str]] = None):
    minx = bounds.get('minx') or 0.0
    maxx = bounds.get('maxx') or minx
    miny = bounds.get('miny') or 0.0
    maxy = bounds.get('maxy') or miny
    minz = bounds.get('minz') or 0.0
    maxz = bounds.get('maxz') or minz
    center_x = (minx + maxx) / 2.0
    center_y = (miny + maxy) / 2.0

    available_attrs = []
    for f in viewer_features:
        for k in (f.get('attrs') or {}).keys():
            if k not in available_attrs:
                available_attrs.append(k)
    for required in ['floor_no', 'floor_label', 'is_underground', 'ground_z', 'z_base', 'z_top']:
        if required not in available_attrs:
            available_attrs.insert(0, required)

    data = {
        'title': title,
        'center': [center_x, center_y],
        'z0': minz,
        'bounds': bounds,
        'features': viewer_features,
        'availableAttributes': available_attrs,
        'selectedAttributes': selected_attributes or available_attrs,
        'defaultColorAttribute': default_color_attribute or 'floor_no',
        'defaultColorScheme': default_color_scheme or 'rainbow',
    }
    data_json = json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    data_path = html_data_path_for(html_path)
    data_js_name = os.path.basename(data_path)
    html = _viewer_html(data_json, len(viewer_features), minz, maxz, data_js_name)
    cesium_html = _cesium_viewer_html(data_json, len(viewer_features), minz, maxz, data_js_name)
    data_js = 'window.CGML2FP_VIEWER_DATA = ' + data_json + ';\n'
    cesium_path = cesium_html_path_for(html_path)

    if os.path.dirname(html_path):
        os.makedirs(os.path.dirname(html_path), exist_ok=True)
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html)
    with open(data_path, 'w', encoding='utf-8') as f:
        f.write(data_js)
    with open(cesium_path, 'w', encoding='utf-8') as f:
        f.write(cesium_html)
    _write_cesium_launcher_files(cesium_path)
    return html_path, data_path, cesium_path




def _write_cesium_launcher_files(cesium_path: str):
    # Cesium Viewer launcher files for localhost startup.
    folder = os.path.dirname(cesium_path) or os.getcwd()
    html_name = os.path.basename(cesium_path)
    os.makedirs(folder, exist_ok=True)

    py_server = r'''#!/usr/bin/env python3
# CityGML2FloorPolygons Cesium Viewer local server
# ASCII-only console messages to avoid Windows code page issues.
import http.server
import os
import socketserver
import sys
import threading
import time
import webbrowser
from urllib.parse import unquote, urlparse

START_PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
HTML = sys.argv[2] if len(sys.argv) > 2 else "__HTML__"
ROOT = os.path.abspath(os.path.dirname(__file__))
LOG = os.path.join(ROOT, "cesium_server_log_python.txt")

def log(msg):
    line = time.strftime("%Y-%m-%d %H:%M:%S") + " " + str(msg)
    print(line, flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\\n")
    except Exception:
        pass

class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        log(fmt % args)

    def translate_path(self, path):
        path = urlparse(path).path
        path = unquote(path)
        if path in ("", "/"):
            path = "/" + HTML
        safe = os.path.normpath(path.lstrip("/"))
        full = os.path.abspath(os.path.join(ROOT, safe))
        if not full.startswith(ROOT):
            return ROOT
        return full

    def _shutdown(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write("server shutting down".encode("utf-8"))
        log("Shutdown requested from viewer.")
        threading.Thread(target=self.server.shutdown, daemon=True).start()

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_POST(self):
        if urlparse(self.path).path == "/__shutdown":
            self._shutdown()
        else:
            self.send_error(404)

    def do_GET(self):
        if urlparse(self.path).path == "/__shutdown":
            self._shutdown()
        else:
            super().do_GET()

class ReusableTCPServer(socketserver.TCPServer):
    allow_reuse_address = True

def open_server():
    last_error = None
    for port in range(START_PORT, START_PORT + 21):
        try:
            httpd = ReusableTCPServer(("localhost", port), Handler)
            return port, httpd
        except OSError as e:
            last_error = e
            log("Port %s unavailable: %s" % (port, e))
    raise RuntimeError("No available port from %s to %s. Last error: %s" % (START_PORT, START_PORT + 20, last_error))

def main():
    os.chdir(ROOT)
    log("Root: " + ROOT)
    log("HTML: " + HTML)
    port, httpd = open_server()
    url = "http://localhost:%s/%s" % (port, HTML)
    log("Cesium Viewer server started.")
    log("Open: " + url)
    log("Stop: Viewer Exit button, or Ctrl+C in this window.")
    try:
        webbrowser.open(url)
    except Exception as e:
        log("Browser open failed: " + str(e))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        log("KeyboardInterrupt")
    finally:
        try:
            httpd.server_close()
        except Exception:
            pass
        log("Server stopped.")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log("FATAL: " + repr(e))
        input("Press Enter to close...")
        raise
'''
    py_server = py_server.replace('__HTML__', html_name)

    ps_server = r'''param(
  [int]$Port = 8000,
  [string]$HtmlFile = "__HTML__"
)

# CityGML2FloorPolygons Cesium Viewer local server
# ASCII-only console messages to avoid Windows code page issues.

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogFile = Join-Path $Root "cesium_server_log_powershell.txt"

function Write-Log([string]$Message) {
  $line = (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + " " + $Message
  Write-Host $line
  try { Add-Content -Path $LogFile -Value $line -Encoding UTF8 } catch {}
}

function Send-Bytes($stream, [int]$Code, [byte[]]$Body, [string]$ContentType) {
  $reason = if ($Code -eq 200) { "OK" } elseif ($Code -eq 204) { "No Content" } elseif ($Code -eq 403) { "Forbidden" } elseif ($Code -eq 404) { "Not Found" } else { "Error" }
  $header = "HTTP/1.1 $Code $reason`r`nContent-Type: $ContentType`r`nContent-Length: $($Body.Length)`r`nAccess-Control-Allow-Origin: *`r`nConnection: close`r`n`r`n"
  $hbytes = [System.Text.Encoding]::ASCII.GetBytes($header)
  $stream.Write($hbytes, 0, $hbytes.Length)
  if ($Body.Length -gt 0) { $stream.Write($Body, 0, $Body.Length) }
}

function Send-Text($stream, [int]$Code, [string]$Text, [string]$ContentType = "text/plain; charset=utf-8") {
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
  Send-Bytes $stream $Code $bytes $ContentType
}

function Get-Mime([string]$path) {
  switch ([System.IO.Path]::GetExtension($path).ToLowerInvariant()) {
    ".html" { return "text/html; charset=utf-8" }
    ".htm"  { return "text/html; charset=utf-8" }
    ".js"   { return "text/javascript; charset=utf-8" }
    ".json" { return "application/json; charset=utf-8" }
    ".css"  { return "text/css; charset=utf-8" }
    ".png"  { return "image/png" }
    ".jpg"  { return "image/jpeg" }
    ".jpeg" { return "image/jpeg" }
    ".svg"  { return "image/svg+xml" }
    ".txt"  { return "text/plain; charset=utf-8" }
    default { return "application/octet-stream" }
  }
}

function New-Listener([int]$StartPort) {
  $last = $null
  for ($p = $StartPort; $p -le ($StartPort + 20); $p++) {
    try {
      $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $p)
      $l.Start()
      return @($p, $l)
    } catch {
      $last = $_.Exception.Message
      Write-Log "Port $p unavailable: $last"
    }
  }
  throw "No available port from $StartPort to $($StartPort + 20). Last error: $last"
}

try {
  Set-Location $Root
  Write-Log "Root: $Root"
  Write-Log "HTML: $HtmlFile"

  $pair = New-Listener $Port
  $actualPort = [int]$pair[0]
  $listener = $pair[1]
  $url = "http://localhost:$actualPort/$HtmlFile"

  Write-Log "Cesium Viewer server started."
  Write-Log "Open: $url"
  Write-Log "Stop: Viewer Exit button, or Ctrl+C in this window."
  Start-Process $url

  $stop = $false
  while (-not $stop) {
    $client = $listener.AcceptTcpClient()
    try {
      $stream = $client.GetStream()
      $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII, $false, 8192, $true)
      $requestLine = $reader.ReadLine()
      if ([string]::IsNullOrWhiteSpace($requestLine)) {
        Send-Text $stream 400 "Bad Request"
        continue
      }

      while ($true) {
        $line = $reader.ReadLine()
        if ($null -eq $line -or $line -eq "") { break }
      }

      $parts = $requestLine.Split(" ")
      $method = $parts[0]
      $rawPath = if ($parts.Length -gt 1) { $parts[1] } else { "/" }
      $pathOnly = $rawPath.Split("?")[0]
      $reqPath = [Uri]::UnescapeDataString($pathOnly)

      Write-Log "$method $reqPath"

      if ($method -eq "OPTIONS") {
        Send-Bytes $stream 204 ([byte[]]@()) "text/plain"
        continue
      }

      if ($reqPath -eq "/__shutdown") {
        Send-Text $stream 200 "server shutting down"
        Write-Log "Shutdown requested from viewer."
        $stop = $true
        continue
      }

      if ([string]::IsNullOrWhiteSpace($reqPath) -or $reqPath -eq "/") {
        $reqPath = "/" + $HtmlFile
      }

      $relative = $reqPath.TrimStart("/")
      $local = Join-Path $Root $relative
      $full = [System.IO.Path]::GetFullPath($local)
      $rootFull = [System.IO.Path]::GetFullPath($Root)

      if (-not $full.StartsWith($rootFull)) {
        Send-Text $stream 403 "Forbidden"
        continue
      }

      if (-not [System.IO.File]::Exists($full)) {
        Send-Text $stream 404 "Not Found"
        continue
      }

      $bytes = [System.IO.File]::ReadAllBytes($full)
      Send-Bytes $stream 200 $bytes (Get-Mime $full)
    } catch {
      try { Send-Text $stream 500 ("Server error: " + $_.Exception.Message) } catch {}
      Write-Log ("ERROR: " + $_.Exception.Message)
    } finally {
      try { $client.Close() } catch {}
    }
  }
} catch {
  Write-Log ("FATAL: " + $_.Exception.Message)
  Write-Host ""
  Write-Host "Press any key to close..."
  $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
  exit 1
} finally {
  try { if ($listener) { $listener.Stop() } } catch {}
  Write-Log "Server stopped."
}
'''
    ps_server = ps_server.replace('__HTML__', html_name)

    bat_py = r'''@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo CityGML2FloorPolygons Cesium Viewer - Python server
echo Folder: %CD%
echo Log: cesium_server_log_python.txt
echo.
echo Trying: py -3
py -3 server_cesium_viewer.py 8000 "__HTML__"
set ERR=%ERRORLEVEL%
if not "%ERR%"=="0" (
  echo.
  echo py -3 failed. Exit code: %ERR%
  echo Trying: python
  python server_cesium_viewer.py 8000 "__HTML__"
  set ERR=%ERRORLEVEL%
)
echo.
echo Server process ended. Exit code: %ERR%
echo If it did not start, please send cesium_server_log_python.txt.
pause
'''.replace('__HTML__', html_name)

    bat_ps = r'''@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo CityGML2FloorPolygons Cesium Viewer - PowerShell server
echo Folder: %CD%
echo Log: cesium_server_log_powershell.txt
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server_cesium_viewer.ps1" -Port 8000 -HtmlFile "__HTML__"
set ERR=%ERRORLEVEL%
echo.
echo Server process ended. Exit code: %ERR%
echo If it did not start, please send cesium_server_log_powershell.txt.
pause
'''.replace('__HTML__', html_name)

    bat_main = r'''@echo off
chcp 65001 >nul
cd /d "%~dp0"
call "%~dp0start_cesium_viewer_powershell.bat"
'''

    readme = '''Cesium Viewer startup

Recommended:
1. Double-click start_cesium_viewer_powershell.bat
2. Browser opens automatically.
3. Use the Exit button in the Viewer to stop the local server.

Alternative if Python is installed:
- Double-click start_cesium_viewer_python.bat

If nothing starts:
- Open cesium_server_log_powershell.txt
- Or run start_cesium_viewer_powershell.bat from Command Prompt to keep the message visible.
- The server automatically tries ports 8000 to 8020.

Notes:
- Cesium Viewer is more stable from http://localhost than file:///.
- Cesium terrain requires a Cesium ion token and internet access.
- Chrome may not allow the Viewer to close the tab automatically. If so, close the tab manually after the server stops.
'''

    files = {
        'server_cesium_viewer.py': py_server,
        'server_cesium_viewer.ps1': ps_server,
        'start_cesium_viewer_python.bat': bat_py,
        'start_cesium_viewer_powershell.bat': bat_ps,
        'start_cesium_viewer.bat': bat_main,
        'README_CesiumViewer_Start.txt': readme,
    }
    for name, content in files.items():
        with open(os.path.join(folder, name), 'w', encoding='utf-8', newline='') as f:
            f.write(content)

def _cesium_viewer_html(data_json: str, feature_count: int, minz: float, maxz: float, data_js_name: str) -> str:
    """CesiumJSを使う試作ビューワー。地理院淡色地図＋Cesium地形を使います。"""
    html = """<!doctype html>
<html lang=\"ja\">
<head>
<meta charset=\"utf-8\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<title>CityGML2FloorPolygons Cesium Viewer</title>
<script>
window.addEventListener('error', function(e){
  const el=document.getElementById('status');
  if(el){
    const msg=(e && e.message) ? e.message : String(e);
    el.textContent='JavaScriptエラーで初期化が止まりました。\\n' + msg + '\\n\\nCesiumJS、data.js、ネット接続、ブラウザの開発者ツールConsoleを確認してください。';
  }
});
</script>
<script src=\"https://cesium.com/downloads/cesiumjs/releases/1.127/Build/Cesium/Cesium.js\"></script>
<link href=\"https://cesium.com/downloads/cesiumjs/releases/1.127/Build/Cesium/Widgets/widgets.css\" rel=\"stylesheet\">
<style>
html,body,#cesiumContainer{width:100%;height:100%;margin:0;padding:0;overflow:hidden;font-family:system-ui,-apple-system,\"Segoe UI\",sans-serif;}
#cesiumContainer{background:#f4f5f6;}
#panel{position:absolute;left:12px;top:12px;width:410px;max-height:calc(100% - 24px);overflow:auto;background:rgba(255,255,255,.94);border:1px solid #bbb;border-radius:10px;box-shadow:0 4px 20px rgba(0,0,0,.22);padding:12px;font-size:13px;box-sizing:border-box;z-index:10;}
#panel h1{font-size:16px;margin:0 0 8px;}
.hint{font-size:12px;color:#555;line-height:1.55;}
.row{display:flex;gap:8px;align-items:center;margin:7px 0;flex-wrap:wrap;}
button{padding:5px 8px;border:1px solid #aaa;border-radius:6px;background:#fff;cursor:pointer;}
button:hover{background:#f1f4ff;}
button.primary{background:#eef3ff;border-color:#7895d6;}
button.danger{background:#fff4f4;border-color:#d29a9a;}
input[type=text], input[type=password]{flex:1;min-width:120px;padding:5px;border:1px solid #aaa;border-radius:5px;}
select{padding:5px;border:1px solid #aaa;border-radius:5px;background:#fff;max-width:100%;}
input[type=range]{vertical-align:middle;}
#status{font-size:12px;color:#555;white-space:pre-wrap;background:#f7f7f7;border:1px solid #ddd;border-radius:6px;padding:8px;margin-top:8px;}
#info{white-space:pre-wrap;max-height:220px;overflow:auto;background:#fbfbfb;border:1px solid #ddd;border-radius:6px;padding:8px;margin-top:8px;font-family:ui-monospace,Consolas,monospace;font-size:12px;}
#legend{display:flex;align-items:center;gap:6px;}
#legendBar{height:12px;flex:1;border:1px solid #bbb;border-radius:6px;background:linear-gradient(90deg,hsl(210,60%,74%),hsl(204,68%,48%),hsl(120,62%,58%),hsl(60,62%,58%),hsl(0,65%,56%),hsl(285,65%,54%));}
.credit{font-size:11px;color:#555;line-height:1.45;margin-top:8px;}
.credit a{color:#335fbd;}
.warn{color:#9a5a00;}
#tokenOverlay{display:none;position:absolute;inset:0;background:rgba(0,0,0,.28);z-index:30;}
#tokenDialog{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(560px,calc(100% - 40px));background:#fff;border-radius:12px;box-shadow:0 10px 40px rgba(0,0,0,.3);border:1px solid #aaa;padding:16px;box-sizing:border-box;}
#tokenDialog h2{font-size:16px;margin:0 0 10px;}
#tokenDialog p{font-size:12px;line-height:1.55;color:#555;margin:8px 0;}
#tokenDialog input{width:100%;box-sizing:border-box;margin:6px 0;}
.small{font-size:11px;color:#666;}
</style>
</head>
<body>
<div id=\"cesiumContainer\"></div>
<div id=\"tokenOverlay\">
  <div id=\"tokenDialog\">
    <h2>Cesium ion token 設定</h2>
    <p>地形の起伏を表示するには Cesium ion token が必要です。tokenはこのブラウザの localStorage に保存します。HTMLファイル自体には書き込みません。</p>
    <input id=\"tokenModalInput\" type=\"password\" placeholder=\"Cesium ion access token を貼り付け\">
    <div class=\"row\">
      <button id=\"saveToken\" class=\"primary\">保存</button>
      <button id=\"deleteToken\">削除</button>
      <button id=\"openTokenPage\">token取得ページを開く</button>
      <button id=\"closeTokenDialog\">閉じる</button>
    </div>
    <p class=\"small\">取得後、この画面に貼り付けて保存し、左パネルの「地形ON/OFF」を押してください。</p>
  </div>
</div>
<div id=\"panel\">
  <h1>Cesium版 Viewer（試作）</h1>
  <div class=\"hint\">地理院タイルを背景に、Cesium上で階別ポリゴンを表示します。地形を有効にするには Cesium ion token が必要です。安定表示のため、同時出力される start_cesium_viewer_powershell.bat から開くことを推奨します。</div>
  <div class=\"row\"><button id=\"zoomToData\">範囲へ移動</button><button id=\"zoomToEntities\">建物へ移動</button><button id=\"reloadMap\">地図再読込</button><button id=\"shutdown\" class=\"danger\">終了</button></div>
  <div class=\"row\"><button id=\"toggleUnderground\">地下ON/OFF</button><button id=\"toggleAbove\">地上ON/OFF</button><button id=\"toggleTerrain\" class=\"primary\">地形ON/OFF</button></div>
  <div class=\"row\"><label><input id=\"groundRelative\" type=\"checkbox\" checked> 地形に対する相対高さで表示</label></div>
  <div class=\"row\"><label><input id=\"sampleTerrain\" type=\"checkbox\" checked> 地形標高をサンプリングして建物を配置</label></div>
  <div class=\"row\">背景 <select id=\"mapMode\"><option value=\"pale\" selected>地理院 淡色</option><option value=\"std\">地理院 標準</option><option value=\"none\">地図なし（明るい地面）</option></select></div>
  <div class=\"row\">背景透過度 <input id=\"mapAlpha\" type=\"range\" min=\"0\" max=\"100\" value=\"100\"><span id=\"mapAlphaLabel\">100%</span></div>
  <div class=\"row\">空背景 <select id=\"skyMode\"><option value=\"bright\" selected>明るい背景</option><option value=\"standard\">Cesium標準の空・大気</option><option value=\"plain\">空なし（単色）</option></select></div>
  <div class=\"row\">建物透明度 <input id=\"buildingAlpha\" type=\"range\" min=\"5\" max=\"100\" value=\"78\"><span id=\"buildingAlphaLabel\">78%</span></div>
  <div class=\"row\">色分け属性 <select id=\"colorAttr\"></select></div>
  <div class=\"row\">色 <select id=\"colorScheme\">
    <option value=\"floorRainbow\" selected>レインボー（階別・前の色）</option>
    <option value=\"rainbow\">連続レインボー（紫→青→緑→黄→赤）</option>
    <option value=\"viridis\">紫→青緑→黄</option>
    <option value=\"terrain\">茶→白→緑</option>
    <option value=\"heat\">黄→橙→赤</option>
    <option value=\"pinkgreen\">ピンク→白→緑</option>
    <option value=\"redblue\">赤→黄→青</option>
  </select></div>
  <div class=\"row\"><input id=\"ionToken\" type=\"password\" placeholder=\"Cesium ion token（地形ON用・任意）\"><button id=\"tokenSettings\">token設定</button></div>
  <div id=\"legend\"><span id=\"legendMin\">B</span><div id=\"legendBar\"></div><span id=\"legendMax\">地上</span></div>
  <div id=\"status\">読み込み中...</div>
  <div id=\"info\">建物をクリックすると属性を表示します。</div>
  <div class=\"credit\">背景地図: <a href=\"https://maps.gsi.go.jp/development/ichiran.html\" target=\"_blank\">地理院タイル</a> / 3D表示: CesiumJS。地形はCesium ion token設定時のみ有効です。</div>
</div>
<script id=\"viewer-data\" type=\"application/json\">__DATA__</script>
<script src=\"__DATA_JS__\"></script>
<script>
(async function(){
'use strict';
const statusEl=document.getElementById('status');
const infoEl=document.getElementById('info');
function status(msg){ if(statusEl) statusEl.textContent=msg; }

function escapeHtml(s){ return String(s).replace(/[&<>]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }
function showFatal(msg){
  status(msg);
  const c=document.getElementById('cesiumContainer');
  if(c){ c.innerHTML='<div style=\"padding:24px;color:#555;font-family:sans-serif;white-space:pre-wrap;\">'+escapeHtml(msg)+'</div>'; }
}

try{
if(typeof Cesium==='undefined'){
  showFatal('CesiumJSを読み込めませんでした。\\nネット接続、セキュリティ設定、社内プロキシ、またはCDNへのアクセスを確認してください。');
  return;
}

let embedded={};
try{ embedded=JSON.parse(document.getElementById('viewer-data').textContent||'{}'); }
catch(e){ showFatal('HTML内蔵データを読めませんでした: '+e.message); return; }

const data=window.CGML2FP_VIEWER_DATA || embedded || {};
const features=Array.isArray(data.features)?data.features:[];
const bounds=data.bounds||{};
const minLon=Number(bounds.minx), maxLon=Number(bounds.maxx), minLat=Number(bounds.miny), maxLat=Number(bounds.maxy);
const centerLon=(minLon+maxLon)/2, centerLat=(minLat+maxLat)/2;
const looksLonLat=Number.isFinite(minLon)&&Number.isFinite(maxLon)&&Number.isFinite(minLat)&&Number.isFinite(maxLat)&&Math.abs(minLon)<=180&&Math.abs(maxLon)<=180&&Math.abs(minLat)<=90&&Math.abs(maxLat)<=90;

if(!features.length){
  showFatal('表示対象データがありません。\\nHTML内蔵データまたは同じフォルダの __DATA_JS__ を確認してください。');
  return;
}
if(!looksLonLat){
  showFatal('Cesium版は経度・緯度座標のHTMLデータで試作しています。\\n現在のデータは経度・緯度に見えないため、通常HTML Viewerを使用してください。');
  return;
}

let viewer;
try{
  viewer = new Cesium.Viewer('cesiumContainer', {
    animation:false,
    timeline:false,
    geocoder:false,
    homeButton:false,
    sceneModePicker:true,
    baseLayerPicker:false,
    navigationHelpButton:true,
    fullscreenButton:true,
    terrainProvider: new Cesium.EllipsoidTerrainProvider()
  });
}catch(e){
  showFatal('Cesium Viewerの初期化に失敗しました。\\n'+e.message+'\\n\\nネット接続、CesiumJSの読み込み、ブラウザのWebGL対応を確認してください。');
  return;
}

viewer.scene.globe.depthTestAgainstTerrain=false;
viewer.scene.globe.enableLighting=false;
function applySkyMode(){
  const mode=(document.getElementById('skyMode')&&document.getElementById('skyMode').value)||'bright';
  if(mode==='standard'){
    viewer.scene.backgroundColor=Cesium.Color.BLACK;
    if(viewer.scene.skyBox) viewer.scene.skyBox.show=true;
    if(viewer.scene.sun) viewer.scene.sun.show=true;
    if(viewer.scene.moon) viewer.scene.moon.show=true;
    if(viewer.scene.skyAtmosphere) viewer.scene.skyAtmosphere.show=true;
    if(viewer.scene.fog) viewer.scene.fog.enabled=true;
    if(viewer.scene.globe) viewer.scene.globe.showGroundAtmosphere=true;
  }else{
    const bg=(mode==='plain')?'#ffffff':'#eaf3ff';
    viewer.scene.backgroundColor=Cesium.Color.fromCssColorString(bg);
    if(viewer.scene.skyBox) viewer.scene.skyBox.show=false;
    if(viewer.scene.sun) viewer.scene.sun.show=false;
    if(viewer.scene.moon) viewer.scene.moon.show=false;
    if(viewer.scene.skyAtmosphere) viewer.scene.skyAtmosphere.show=false;
    if(viewer.scene.fog) viewer.scene.fog.enabled=false;
    if(viewer.scene.globe) viewer.scene.globe.showGroundAtmosphere=false;
  }
  viewer.scene.globe.baseColor=Cesium.Color.fromCssColorString('#f4f3ee');
}
applySkyMode();

let currentImageryLayer=null;
function updateMapAlpha(){
  const v=Number(document.getElementById('mapAlpha').value);
  const alpha=Math.max(0,Math.min(1,v/100));
  document.getElementById('mapAlphaLabel').textContent=Math.round(alpha*100)+'%';
  if(currentImageryLayer) currentImageryLayer.alpha=alpha;
}
function loadImagery(){
  const mode=document.getElementById('mapMode').value || 'pale';
  try{ viewer.imageryLayers.removeAll(); currentImageryLayer=null; }catch(_){}
  viewer.scene.globe.baseColor=Cesium.Color.fromCssColorString('#f4f3ee');
  if(mode==='none'){
    status('背景地図をOFFにしました。明るい地面色だけ表示します。');
    return;
  }
  const layer = mode==='std' ? 'std' : 'pale';
  const label = mode==='std' ? '地理院タイル 標準地図' : '地理院タイル 淡色地図';
  try{
    const provider=new Cesium.UrlTemplateImageryProvider({
      url:'https://cyberjapandata.gsi.go.jp/xyz/'+layer+'/{z}/{x}/{y}.png',
      minimumLevel:5,
      maximumLevel:18,
      credit:new Cesium.Credit(label)
    });
    if(provider.errorEvent){
      provider.errorEvent.addEventListener(function(err){
        status('背景地図タイルの読み込みでエラーが出ています。\\n'+label+'\\nネット接続、地理院タイルへのアクセス、ブラウザConsoleを確認してください。\\n\\n'+(err && err.message ? err.message : ''));
      });
    }
    currentImageryLayer=viewer.imageryLayers.addImageryProvider(provider);
    updateMapAlpha();
    status('背景地図を読み込みました: '+label);
  }catch(e){
    status('背景地図の設定に失敗しました。地図なしで続行します。\\n'+e.message);
  }
}
loadImagery();

const TOKEN_KEY='cgml2fp_cesium_ion_token';
const tokenInput=document.getElementById('ionToken');
const tokenModalInput=document.getElementById('tokenModalInput');
const tokenOverlay=document.getElementById('tokenOverlay');
function getStoredToken(){ return (localStorage.getItem(TOKEN_KEY)||'').trim(); }
function syncTokenInputs(){
  const v=getStoredToken();
  if(tokenInput) tokenInput.value=v;
  if(tokenModalInput) tokenModalInput.value=v;
}
function openTokenDialog(){ syncTokenInputs(); if(tokenOverlay) tokenOverlay.style.display='block'; if(tokenModalInput) tokenModalInput.focus(); }
function closeTokenDialog(){ if(tokenOverlay) tokenOverlay.style.display='none'; }
document.getElementById('tokenSettings').onclick=openTokenDialog;
document.getElementById('closeTokenDialog').onclick=closeTokenDialog;
document.getElementById('saveToken').onclick=function(){
  const v=(tokenModalInput&&tokenModalInput.value||'').trim();
  if(!v){ status('tokenが空です。保存しませんでした。'); return; }
  localStorage.setItem(TOKEN_KEY,v); syncTokenInputs(); closeTokenDialog(); status('Cesium ion tokenを保存しました。地形ON/OFFを押すと地形を読み込みます。');
};
document.getElementById('deleteToken').onclick=function(){
  localStorage.removeItem(TOKEN_KEY); syncTokenInputs(); status('保存済みtokenを削除しました。'); 
};
document.getElementById('openTokenPage').onclick=function(){
  window.open('https://ion.cesium.com/tokens','_blank','noopener');
};
if(tokenOverlay){ tokenOverlay.addEventListener('click', function(e){ if(e.target===tokenOverlay) closeTokenDialog(); }); }
syncTokenInputs();

const undergroundEntities=[];
const aboveEntities=[];
let undergroundVisible=true;
let aboveVisible=true;
let terrainOn=false;
const floorNums=features.map(f=>Number(f.floor_no)).filter(Number.isFinite);
const minFloor=Math.min(...floorNums,0);
const maxFloor=Math.max(...floorNums,1);
const maxBasement=Math.max(0,...floorNums.filter(n=>n<0).map(n=>Math.abs(n)));
const maxAbove=Math.max(0,...floorNums.filter(n=>n>0));
let colorScheme='floorRainbow';
let colorAttr='floor_no';

function ownAttr(f, attr){
  if(f && Object.prototype.hasOwnProperty.call(f, attr)) return f[attr];
  const a=(f&&f.attrs)||{};
  return a[attr];
}
function getAttrValue(f, attr){
  const v=ownAttr(f, attr);
  const n=Number(v);
  return Number.isFinite(n) && String(v).trim()!=='' ? n : v;
}
let availableAttrs=Array.isArray(data.availableAttributes)?data.availableAttributes.slice():[];
if(!availableAttrs.length && features.length){
  const s=new Set(['floor_no','floor_label','is_underground','z_base','z_top','ground_z']);
  for(const f of features.slice(0, Math.min(features.length, 50))){
    for(const k of Object.keys(f.attrs||{})) s.add(k);
    for(const k of ['floor_no','floor_label','is_underground','z_base','z_top','ground_z','gml_id','building_id']) if(k in f) s.add(k);
  }
  availableAttrs=Array.from(s);
}
for(const k of ['floor_no','floor_label','is_underground','z_base','z_top','ground_z']){
  if(!availableAttrs.includes(k)) availableAttrs.unshift(k);
}
const colorAttrSelect=document.getElementById('colorAttr');
if(colorAttrSelect){
  for(const name of availableAttrs){
    const opt=document.createElement('option');
    opt.value=name; opt.textContent=name;
    if(name==='floor_no') opt.selected=true;
    colorAttrSelect.appendChild(opt);
  }
}
function numericRange(attr){
  let min=Infinity, max=-Infinity, count=0;
  for(const f of features){
    const v=getAttrValue(f,attr);
    if(typeof v==='number' && Number.isFinite(v)){
      min=Math.min(min,v); max=Math.max(max,v); count++;
    }
  }
  return count?{min,max,count}:null;
}
function hashHue(text){
  let h=0; text=String(text||'');
  for(let i=0;i<text.length;i++) h=((h*31)+text.charCodeAt(i))%360;
  return h;
}
function buildingAlpha(){
  const el=document.getElementById('buildingAlpha');
  const v=el?Number(el.value):78;
  return Math.max(.05, Math.min(1, v/100));
}
function updateBuildingAlphaLabel(){
  const el=document.getElementById('buildingAlpha');
  const lab=document.getElementById('buildingAlphaLabel');
  if(el&&lab) lab.textContent=String(Math.round(Number(el.value)))+'%';
}

const PALETTES={
  viridis:['#440154','#31688e','#35b779','#fde725'],
  terrain:['#b57b2a','#d8c077','#f0eee3','#67b7a8','#00866b'],
  heat:['#ffffb2','#fed976','#fd8d3c','#f03b20','#bd0026'],
  pinkgreen:['#d01c8b','#f1b6da','#f7f7f7','#b8e186','#4dac26'],
  redblue:['#d7191c','#fdae61','#ffffbf','#abd9e9','#2c7bb6']
};
function hexToRgb(hex){ hex=String(hex).replace('#',''); return [parseInt(hex.slice(0,2),16),parseInt(hex.slice(2,4),16),parseInt(hex.slice(4,6),16)]; }
function interpRgb(t,pal){
  t=Math.max(0,Math.min(1,t));
  const arr=pal.map(hexToRgb);
  const pos=t*(arr.length-1);
  const i=Math.min(arr.length-2,Math.floor(pos));
  const u=pos-i;
  return [0,1,2].map(k=>Math.round(arr[i][k]+(arr[i+1][k]-arr[i][k])*u));
}
function rgbColor(rgb,alpha){ return Cesium.Color.fromBytes(rgb[0],rgb[1],rgb[2],Math.round(alpha*255)); }
function basementColor(depth, alpha){
  const d=Math.max(1,Math.abs(Number(depth)||1));
  const t=maxBasement>1?((d-1)/(maxBasement-1)):0;
  const hue=212-(8*t), sat=60+(t*8), light=74-(t*26);
  return Cesium.Color.fromCssColorString('hsl('+hue+','+sat+'%,'+light+'%)').withAlpha(alpha);
}
function aboveGreenPurpleColor(floorNo, alpha){
  const n=Math.max(1,Number(floorNo)||1);
  const t=maxAbove>1?((n-1)/(maxAbove-1)):0;
  const rawHue=120-(195*t);
  const hue=((rawHue%360)+360)%360;
  const sat=62+(t*3), light=58-(t*4);
  return Cesium.Color.fromCssColorString('hsl('+hue+','+sat+'%,'+light+'%)').withAlpha(alpha);
}
function floorT(floorNo){
  const n=Number(floorNo)||0;
  return (maxFloor-minFloor)>0 ? (n-minFloor)/(maxFloor-minFloor) : 0.5;
}
function colorByT(t, alpha){
  t=Math.max(0,Math.min(1,t));
  if(colorScheme==='rainbow'){
    const hue=270-(270*t);
    return Cesium.Color.fromCssColorString('hsl('+hue+',62%,58%)').withAlpha(alpha);
  }
  if(colorScheme==='floorRainbow'){
    const rawHue=120-(195*t);
    const hue=((rawHue%360)+360)%360;
    return Cesium.Color.fromCssColorString('hsl('+hue+',62%,58%)').withAlpha(alpha);
  }
  return rgbColor(interpRgb(t, PALETTES[colorScheme]||PALETTES.viridis), alpha);
}
function colorForFloor(floorNo, alpha){
  const n=Number(floorNo)||0;
  if(colorScheme==='floorRainbow'){
    if(n<0) return basementColor(n,alpha);
    return aboveGreenPurpleColor(n<=0?1:n,alpha);
  }
  const t=floorT(n);
  return colorByT(t, alpha);
}
function colorForFeature(f, alpha){
  const v=getAttrValue(f,colorAttr);
  if(colorAttr==='floor_no') return colorForFloor(v, alpha);
  const r=numericRange(colorAttr);
  if(r && typeof v==='number' && Number.isFinite(v)){
    const t=(r.max-r.min)>0 ? ((v-r.min)/(r.max-r.min)) : 0.5;
    return colorByT(t, alpha);
  }
  const hue=hashHue(v);
  return Cesium.Color.fromCssColorString('hsl('+hue+',55%,60%)').withAlpha(alpha);
}
function updateLegend(){
  const bar=document.getElementById('legendBar');
  if(!bar) return;
  if(colorAttr==='floor_no' && colorScheme==='floorRainbow'){
    bar.style.background='linear-gradient(90deg,hsl(212,60%,74%),hsl(204,68%,48%),hsl(120,62%,58%),hsl(60,62%,58%),hsl(0,65%,56%),hsl(285,65%,54%))';
    document.getElementById('legendMin').textContent='B';
    document.getElementById('legendMax').textContent='地上';
  }else if(numericRange(colorAttr)){
    const r=numericRange(colorAttr);
    if(colorScheme==='rainbow'){
      bar.style.background='linear-gradient(90deg,hsl(270,70%,55%),hsl(210,70%,55%),hsl(135,70%,50%),hsl(60,80%,55%),hsl(0,75%,55%))';
    }else if(colorScheme==='floorRainbow'){
      bar.style.background='linear-gradient(90deg,hsl(120,62%,58%),hsl(60,62%,58%),hsl(0,65%,56%),hsl(285,65%,54%))';
    }else{
      bar.style.background='linear-gradient(90deg,'+(PALETTES[colorScheme]||PALETTES.viridis).join(',')+')';
    }
    document.getElementById('legendMin').textContent=String(r.min);
    document.getElementById('legendMax').textContent=String(r.max);
  }else{
    bar.style.background='linear-gradient(90deg,hsl(20,55%,60%),hsl(120,55%,60%),hsl(220,55%,60%),hsl(310,55%,60%))';
    document.getElementById('legendMin').textContent='カテゴリ';
    document.getElementById('legendMax').textContent=colorAttr;
  }
}
updateLegend();
updateBuildingAlphaLabel();

function positionsFromRing(ring){
  const out=[];
  const pts=Array.isArray(ring)?ring:[];
  for(let i=0;i<pts.length;i++){
    const p=pts[i];
    if(!p || p.length<2) continue;
    const lon=Number(p[0]), lat=Number(p[1]);
    if(Number.isFinite(lon)&&Number.isFinite(lat)) out.push(Cesium.Cartesian3.fromDegrees(lon,lat,0));
  }
  if(out.length>2){
    const a=pts[0], b=pts[pts.length-1];
    if(a&&b&&Math.abs(Number(a[0])-Number(b[0]))<1e-10&&Math.abs(Number(a[1])-Number(b[1]))<1e-10) out.pop();
  }
  return out;
}
function hierarchyFromPoly(poly){
  if(!poly || !poly.length) return null;
  const outer=positionsFromRing(poly[0]);
  if(outer.length<3) return null;
  const holes=[];
  for(let i=1;i<poly.length;i++){
    const hp=positionsFromRing(poly[i]);
    if(hp.length>=3) holes.push(new Cesium.PolygonHierarchy(hp));
  }
  return new Cesium.PolygonHierarchy(outer, holes);
}
function featureCenter(f){
  for(const poly of (f.polygons||[])){
    if(!poly || !poly.length || !Array.isArray(poly[0])) continue;
    let sx=0, sy=0, c=0;
    for(const p of poly[0]){
      const lon=Number(p&&p[0]), lat=Number(p&&p[1]);
      if(Number.isFinite(lon)&&Number.isFinite(lat)){ sx+=lon; sy+=lat; c++; }
    }
    if(c>0) return {lon:sx/c, lat:sy/c};
  }
  return {lon:centerLon, lat:centerLat};
}
async function sampleTerrainHeights(){
  if(!terrainOn || !document.getElementById('sampleTerrain').checked) return null;
  const centers=features.map(featureCenter);
  const cartos=centers.map(p=>Cesium.Cartographic.fromDegrees(p.lon,p.lat));
  try{
    status('地形標高をサンプリング中...\\n建物数: '+features.length);
    const sampled=await Cesium.sampleTerrainMostDetailed(viewer.terrainProvider, cartos);
    return sampled.map(c=>Number.isFinite(c.height)?c.height:0);
  }catch(e){
    status('地形標高のサンプリングに失敗しました。相対高さ指定で続行します。\\n'+e.message);
    return null;
  }
}
function attrLines(f){
  const lines=[];
  const attrs=f.attrs||{};
  const selected=Array.isArray(data.selectedAttributes)?data.selectedAttributes:Object.keys(attrs);
  for(const k of selected){ if(k in attrs) lines.push(k+': '+attrs[k]); }
  if(!lines.length){
    lines.push('gml_id: '+(f.gml_id||''));
    lines.push('building_id: '+(f.building_id||''));
    lines.push('floor_no: '+(f.floor_no||''));
    lines.push('z_base: '+(f.z_base||''));
    lines.push('z_top: '+(f.z_top||''));
  }
  return lines.join('\\n');
}
async function rebuildEntities(useGroundRelative){
  const sampledHeights=await sampleTerrainHeights();
  viewer.entities.removeAll(); undergroundEntities.length=0; aboveEntities.length=0;
  let added=0, skipped=0;
  for(let idx=0; idx<features.length; idx++){
    const f=features[idx];
    const floorNo=Number(f.floor_no)||0;
    const isUnder=floorNo<0 || Number(f.is_underground)===1;
    const ground=Number.isFinite(Number(f.ground_z))?Number(f.ground_z):Number(f.z_base)||0;
    const zBase=Number(f.z_base), zTop=Number(f.z_top);
    const relBase=((Number.isFinite(zBase)?zBase:ground)-ground);
    const relTop=((Number.isFinite(zTop)?zTop:ground)-ground);
    let height, extrudedHeight, hRef, ehRef;
    if(useGroundRelative && sampledHeights){
      const terrainH=sampledHeights[idx]||0;
      height=terrainH + Math.min(relBase, relTop);
      extrudedHeight=terrainH + Math.max(relBase, relTop);
      hRef=Cesium.HeightReference.NONE;
      ehRef=Cesium.HeightReference.NONE;
    }else if(useGroundRelative){
      height=Math.min(relBase, relTop);
      extrudedHeight=Math.max(relBase, relTop);
      hRef=Cesium.HeightReference.RELATIVE_TO_GROUND;
      ehRef=Cesium.HeightReference.RELATIVE_TO_GROUND;
    }else{
      height=Math.min(Number.isFinite(zBase)?zBase:0, Number.isFinite(zTop)?zTop:3);
      extrudedHeight=Math.max(Number.isFinite(zBase)?zBase:0, Number.isFinite(zTop)?zTop:3);
      hRef=Cesium.HeightReference.NONE;
      ehRef=Cesium.HeightReference.NONE;
    }
    if(height===extrudedHeight) extrudedHeight=height+0.2;
    const color=colorForFeature(f, buildingAlpha());
    for(const poly of (f.polygons||[])){
      const hierarchy=hierarchyFromPoly(poly); if(!hierarchy){ skipped++; continue; }
      const ent=viewer.entities.add({
        name:(f.floor_label||('F'+floorNo))+' '+(f.building_id||f.gml_id||''),
        properties:{info:attrLines(f), isUnderground:isUnder},
        polygon:{
          hierarchy:hierarchy,
          height:height,
          extrudedHeight:extrudedHeight,
          heightReference:hRef,
          extrudedHeightReference:ehRef,
          material:color,
          outline:true,
          outlineColor:Cesium.Color.BLACK.withAlpha(.55),
          closeTop:true,
          closeBottom:true,
          perPositionHeight:false
        }
      });
      if(isUnder) undergroundEntities.push(ent); else aboveEntities.push(ent);
      added++;
    }
  }
  undergroundEntities.forEach(e=>e.show=undergroundVisible);
  aboveEntities.forEach(e=>e.show=aboveVisible);
  status('表示フィーチャ: '+added+(skipped?('\\nスキップ: '+skipped):'')+
    '\\n地図: '+(document.getElementById('mapMode').selectedOptions[0].textContent)+' / 透過度 '+document.getElementById('mapAlphaLabel').textContent+
    '\\n色分け属性: '+colorAttr+
    '\\n色: '+document.getElementById('colorScheme').selectedOptions[0].textContent+
    '\\n建物透明度: '+document.getElementById('buildingAlphaLabel').textContent+
    '\\n地形: '+(terrainOn?'ON':'OFF（平面楕円体）')+
    '\\n高さ: '+(useGroundRelative?(sampledHeights?'地形標高サンプリング配置':'相対高さ'):'絶対高さ')+
    '\\n※安定表示は start_cesium_viewer_powershell.bat からの起動を推奨します。');
}
function extentMeters(){
  const latM=Math.abs(maxLat-minLat)*110574;
  const lonM=Math.abs(maxLon-minLon)*111320*Math.max(.2,Math.cos(centerLat*Math.PI/180));
  const zM=Math.max(10, Math.abs(Number('__MAXZ__')-Number('__MINZ__')));
  return Math.max(300, latM, lonM, zM*4);
}
function zoomToData(){
  const h=Math.max(500, extentMeters()*2.4);
  try{
    viewer.camera.flyTo({
      destination:Cesium.Cartesian3.fromDegrees(centerLon,centerLat,h),
      orientation:{heading:Cesium.Math.toRadians(0), pitch:Cesium.Math.toRadians(-55), roll:0},
      duration:.8
    });
  }catch(e){ viewer.zoomTo(viewer.entities); }
}
function zoomToEntities(){
  try{
    viewer.flyTo(viewer.entities, {duration:.8});
  }catch(e){ zoomToData(); }
}
function updateTerrainButton(){
  document.getElementById('toggleTerrain').textContent=terrainOn?'地形OFF':'地形ON';
}
async function enableTerrain(){
  const token=((tokenInput&&tokenInput.value)||getStoredToken()).trim();
  if(token){
    Cesium.Ion.defaultAccessToken=token;
    localStorage.setItem(TOKEN_KEY,token);
    syncTokenInputs();
  } else {
    status('Cesium ion token が未入力です。\\ntoken設定ボタンから保存するか、入力欄に貼り付けてください。地形なしの平面表示を続けます。');
    openTokenDialog();
    return;
  }
  try{
    status('地形を読み込み中...');
    if(Cesium.createWorldTerrainAsync){ viewer.terrainProvider=await Cesium.createWorldTerrainAsync(); }
    else if(Cesium.createWorldTerrain){ viewer.terrainProvider=Cesium.createWorldTerrain(); }
    else if(Cesium.Terrain && Cesium.Terrain.fromWorldTerrain && viewer.scene && viewer.scene.setTerrain){ viewer.scene.setTerrain(Cesium.Terrain.fromWorldTerrain()); }
    else { throw new Error('このCesiumJSではWorld Terrain APIが見つかりません。'); }
    terrainOn=true;
    updateTerrainButton();
    document.getElementById('groundRelative').checked=true;
    await rebuildEntities(true);
    loadImagery();
    zoomToData();
  }catch(e){
    terrainOn=false;
    updateTerrainButton();
    status('地形を有効にできませんでした。\\ntoken、ネット接続、Cesium ionの利用設定を確認してください。\\n\\n'+e.message);
  }
}
async function disableTerrain(){
  try{
    viewer.terrainProvider=new Cesium.EllipsoidTerrainProvider();
    terrainOn=false;
    updateTerrainButton();
    await rebuildEntities(document.getElementById('groundRelative').checked);
    zoomToData();
  }catch(e){
    status('地形OFFに失敗しました。\\n'+e.message);
  }
}
async function toggleTerrain(){
  if(terrainOn) await disableTerrain();
  else await enableTerrain();
}
async function shutdownViewer(){
  status('終了処理を送信しています...');
  try{
    await fetch('/__shutdown', {method:'POST'});
    status('ローカルサーバーへ終了を送信しました。タブを閉じます。閉じない場合は手動で閉じてください。');
    setTimeout(function(){ window.close(); }, 600);
  }catch(e){
    status('サーバー終了リクエストを送れませんでした。\\nfile:///で直接開いている場合や、標準サーバー以外では終了ボタンは使えません。\\n起動用batから開いた場合は、黒い画面で Ctrl+C でも終了できます。\\n\\n'+e.message);
  }
}
viewer.screenSpaceEventHandler.setInputAction(function(click){
  const picked=viewer.scene.pick(click.position);
  if(Cesium.defined(picked) && picked.id && picked.id.properties){
    const v=picked.id.properties.info && picked.id.properties.info.getValue ? picked.id.properties.info.getValue() : '';
    infoEl.textContent=v || picked.id.name || '属性なし';
  }
}, Cesium.ScreenSpaceEventType.LEFT_CLICK);

document.getElementById('zoomToData').onclick=zoomToData;
document.getElementById('zoomToEntities').onclick=zoomToEntities;
document.getElementById('reloadMap').onclick=function(){ loadImagery(); zoomToData(); };
document.getElementById('shutdown').onclick=shutdownViewer;
document.getElementById('mapMode').onchange=function(){ loadImagery(); };
document.getElementById('mapAlpha').oninput=updateMapAlpha;
document.getElementById('skyMode').onchange=applySkyMode;
let rebuildTimer=null;
function scheduleRebuild(){
  if(rebuildTimer) clearTimeout(rebuildTimer);
  rebuildTimer=setTimeout(async function(){ await rebuildEntities(document.getElementById('groundRelative').checked); }, 120);
}
document.getElementById('buildingAlpha').oninput=function(){ updateBuildingAlphaLabel(); scheduleRebuild(); };
if(colorAttrSelect) colorAttrSelect.onchange=async function(){ colorAttr=this.value||'floor_no'; updateLegend(); await rebuildEntities(document.getElementById('groundRelative').checked); };
document.getElementById('toggleUnderground').onclick=function(){ undergroundVisible=!undergroundVisible; undergroundEntities.forEach(e=>e.show=undergroundVisible); };
document.getElementById('toggleAbove').onclick=function(){ aboveVisible=!aboveVisible; aboveEntities.forEach(e=>e.show=aboveVisible); };
document.getElementById('toggleTerrain').onclick=toggleTerrain;
document.getElementById('groundRelative').onchange=async function(){ await rebuildEntities(this.checked); };
document.getElementById('sampleTerrain').onchange=async function(){ await rebuildEntities(document.getElementById('groundRelative').checked); };
document.getElementById('colorScheme').onchange=async function(){ colorScheme=this.value||'floorRainbow'; updateLegend(); await rebuildEntities(document.getElementById('groundRelative').checked); };

updateTerrainButton();
await rebuildEntities(true);
zoomToData();

}catch(e){
  showFatal('Cesium版Viewerの初期化中にエラーが発生しました。\\n'+(e && e.message ? e.message : String(e)));
}
})();
</script>
</body>
</html>"""
    return (html
            .replace('__DATA__', data_json)
            .replace('__DATA_JS__', data_js_name)
            .replace('__COUNT__', str(feature_count))
            .replace('__MINZ__', f'{minz:.3f}')
            .replace('__MAXZ__', f'{maxz:.3f}'))

def _viewer_html(data_json: str, feature_count: int, minz: float, maxz: float, data_js_name: str) -> str:
    """HTML内蔵データで必ず表示し、同じフォルダに data.js があればそれを優先するビューワー。"""
    html = """<!doctype html>
<html lang=\"ja\">
<head>
<meta charset=\"utf-8\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<title>CityGML2FloorPolygons Viewer</title>
<style>
html,body{margin:0;height:100%;overflow:hidden;font-family:system-ui,-apple-system,\"Segoe UI\",sans-serif;background:#eef0f2;color:#222;}
#view{position:absolute;inset:0;background:linear-gradient(#f7f8f9,#e5e8eb);cursor:grab;}
#view:active{cursor:grabbing;}
#panel{position:absolute;left:12px;top:12px;width:370px;max-height:calc(100% - 24px);overflow:auto;background:rgba(255,255,255,.96);border:1px solid #c9c9c9;border-radius:10px;box-shadow:0 4px 20px rgba(0,0,0,.18);padding:12px;font-size:13px;box-sizing:border-box;}
#panel h1{font-size:16px;margin:0 0 8px;}
.hint{font-size:12px;color:#555;line-height:1.5;}
.row{margin:8px 0;}
button{margin:2px 4px 2px 0;}
#floors{display:grid;grid-template-columns:repeat(3,1fr);gap:4px 6px;margin-top:6px;}
label{white-space:nowrap;user-select:none;}
#info{margin-top:8px;padding-top:8px;border-top:1px solid #ddd;white-space:pre-wrap;line-height:1.45;}
#err{margin-top:6px;color:#b00020;white-space:pre-wrap;font-weight:600;}
#stats{font-size:12px;color:#555;}
#legend{display:flex;align-items:center;gap:8px;font-size:11px;color:#555;}
#legendBar{height:12px;flex:1;border:1px solid #bbb;border-radius:6px;background:linear-gradient(90deg,#dfe8ff,#4f67d2,#7a0059);}
</style>
</head>
<body>
<canvas id=\"view\"></canvas>
<div id=\"panel\">
  <h1>CityGML2FloorPolygons Viewer</h1>
  <div class=\"hint\">HTML内蔵データで表示します。同じフォルダに __DATA_JS__ がある場合はそちらを優先します。ドラッグで360°回転、Shift+ドラッグで移動、ホイールでズーム、クリックで属性表示します。真横表示ボタンで地面を真横から見る視点にできます。右上の矢印は天方向です。</div>
  <div id=\"stats\" class=\"row\">floor count: __COUNT__ / z: __MINZ__ – __MAXZ__</div>
  <div class=\"row\"><button id=\"showAll\">全階ON</button><button id=\"hideAll\">全階OFF</button><button id=\"sideView\">真横表示</button><button id=\"resetView\">表示リセット</button></div>
  <div class=\"row\">透明度 <input id=\"opacity\" type=\"range\" min=\"15\" max=\"100\" value=\"78\"></div>
  <div class=\"row\">Z強調 <input id=\"zscale\" type=\"range\" min=\"40\" max=\"300\" value=\"120\"></div>
  <div class=\"row\"><label><input id=\"showWalls\" type=\"checkbox\"> 壁を表示（重い場合はOFF推奨）</label></div>
  <div class=\"row\">色分け属性 <select id=\"colorAttr\"></select></div>
  <div class=\"row\">カラーバリエーション <select id=\"colorScheme\">
    <option value=\"floorRainbow\" selected>レインボー（階別・前の色）</option>
    <option value=\"rainbow\">連続レインボー（紫→青→緑→黄→赤）</option>
    <option value=\"viridis\">紫→青緑→黄</option>
    <option value=\"terrain\">茶→白→緑</option>
    <option value=\"heat\">黄→橙→赤</option>
    <option value=\"pinkgreen\">ピンク→白→緑</option>
    <option value=\"redblue\">赤→黄→青</option>
  </select></div>
  <div id=\"legend\" class=\"row\"><span id=\"legendMin\"></span><div id=\"legendBar\"></div><span id=\"legendMax\"></span></div>
  <div>階の表示</div>
  <div id=\"floors\"></div>
  <div id=\"err\"></div>
  <div id=\"info\">建物をクリックすると、属性を表示します。</div>
</div>
<script id=\"viewer-data\" type=\"application/json\">__DATA__</script>
<script src=\"__DATA_JS__\"></script>
<script>
(function(){
'use strict';
const err = document.getElementById('err');
function showError(msg){ if(err) err.textContent = msg; }
let embedded = {};
try { embedded = JSON.parse(document.getElementById('viewer-data').textContent || '{}'); }
catch(e){ showError('HTML内蔵データを読めませんでした: '+e.message); embedded = {}; }
const data = window.CGML2FP_VIEWER_DATA || embedded || {};
const canvas = document.getElementById('view');
const ctx = canvas.getContext('2d');
const floorsDiv = document.getElementById('floors');
const info = document.getElementById('info');
const opacityInput = document.getElementById('opacity');
const zScaleInput = document.getElementById('zscale');
const colorAttrSelect = document.getElementById('colorAttr');
const colorSchemeSelect = document.getElementById('colorScheme');
const showWallsInput = document.getElementById('showWalls');
const legendMin = document.getElementById('legendMin');
const legendMax = document.getElementById('legendMax');
const legendBar = document.getElementById('legendBar');
const sideViewBtn = document.getElementById('sideView');
let W=1,H=1,dpr=1;
let yaw=-0.75, pitch=0.95, scale=1, panX=0, panY=0;
let dragging=false,lastX=0,lastY=0,dragMoved=false,dragMode='rotate';
let hitFaces=[];
let colorInfo={numeric:false,range:null};
const bounds=data.bounds||{};
const features=Array.isArray(data.features)?data.features:[];
const center=Array.isArray(data.center)?data.center:[0,0];
const cx0=Number(center[0])||0;
const cy0=Number(center[1])||0;
const z0=Number(data.z0)||0;
const looksLonLat=Math.abs(cx0)<=180 && Math.abs(cy0)<=90 && Math.abs(Number(bounds.maxx||0))<=180 && Math.abs(Number(bounds.maxy||0))<=90;
const rad=Math.PI/180;
const mx=looksLonLat?Math.max(1,111320*Math.cos(cy0*rad)):1;
const my=looksLonLat?110574:1;
function ownAttr(f, attr){ if(f && Object.prototype.hasOwnProperty.call(f, attr)) return f[attr]; const a=(f&&f.attrs)||{}; return a[attr]; }
function num(v, fallback){ const n=Number(v); return Number.isFinite(n) ? n : fallback; }
function floorNumber(f){ return num(ownAttr(f,'floor_no'), num(f.floor_no, 0)); }
function zBase(f){ return num(ownAttr(f,'z_base'), num(f.z_base, num(f.floor_z, 0))); }
function zTop(f){ return num(ownAttr(f,'z_top'), num(f.z_top, num(f.ceiling_z, zBase(f)))); }
let availableAttrs=Array.isArray(data.availableAttributes)?data.availableAttributes.slice():[];
if(!availableAttrs.length && features.length){
  const s=new Set(['floor_no','z_base','z_top']);
  for(const k of Object.keys(features[0].attrs||{})) s.add(k);
  availableAttrs=Array.from(s);
}
if(!availableAttrs.includes('floor_no')) availableAttrs.unshift('floor_no');
let colorAttr='floor_no';
let colorScheme=data.defaultColorScheme||'rainbow';
if(!availableAttrs.includes(colorAttr)) colorAttr='floor_no';
const floorStats=new Map();
for(const f of features){ const n=floorNumber(f); floorStats.set(n,(floorStats.get(n)||0)+1); }
const sortedFloors=Array.from(floorStats.keys()).sort((a,b)=>a-b);
const groups=[];
for(const n of sortedFloors){
  if(n<=-10){ if(!groups.includes('B10+')) groups.push('B10+'); }
  else if(n>=10){ if(!groups.includes('10+')) groups.push('10+'); }
  else groups.push(String(n));
}
const visibleGroups=new Map(groups.map(g=>[g,true]));
const basementFloors=sortedFloors.filter(n=>n<0);
const aboveFloors=sortedFloors.filter(n=>n>0);
const maxBasement=Math.max(0, ...basementFloors.map(n=>Math.abs(n)));
const maxAbove=Math.max(0, ...aboveFloors);
function floorLabel(n){ n=Number(n)||0; return n<0 ? ('B'+Math.abs(n)+'F') : (n+'F'); }
function basementBlueColor(depth, alpha, side){
  const d=Math.max(1, Math.abs(Number(depth)||1));
  const t=maxBasement>1 ? ((d-1)/(maxBasement-1)) : 0;
  const hue=212 - (8*t);
  const sat=(side?46:60) + (t*8);
  const light=(side?64:74) - (t*(side?18:26));
  return 'hsla('+hue+','+sat+'%,'+light+'%,'+alpha+')';
}
function aboveGreenPurpleRainbowColor(floorNo, alpha, side){
  const n=Math.max(1, Number(floorNo)||1);
  const t=maxAbove>1 ? ((n-1)/(maxAbove-1)) : 0;
  const rawHue=120 - (195*t); // green -> yellow -> orange -> red -> magenta -> purple
  const hue=((rawHue%360)+360)%360;
  const sat=(side?46:62) + (t*3);
  const light=(side?50:58) - (t*(side?2:4));
  return 'hsla('+hue+','+sat+'%,'+light+'%,'+alpha+')';
}
function groupOfFloor(n){ n=Number(n)||0; if(n<=-10) return 'B10+'; if(n>=10) return '10+'; return String(n); }
function groupLabel(g){ if(g==='B10+') return 'B10F以下'; if(g==='10+') return '10F以上'; return floorLabel(Number(g)); }
for(const g of groups){
  const label=document.createElement('label');
  const count=(g==='10+') ? sortedFloors.filter(v=>v>=10).reduce((a,b)=>a+(floorStats.get(b)||0),0)
    : (g==='B10+') ? sortedFloors.filter(v=>v<=-10).reduce((a,b)=>a+(floorStats.get(b)||0),0)
    : (floorStats.get(Number(g))||0);
  label.innerHTML='<input type=\"checkbox\" checked> '+groupLabel(g)+' ('+count+')';
  const cb=label.querySelector('input');
  cb.addEventListener('change',e=>{ visibleGroups.set(g,e.target.checked); draw(); });
  floorsDiv.appendChild(label);
}
if(!availableAttrs.includes('floor_no') && availableAttrs.length){ colorAttr=availableAttrs[0]; }
for(const name of availableAttrs){ const opt=document.createElement('option'); opt.value=name; opt.textContent=name; if(name===colorAttr) opt.selected=true; colorAttrSelect.appendChild(opt); }
if(colorSchemeSelect){ colorSchemeSelect.value=colorScheme; if(colorSchemeSelect.value!==colorScheme) colorSchemeSelect.value='rainbow'; }
colorAttrSelect.addEventListener('change',()=>{ colorAttr=colorAttrSelect.value || 'floor_no'; updateLegend(); draw(); });
if(colorSchemeSelect) colorSchemeSelect.addEventListener('change',()=>{ colorScheme=colorSchemeSelect.value||'floorRainbow'; updateLegend(); draw(); });
showWallsInput.addEventListener('change',()=>draw());
if(!features.length){showError('HTML内に表示対象データがありません。data.jsがある場合は、HTMLと同じフォルダに置かれているか確認してください。');}
document.getElementById('showAll').onclick=()=>setAll(true);
document.getElementById('hideAll').onclick=()=>setAll(false);
if(sideViewBtn) sideViewBtn.onclick=()=>setSideView();
document.getElementById('resetView').onclick=()=>fitView();
opacityInput.addEventListener('input',draw);
zScaleInput.addEventListener('input',()=>{fitView(false); draw();});
function setAll(v){ for(const g of groups){ visibleGroups.set(g,v); } Array.from(floorsDiv.querySelectorAll('input')).forEach(cb=>cb.checked=v); draw(); }
function localXY(pt){return {x:(Number(pt[0])-cx0)*mx, y:(Number(pt[1])-cy0)*my};}
function rawProject(pt,z){
  const p=localXY(pt);
  const cy=Math.cos(yaw), sy=Math.sin(yaw);
  const x1=p.x*cy-p.y*sy;
  const y1=p.x*sy+p.y*cy;
  const zex=Number(zScaleInput.value)/100;
  const z1=(Number(z)-z0)*zex;
  const cp=Math.cos(pitch), sp=Math.sin(pitch);
  const y2=y1*cp - z1*sp;
  const z2=y1*sp + z1*cp;
  return {x:x1, y:y2, depth:z2 + y1*0.15};
}
function project(pt,z){ const r=rawProject(pt,z); return {x:W/2+panX+r.x*scale, y:H/2+panY+r.y*scale, depth:r.depth}; }
function upVectorScreen(){
  const cp=Math.cos(pitch), sp=Math.sin(pitch);
  return {x:0, y:(-sp)};
}
function ringOpen(ring){const pts=(ring||[]).slice(); if(pts.length>2){const a=pts[0],b=pts[pts.length-1]; if(Math.abs(Number(a[0])-Number(b[0]))<1e-10 && Math.abs(Number(a[1])-Number(b[1]))<1e-10) pts.pop();} return pts;}
function hashHue(text){ let h=0; text=String(text||''); for(let i=0;i<text.length;i++) h=((h*31)+text.charCodeAt(i))%360; return h; }
function getAttrValue(f,attr){ const v=ownAttr(f,attr); const n=Number(v); return Number.isFinite(n) && String(v).trim()!=='' ? n : v; }
function numericRange(attr){ let min=Infinity,max=-Infinity,count=0; for(const f of features){ const v=getAttrValue(f,attr); if(typeof v==='number' && Number.isFinite(v)){ min=Math.min(min,v); max=Math.max(max,v); count++; } } return count?{min,max}:null; }
function currentColorInfo(){ const r=numericRange(colorAttr); return { numeric: !!r, range: r }; }
const PALETTES={
  viridis:['#440154','#31688e','#35b779','#fde725'],
  terrain:['#b57b2a','#d8c077','#f0eee3','#67b7a8','#00866b'],
  heat:['#ffffb2','#fed976','#fd8d3c','#f03b20','#bd0026'],
  pinkgreen:['#d01c8b','#f1b6da','#f7f7f7','#b8e186','#4dac26'],
  redblue:['#d7191c','#fdae61','#ffffbf','#abd9e9','#2c7bb6']
};
function hexToRgb(hex){ hex=String(hex).replace('#',''); return [parseInt(hex.slice(0,2),16),parseInt(hex.slice(2,4),16),parseInt(hex.slice(4,6),16)]; }
function interpPalette(t,pal){ t=Math.max(0,Math.min(1,t)); const arr=pal.map(hexToRgb); const pos=t*(arr.length-1); const i=Math.min(arr.length-2,Math.floor(pos)); const u=pos-i; return [0,1,2].map(k=>Math.round(arr[i][k]+(arr[i+1][k]-arr[i][k])*u)); }
function floorRainbowColor(v,alpha,side){
  const n=Number(v);
  if(Number.isFinite(n)){
    if(n < 0) return basementBlueColor(n, alpha, side);
    return aboveGreenPurpleRainbowColor(n <= 0 ? 1 : n, alpha, side);
  }
  return aboveGreenPurpleRainbowColor(1, alpha, side);
}
function paletteColor(t,alpha,side){
  t=Math.max(0,Math.min(1,t));
  if(colorScheme==='rainbow'){ const hue=270-(270*t); const sat=side?46:62; const light=side?(54-(t*12)):(62-(t*8)); return 'hsla('+hue+','+sat+'%,'+light+'%,'+alpha+')'; }
  const rgb=interpPalette(t, PALETTES[colorScheme]||PALETTES.viridis);
  if(side){ rgb[0]=Math.round(rgb[0]*0.82); rgb[1]=Math.round(rgb[1]*0.82); rgb[2]=Math.round(rgb[2]*0.82); }
  return 'rgba('+rgb[0]+','+rgb[1]+','+rgb[2]+','+alpha+')';
}
function legendCss(){
  if(colorScheme==='floorRainbow'){
    const hasBasement=maxBasement>0;
    const hasAbove=maxAbove>0;
    if(hasBasement && hasAbove){
      const blueStops=[];
      const aboveStops=[];
      const bc=Math.min(6, Math.max(2, maxBasement));
      const ac=Math.min(10, Math.max(2, maxAbove));
      for(let i=0;i<bc;i++){
        const depth=maxBasement - ((maxBasement-1)*(i/Math.max(1,bc-1)));
        blueStops.push(basementBlueColor(-Math.round(depth),1,false));
      }
      for(let i=0;i<ac;i++){
        const floorNo=1 + ((Math.max(1,maxAbove)-1)*(i/Math.max(1,ac-1)));
        aboveStops.push(aboveGreenPurpleRainbowColor(Math.round(floorNo),1,false));
      }
      return 'linear-gradient(90deg,'+blueStops.join(',')+', '+aboveStops.join(',')+')';
    }
    if(hasBasement){
      const stops=[];
      const count=Math.min(8, Math.max(2, maxBasement));
      for(let i=0;i<count;i++){
        const depth=maxBasement - ((maxBasement-1)*(i/Math.max(1,count-1)));
        stops.push(basementBlueColor(-Math.round(depth),1,false));
      }
      return 'linear-gradient(90deg,'+stops.join(',')+')';
    }
    const stops=[];
    const count=Math.min(12, Math.max(2, maxAbove||8));
    for(let i=0;i<count;i++){
      const floorNo=1 + (((Math.max(1,maxAbove||8))-1)*(i/Math.max(1,count-1)));
      stops.push(aboveGreenPurpleRainbowColor(Math.round(floorNo),1,false));
    }
    return 'linear-gradient(90deg,'+stops.join(',')+')';
  }
  if(colorScheme==='rainbow') return 'linear-gradient(90deg,hsl(270,70%,55%),hsl(210,70%,55%),hsl(135,70%,50%),hsl(60,80%,55%),hsl(0,75%,55%))';
  return 'linear-gradient(90deg,'+(PALETTES[colorScheme]||PALETTES.viridis).join(',')+')';
}
function colorForFeature(f,alpha,side){ const ci=colorInfo; const v=getAttrValue(f,colorAttr); if(colorScheme==='floorRainbow'){ return floorRainbowColor(v===undefined?floorNumber(f):v,alpha,side); } if(ci.numeric && ci.range){ const min=ci.range.min, max=ci.range.max; const t=(max-min)>0 ? ((Number(v)-min)/(max-min)) : 0.5; return paletteColor(t,alpha,side); } const hue=hashHue(v===undefined?floorNumber(f):v); return 'hsla('+hue+','+(side?40:55)+'%,'+(side?46:60)+'%,'+alpha+')'; }
function updateLegend(){ colorInfo=currentColorInfo(); if(legendBar) legendBar.style.background=legendCss(); const ci=colorInfo; if(ci.numeric && ci.range){ legendMin.textContent=String(ci.range.min); legendMax.textContent=String(ci.range.max); } else { legendMin.textContent='カテゴリ'; legendMax.textContent=colorAttr; } }
function pathFrom(points,z){ const path=new Path2D(); let d=0, first=true; for(const pt of points){const p=project(pt,z); if(first){path.moveTo(p.x,p.y); first=false;} else path.lineTo(p.x,p.y); d+=p.depth;} path.closePath(); return {path, depth:d/Math.max(points.length,1)}; }
function collectFaces(fast=false){
  const faces=[]; hitFaces=[]; const alpha=Math.max(.15,Number(opacityInput.value)/100);
  const includeWalls=Boolean(showWallsInput && showWallsInput.checked && !fast);
  for(const f of features){
    const fno=floorNumber(f); const g=groupOfFloor(fno); if(!visibleGroups.get(g)) continue;
    const zB=zBase(f), zT=zTop(f); if(!Number.isFinite(zB)||!Number.isFinite(zT)) continue;
    for(const poly of (f.polygons||[])){
      if(!poly||!poly.length) continue; const outer=ringOpen(poly[0]); if(outer.length<3) continue;
      if(includeWalls){
        for(let i=0;i<outer.length;i++){
          const a=outer[i], b=outer[(i+1)%outer.length];
          const pts=[a,b,b,a], zs=[zB,zB,zT,zT]; const path=new Path2D(); let depth=0;
          for(let j=0;j<4;j++){ const p=project(pts[j],zs[j]); if(j===0) path.moveTo(p.x,p.y); else path.lineTo(p.x,p.y); depth+=p.depth; }
          path.closePath(); faces.push({path, depth:depth/4, fill:colorForFeature(f,alpha*.72,true), stroke:fast?'rgba(30,30,30,.12)':'rgba(30,30,30,.28)', feature:f, hit:false});
        }
      }
      const top=pathFrom(outer,zT); faces.push({path:top.path, depth:top.depth+100000, fill:colorForFeature(f,alpha,false), stroke:fast?'rgba(20,20,20,.18)':'rgba(20,20,20,.42)', feature:f, hit:true});
    }
  }
  faces.sort((a,b)=>a.depth-b.depth); return faces;
}
function drawGrid(){
  ctx.save(); ctx.strokeStyle='rgba(0,0,0,.08)'; ctx.lineWidth=1;
  const step=50, lim=500; for(let v=-lim; v<=lim; v+=step){
    let a=project([cx0+(-lim)/mx, cy0+v/my], z0), b=project([cx0+lim/mx, cy0+v/my], z0);
    ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y); ctx.stroke();
    let c=project([cx0+v/mx, cy0+(-lim)/my], z0), d=project([cx0+v/mx, cy0+lim/my], z0);
    ctx.beginPath(); ctx.moveTo(c.x,c.y); ctx.lineTo(d.x,d.y); ctx.stroke();
  }
  ctx.restore();
}
function drawUpIndicator(){
  const vx=upVectorScreen().x;
  const vy=upVectorScreen().y;
  const len=Math.hypot(vx,vy) || 1;
  const ux=vx/len, uy=vy/len;
  const cx=W-78, cy=78, r=28;
  ctx.save();
  ctx.fillStyle='rgba(255,255,255,.88)';
  ctx.strokeStyle='rgba(60,60,60,.35)';
  ctx.lineWidth=1.2;
  ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.fill(); ctx.stroke();
  ctx.fillStyle='rgba(40,40,40,.9)';
  ctx.font='bold 14px sans-serif';
  ctx.textAlign='center';
  ctx.textBaseline='middle';
  ctx.fillText('天', cx, cy-r-14);
  const ex=cx + ux*18, ey=cy + uy*18;
  ctx.strokeStyle='rgba(35,78,170,.95)';
  ctx.fillStyle='rgba(35,78,170,.95)';
  ctx.lineWidth=3;
  ctx.beginPath(); ctx.moveTo(cx,cy); ctx.lineTo(ex,ey); ctx.stroke();
  const px=-uy, py=ux;
  ctx.beginPath();
  ctx.moveTo(ex,ey);
  ctx.lineTo(ex-ux*9+px*5, ey-uy*9+py*5);
  ctx.lineTo(ex-ux*9-px*5, ey-uy*9-py*5);
  ctx.closePath(); ctx.fill();
  ctx.restore();
}
function draw(fast=false){
  ctx.clearRect(0,0,W,H);
  if(!fast) drawGrid();
  const faces=collectFaces(fast);
  for(const face of faces){
    ctx.fillStyle=face.fill; ctx.strokeStyle=face.stroke; ctx.lineWidth=fast?.45:.7;
    ctx.fill(face.path); if(!fast || features.length<2500) ctx.stroke(face.path);
    if(face.hit && !fast) hitFaces.push(face);
  }
  drawUpIndicator();
  if(!faces.length && features.length) showError('現在ONの階に表示対象がありません。'); else if(err.textContent.startsWith('現在ON')) showError('');
}
function projectedBounds(){
  let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity, ok=false;
  for(const f of features){
    for(const poly of (f.polygons||[])){
      if(!poly||!poly.length) continue; const outer=ringOpen(poly[0]);
      for(const pt of outer){ for(const z of [zBase(f),zTop(f)]){ const p=rawProject(pt,z); if(Number.isFinite(p.x)&&Number.isFinite(p.y)){ minx=Math.min(minx,p.x); maxx=Math.max(maxx,p.x); miny=Math.min(miny,p.y); maxy=Math.max(maxy,p.y); ok=true; } } }
    }
  }
  return ok?{minx,miny,maxx,maxy}:null;
}
function fitView(resetAngle=true){
  if(resetAngle){ yaw=-0.75; pitch=0.95; }
  const b=projectedBounds(); if(!b){scale=1; panX=0; panY=0; draw(); return;}
  const panelW=400; const left=panelW+24, right=W-24, top=24, bottom=H-24;
  const aw=Math.max(100,right-left), ah=Math.max(100,bottom-top);
  const bw=Math.max(1,b.maxx-b.minx), bh=Math.max(1,b.maxy-b.miny);
  scale=Math.min(aw/bw, ah/bh)*0.88; if(!Number.isFinite(scale)||scale<=0) scale=1;
  const targetX=(left+right)/2, targetY=(top+bottom)/2;
  panX=targetX-W/2-((b.minx+b.maxx)/2)*scale;
  panY=targetY-H/2-((b.miny+b.maxy)/2)*scale;
  draw();
}
function setSideView(){
  pitch=Math.PI/2;
  const b=projectedBounds(); if(!b){ draw(); return; }
  const panelW=400; const left=panelW+24, right=W-24, top=24, bottom=H-24;
  const aw=Math.max(100,right-left), ah=Math.max(100,bottom-top);
  const bw=Math.max(1,b.maxx-b.minx), bh=Math.max(1,b.maxy-b.miny);
  scale=Math.min(aw/bw, ah/bh)*0.88; if(!Number.isFinite(scale)||scale<=0) scale=1;
  const targetX=(left+right)/2, targetY=(top+bottom)/2;
  panX=targetX-W/2-((b.minx+b.maxx)/2)*scale;
  panY=targetY-H/2-((b.miny+b.maxy)/2)*scale;
  draw();
}
function resize(){W=window.innerWidth; H=window.innerHeight; dpr=window.devicePixelRatio||1; canvas.style.width=W+'px'; canvas.style.height=H+'px'; canvas.width=Math.round(W*dpr); canvas.height=Math.round(H*dpr); ctx.setTransform(dpr,0,0,dpr,0,0); fitView(false);}
window.addEventListener('resize',resize); updateLegend(); resize();
canvas.addEventListener('pointerdown',e=>{dragging=true; dragMoved=false; dragMode=e.shiftKey?'pan':'rotate'; lastX=e.clientX; lastY=e.clientY; canvas.setPointerCapture(e.pointerId);});
canvas.addEventListener('pointermove',e=>{if(!dragging)return; const dx=e.clientX-lastX, dy=e.clientY-lastY; if(Math.abs(dx)+Math.abs(dy)>1) dragMoved=true; if(dragMode==='pan'){panX+=dx; panY+=dy;} else {yaw+=dx*.008; pitch-=dy*.008; if(pitch>Math.PI) pitch=Math.PI; if(pitch<-Math.PI) pitch=-Math.PI;} lastX=e.clientX; lastY=e.clientY; draw();});
canvas.addEventListener('pointerup',e=>{dragging=false; try{canvas.releasePointerCapture(e.pointerId);}catch(_){} });
canvas.addEventListener('wheel',e=>{e.preventDefault(); const old=scale; scale*=Math.exp(-e.deltaY*.001); if(!Number.isFinite(scale)||scale<=0) scale=old; draw();},{passive:false});
canvas.addEventListener('click',e=>{
  if(dragMoved) return; const x=e.clientX, y=e.clientY;
  for(let i=hitFaces.length-1;i>=0;i--){ const face=hitFaces[i]; if(ctx.isPointInPath(face.path,x,y)){ const f=face.feature; const lines=[]; const attrs=f.attrs||{}; const selected=Array.isArray(data.selectedAttributes)?data.selectedAttributes:Object.keys(attrs); for(const key of selected){ if(key in attrs) lines.push(key+': '+attrs[key]); } if(!lines.length){ lines.push('gml_id: '+(f.gml_id||'')); lines.push('building_id: '+(f.building_id||'')); lines.push('floor_no: '+floorNumber(f)+' / '+(f.floors_used||'')); lines.push('z_base: '+zBase(f)); lines.push('z_top: '+zTop(f)); } info.textContent=lines.join('\\n'); return; } }
});
})();
</script>
</body>
</html>"""
    return (html
            .replace('__DATA__', data_json)
            .replace('__DATA_JS__', data_js_name)
            .replace('__COUNT__', str(feature_count))
            .replace('__MINZ__', f'{minz:.3f}')
            .replace('__MAXZ__', f'{maxz:.3f}'))

def select_footprint(b: PlateauBuilding, footprint_source: int):
    if footprint_source == 0:
        return b.footprint_lod0 or b.footprint_lod1_bottom
    return b.footprint_lod1_bottom or b.footprint_lod0


def footprint_method(b: PlateauBuilding, footprint_source: int):
    if footprint_source == 0:
        if b.footprint_lod0:
            return 'lod0RoofEdge/lod0FootPrint'
        if b.footprint_lod1_bottom:
            return 'lod1Solid_bottom'
    else:
        if b.footprint_lod1_bottom:
            return 'lod1Solid_bottom'
        if b.footprint_lod0:
            return 'lod0RoofEdge/lod0FootPrint'
    return 'unknown'


def multipolygon_geometry(mp, swap_axis: bool, z_value: Optional[float]):
    if z_value is None:
        multi = []
        for poly in mp:
            rings_xy = []
            for ring in poly:
                pts = []
                for a, b, _z in ring:
                    if swap_axis:
                        pts.append(QgsPointXY(b, a))
                    else:
                        pts.append(QgsPointXY(a, b))
                if len(pts) >= 4:
                    if pts[0] != pts[-1]:
                        pts.append(pts[0])
                    rings_xy.append(pts)
            if rings_xy:
                multi.append(rings_xy)
        if not multi:
            return None
        return QgsGeometry.fromMultiPolygonXY(multi)

    polys_wkt = []
    z = _fmt(z_value)
    for poly in mp:
        rings_wkt = []
        for ring in poly:
            pts = []
            for a, b, _original_z in ring:
                x, y = (b, a) if swap_axis else (a, b)
                pts.append((_fmt(x), _fmt(y), z))
            if len(pts) >= 4:
                if pts[0][0] != pts[-1][0] or pts[0][1] != pts[-1][1]:
                    pts.append(pts[0])
                rings_wkt.append('(' + ','.join(f'{x} {y} {zz}' for x, y, zz in pts) + ')')
        if rings_wkt:
            polys_wkt.append('(' + ','.join(rings_wkt) + ')')
    if not polys_wkt:
        return None
    return QgsGeometry.fromWkt('MULTIPOLYGON Z (' + ','.join(polys_wkt) + ')')


def _fmt(v: float) -> str:
    return f'{float(v):.12g}'


def valid_height(h: Optional[float]):
    return h is not None and h > 0 and abs(h + 9999) > 1e-9


def valid_storey_count(value: Optional[int], max_storeys: int = 200) -> Optional[int]:
    """Return a usable storey count, excluding PLATEAU missing-value codes.

    Some PLATEAU datasets use values such as 9999 / -9999 as missing or
    unknown values. Treating those values as actual floor counts creates
    thousands of artificial floors, so they are rejected here.
    """
    if value is None:
        return None
    try:
        v = int(value)
    except Exception:
        return None
    if v <= 0:
        return None
    if v in (9999, -9999):
        return None
    if v > max_storeys:
        return None
    return v


def lod1_height(b: PlateauBuilding):
    if b.lod1_min_z is not None and b.lod1_max_z is not None:
        h = b.lod1_max_z - b.lod1_min_z
        return h if h > 0 else None
    return None


def ground_z_method(b: PlateauBuilding):
    if b.lod1_min_z is not None:
        return b.lod1_min_z, 'lod1Solid_min_z'
    if b.lod1_max_z is not None and valid_height(b.measured_height):
        return b.lod1_max_z - b.measured_height, 'lod1Solid_max_z_minus_measuredHeight'
    return 0.0, 'fallback_0'


def total_height_method_for(b: PlateauBuilding, height_source: int):
    lod1_h = lod1_height(b)
    measured_ok = valid_height(b.measured_height)
    lod1_ok = valid_height(lod1_h)

    if height_source == 0:
        if measured_ok:
            return b.measured_height, 'measuredHeight'
        if lod1_ok:
            return lod1_h, 'lod1Solid_z_range'
    else:
        if lod1_ok:
            return lod1_h, 'lod1Solid_z_range'
        if measured_ok:
            return b.measured_height, 'measuredHeight'
    return None, 'unknown'


def floor_heights_for(
    b: PlateauBuilding,
    total_height: Optional[float],
    total_height_method: str,
    invalid_handling: int,
    default_floor_height: float,
) -> Tuple[List[float], int, str]:
    floors = valid_storey_count(b.storeys_above_ground)
    floor_heights_attr = [h for h in b.storey_heights_above_ground if valid_height(h)]

    if floors is not None and floors > 0 and len(floor_heights_attr) >= floors:
        return floor_heights_attr[:floors], floors, 'storeyHeightsAboveGround'

    if floors is not None and floors > 0 and valid_height(total_height):
        avg = total_height / floors
        if avg > 0:
            return [avg] * floors, floors, f'{total_height_method}/storeysAboveGround'

    if floors is not None and floors > 0 and not valid_height(total_height):
        return [default_floor_height] * floors, floors, 'default_floor_height/storeysAboveGround'

    if invalid_handling == 1:
        if valid_height(total_height):
            return [total_height], 1, f'whole_building/{total_height_method}'
        return [default_floor_height], 1, 'whole_building/default_floor_height'

    if invalid_handling == 2 and valid_height(total_height):
        estimated = max(1, int(round(total_height / default_floor_height)))
        return [total_height / estimated] * estimated, estimated, 'estimated_floors_from_height'

    return [], 0, 'invalid_skipped'


def below_floor_heights_for(
    b: PlateauBuilding,
    default_floor_height: float,
) -> Tuple[List[float], int, str]:
    floors = valid_storey_count(b.storeys_below_ground)
    if floors is None:
        return [], 0, 'no_storeysBelowGround'

    floor_heights_attr = [h for h in getattr(b, 'storey_heights_below_ground', []) if valid_height(h)]
    if len(floor_heights_attr) >= floors:
        return floor_heights_attr[:floors], floors, 'storeyHeightsBelowGround'

    return [default_floor_height] * floors, floors, 'default_floor_height/storeysBelowGround'


def floor_label_for(floor_no: int) -> str:
    if floor_no < 0:
        return f'B{abs(floor_no)}F'
    return f'{floor_no}F'


