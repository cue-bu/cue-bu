# -*- coding: utf-8 -*-

def classFactory(iface):
    from .citygml2floorpolygons_plugin import CityGML2FloorPolygonsPlugin
    return CityGML2FloorPolygonsPlugin(iface)
